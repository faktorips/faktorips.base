/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.values.Money;

/**
 * Published Interface von HausratZusatzdeckung.
 * 
 * @generated
 */
public interface IHausratZusatzdeckung extends IHausratDeckung {

	/**
	 * Diese Konstante enthaelt den Namen der Property versSumme
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERSSUMME = "versSumme";

	/**
	 * Gibt den Wert des Attributs versSumme zurueck.
	 * 
	 * @generated
	 */
	public Money getVersSumme();

	/**
	 * Gibt d. HausratZusatzdeckungsTyp zurueck, welches d. HausratZusatzdeckung
	 * konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp();

	/**
	 * Setzt d. neue HausratZusatzdeckungsTyp.
	 * 
	 * @param hausratZusatzdeckungsTyp
	 *            D. neue HausratZusatzdeckungsTyp.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> falls die Eigenschaften mit den Defaultwerte
	 *            aus d. HausratZusatzdeckungsTyp belegt werden sollen.
	 * 
	 * @generated
	 */
	public void setHausratZusatzdeckungsTyp(IHausratZusatzdeckungsTyp hausratZusatzdeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Gibt d. Anpassungsstufe zurueck, welches d. HausratZusatzdeckungsTyp
	 * konfiguriert. D. Anpassungsstufe wird anhand des Wirksamkeitsdatum
	 * ermittelt.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTypAnpStufe getHausratZusatzdeckungsTypAnpStufe();

}
