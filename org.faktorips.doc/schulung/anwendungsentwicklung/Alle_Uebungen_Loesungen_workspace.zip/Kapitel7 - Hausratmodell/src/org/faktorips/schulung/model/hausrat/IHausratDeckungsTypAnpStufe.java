/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IProductComponentGeneration;

/**
 * Die Anpassungsstufe von HausratDeckungsTyp.
 * 
 * @generated
 */
public interface IHausratDeckungsTypAnpStufe extends IProductComponentGeneration {

	/**
	 * Gibt d HausratDeckungsTyp zurueck, zu dem diese Anpassungsstufe gehoert.
	 * 
	 * @generated
	 */
	public IHausratDeckungsTyp getHausratDeckungsTyp();

}
