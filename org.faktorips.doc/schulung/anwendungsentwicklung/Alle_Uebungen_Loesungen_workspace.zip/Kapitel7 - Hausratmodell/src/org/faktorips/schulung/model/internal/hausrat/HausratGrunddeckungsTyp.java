/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTyp;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTypAnpStufe;
import java.util.Calendar;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.runtime.IConfigurableModelObject;

/**
 * The implementation of IHausratGrunddeckungsTyp.
 * 
 * @generated
 */
public class HausratGrunddeckungsTyp extends HausratDeckungsTyp implements IHausratGrunddeckungsTyp {

	/**
	 * Erzeugt eine neue Instanz von HausratGrunddeckungsTyp.
	 * 
	 * @generated
	 */
	public HausratGrunddeckungsTyp(IRuntimeRepository repository, String id, String kindId, String generationId) {
		super(repository, id, kindId, generationId);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratGrunddeckungsTypAnpStufe getHausratGrunddeckungsTypAnpStufe(Calendar wirksamkeitsdatum) {
		return (IHausratGrunddeckungsTypAnpStufe) getRepository().getProductComponentGeneration(getId(),
				wirksamkeitsdatum);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratGrunddeckung createHausratGrunddeckung() {
		return new HausratGrunddeckung(this);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IConfigurableModelObject createPolicyComponent() {
		return createHausratGrunddeckung();
	}

}
