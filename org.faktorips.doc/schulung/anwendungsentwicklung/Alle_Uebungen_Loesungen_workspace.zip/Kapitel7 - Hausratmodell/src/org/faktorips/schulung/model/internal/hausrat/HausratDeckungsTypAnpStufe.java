/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.ProductComponentGeneration;
import org.faktorips.schulung.model.hausrat.IHausratDeckungsTypAnpStufe;
import org.faktorips.schulung.model.hausrat.IHausratDeckungsTyp;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.runtime.IProductComponentLink;
import org.faktorips.runtime.IProductComponent;
import java.util.List;
import java.util.ArrayList;

/**
 * Die Implementierung von IHausratDeckungsTypAnpStufe.
 * 
 * @generated
 */
public abstract class HausratDeckungsTypAnpStufe extends ProductComponentGeneration implements
		IHausratDeckungsTypAnpStufe {

	/**
	 * Erzeugt eine neue Instanz von HausratDeckungsTypAnpStufe.
	 * 
	 * @generated
	 */
	public HausratDeckungsTypAnpStufe(HausratDeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratDeckungsTyp getHausratDeckungsTyp() {
		return (IHausratDeckungsTyp) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IProductComponentLink<? extends IProductComponent> getLink(String linkName, IProductComponent target) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public List<IProductComponentLink<? extends IProductComponent>> getLinks() {
		List<IProductComponentLink<? extends IProductComponent>> list = new ArrayList<IProductComponentLink<? extends IProductComponent>>();
		return list;
	}

}
