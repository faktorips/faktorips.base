/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IProductComponentGeneration;
import org.faktorips.values.Money;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.valueset.MoneyRange;
import org.faktorips.valueset.IntegerRange;
import java.util.Calendar;
import org.faktorips.runtime.IProductComponentLink;
import org.faktorips.runtime.CardinalityRange;
import org.faktorips.valueset.ValueSet;
import java.util.List;
import java.util.Collection;

/**
 * Die Anpassungsstufe von HausratProdukt.
 * 
 * @generated
 */
public interface IHausratProduktAnpStufe extends IProductComponentGeneration {

	/**
	 * Diese Konstante enthaelt den Namen der Property produktname
	 * 
	 * @generated
	 */
	public final static String PROPERTY_PRODUKTNAME = "produktname";
	/**
	 * Diese Konstante enthaelt den Namen der Property vertriebsname
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERTRIEBSNAME = "vertriebsname";

	/**
	 * Diese Konstante enthaelt den Namen der Property vorschlagVersSummeProQm
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VORSCHLAGVERSSUMMEPROQM = "vorschlagVersSummeProQm";

	/**
	 * Gibt den Wert der Eigenschaft produktname zurueck.
	 * 
	 * @generated
	 */
	public String getProduktname();

	/**
	 * Gibt den Wert der Eigenschaft vertriebsname zurueck.
	 * 
	 * @generated
	 */
	public String getVertriebsname();

	/**
	 * Gibt den Wert der Eigenschaft vorschlagVersSummeProQm zurueck.
	 * 
	 * @generated
	 */
	public Money getVorschlagVersSummeProQm();

	/**
	 * Gibt den Defaultwert fuer die Eigenschaft zahlweise zurueck.
	 * 
	 * @generated
	 */
	public Zahlweise getDefaultValueZahlweise();

	/**
	 * Gibt den erlaubte Wertebereich fuer das Attribute zahlweise zurueck.
	 * 
	 * @generated
	 */
	public ValueSet<Zahlweise> getSetOfAllowedValuesForZahlweise(IValidationContext context);

	/**
	 * Gibt den Defaultwert fuer die Eigenschaft wohnflaeche zurueck.
	 * 
	 * @generated
	 */
	public Integer getDefaultValueWohnflaeche();

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribut wohnflaeche zurueck.
	 * 
	 * @generated
	 */
	public IntegerRange getRangeForWohnflaeche(IValidationContext context);

	/**
	 * Gibt den Defaultwert fuer die Eigenschaft versSumme zurueck.
	 * 
	 * @generated
	 */
	public Money getDefaultValueVersSumme();

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribut versSumme zurueck.
	 * 
	 * @generated
	 */
	public MoneyRange getRangeForVersSumme(IValidationContext context);

	/**
	 * Gibt d. HausratGrunddeckungsTyp zurueck. bzw. <null>, wenn kein Objekt
	 * referenziert wird.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             wenn der referenzierte Baustein nicht gefunden wird.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp();

	/**
	 * Gibt die zum gegebenen Zeitpunkt gueltige Generation d.
	 * HausratGrunddeckungsTyp zurueck; bzw. <null>, wenn kein Objekt
	 * referenziert wird.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             wenn der referenzierte Baustein nicht gefunden wird.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTypAnpStufe getHausratGrunddeckungsTyp(Calendar effectiveDate);

	/**
	 * Gib den <code>ILink</code> zut d. HausratGrunddeckungsTyp zurueck. bzw.
	 * <null>, wenn kein Objekt referenziert wird.
	 * 
	 * @generated
	 */
	public IProductComponentLink<IHausratGrunddeckungsTyp> getLinkForHausratGrunddeckungsTyp();

	/**
	 * Gibt den <code>ILink</code> zu d. HausratGrunddeckungsTyp an dem
	 * angegebenen Index zurueck.
	 * 
	 * @generated
	 */
	public IProductComponentLink<IHausratGrunddeckungsTyp> getLinkForHausratGrunddeckungsTyp(
			IHausratGrunddeckungsTyp productComponent);

	/**
	 * Gibt die Kardinalitaet fuer die Beziehung mit den Rollennamen
	 * HausratGrunddeckung zurueck
	 * 
	 * @generated
	 */
	public CardinalityRange getCardinalityForHausratGrunddeckung(IHausratGrunddeckungsTyp productCmpt);

	/**
	 * Gibt die referenzierten HausratZusatzdeckungsTypen zurueck. Gibt ein
	 * leeres Array zurueck, wenn kein Objekt referenziert wird.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             wenn einer der referenzierten Bausteine nicht gefunden wird.
	 * 
	 * @generated
	 */
	public List<IHausratZusatzdeckungsTyp> getHausratZusatzdeckungsTypen();

	/**
	 * Gibt die zum gegebenen Datum gueltigen referenzierten
	 * HausratZusatzdeckungsTypen zurueck. Gibt ein leeres Array zurueck, wenn
	 * kein Objekt referenziert wird.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             wenn einer der referenzierten Bausteine nicht gefunden wird.
	 * 
	 * @generated
	 */
	public List<IHausratZusatzdeckungsTypAnpStufe> getHausratZusatzdeckungsTypen(Calendar effectiveDate);

	/**
	 * Gibt d. HausratZusatzdeckungsTypen an dem angegebenen Index zurueck.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             wenn der referenzierten Baustein nicht gefunden wird.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp(int index);

	/**
	 * Gibt die referenzierten HausratZusatzdeckungsTypen zurueck. Gibt ein
	 * leeres Array zurueck, wenn kein Objekt referenziert wird.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             wenn einer der referenzierten Bausteine nicht gefunden wird.
	 * 
	 * @generated
	 */
	public Collection<IProductComponentLink<IHausratZusatzdeckungsTyp>> getLinksForHausratZusatzdeckungsTypen();

	/**
	 * Gibt den <code>ILink</code> zu d. HausratZusatzdeckungsTyp an dem
	 * angegebenen Index zurueck.
	 * 
	 * @generated
	 */
	public IProductComponentLink<IHausratZusatzdeckungsTyp> getLinkForHausratZusatzdeckungsTyp(
			IHausratZusatzdeckungsTyp productComponent);

	/**
	 * Gibt die Kardinalitaet fuer die Beziehung mit den Rollennamen
	 * HausratZusatzdeckung zurueck
	 * 
	 * @generated
	 */
	public CardinalityRange getCardinalityForHausratZusatzdeckung(IHausratZusatzdeckungsTyp productCmpt);

	/**
	 * Gibt die Anzahl der HausratZusatzdeckungsTypen zurueck.
	 * 
	 * @generated
	 */
	public int getNumOfHausratZusatzdeckungsTypen();

	/**
	 * Gibt die referenzierten HausratDeckungsTypen zurueck. Gibt ein leeres
	 * Array zurueck, wenn kein Objekt referenziert wird.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             wenn einer der referenzierten Bausteine nicht gefunden wird.
	 * 
	 * @generated
	 */
	public List<IHausratDeckungsTyp> getHausratDeckungsTypen();

	/**
	 * Gibt die Anzahl der HausratDeckungsTypen zurueck.
	 * 
	 * @generated
	 */
	public int getNumOfHausratDeckungsTypen();

	/**
	 * Gibt d HausratProdukt zurueck, zu dem diese Anpassungsstufe gehoert.
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProdukt();

}
