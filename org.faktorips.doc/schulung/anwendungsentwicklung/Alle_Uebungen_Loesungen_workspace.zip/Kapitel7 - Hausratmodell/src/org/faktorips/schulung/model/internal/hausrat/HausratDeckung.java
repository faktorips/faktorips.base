/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.AbstractConfigurableModelObject;
import org.faktorips.schulung.model.hausrat.IHausratDeckung;
import org.faktorips.schulung.model.hausrat.IHausratDeckungsTyp;
import org.faktorips.schulung.model.hausrat.IHausratDeckungsTypAnpStufe;
import org.faktorips.values.Money;

import java.util.Calendar;
import org.faktorips.runtime.internal.AbstractModelObject;
import org.w3c.dom.Element;
import org.faktorips.runtime.IModelObjectDelta;
import org.faktorips.runtime.IModelObject;
import org.faktorips.runtime.IDeltaComputationOptions;
import org.faktorips.runtime.internal.ModelObjectDelta;
import java.util.Map;
import org.faktorips.runtime.IModelObjectVisitor;
import org.faktorips.runtime.MessageList;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.runtime.IConfigurableModelObject;

/**
 * @generated
 */
public abstract class HausratDeckung extends AbstractConfigurableModelObject implements IHausratDeckung {

	/**
	 * Membervariable fuer jahresbasisbeitrag.
	 * 
	 * @generated
	 */
	private Money jahresbasisbeitrag = Money.NULL;

	/**
	 * Erzeugt eine neue Instanz von HausratDeckung.
	 * 
	 * @generated
	 */
	public HausratDeckung() {
		super();
	}

	/**
	 * Erzeugt eine neue Instanz von HausratDeckung.
	 * 
	 * @generated
	 */
	public HausratDeckung(IHausratDeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * Initialisiert produktrelevante Attribute mit ihren Vorgabewerten.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initialize() {

		// begin-user-code
		// end-user-code
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratDeckungsTyp getHausratDeckungsTyp() {
		return (IHausratDeckungsTyp) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratDeckungsTypAnpStufe getHausratDeckungsTypAnpStufe() {
		return (IHausratDeckungsTypAnpStufe) getProductCmptGeneration();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setHausratDeckungsTyp(IHausratDeckungsTyp hausratDeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults) {
		setProductComponent(hausratDeckungsTyp);
		if (initPropertiesWithConfiguratedDefaults) {
			initialize();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void effectiveFromHasChanged() {
		super.effectiveFromHasChanged();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Calendar getEffectiveFromAsCalendar() {
		IModelObject parent = getParentModelObject();
		if (parent instanceof IConfigurableModelObject) {
			return ((IConfigurableModelObject) parent).getEffectiveFromAsCalendar();
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void initPropertiesFromXml(Map<String, String> propMap, IRuntimeRepository productRepository) {
		super.initPropertiesFromXml(propMap, productRepository);
		if (propMap.containsKey("jahresbasisbeitrag")) {
			jahresbasisbeitrag = Money.valueOf(propMap.get("jahresbasisbeitrag"));
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected AbstractModelObject createChildFromXml(Element childEl) {
		AbstractModelObject newChild = super.createChildFromXml(childEl);
		if (newChild != null) {
			return newChild;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObjectDelta computeDelta(IModelObject otherObject, IDeltaComputationOptions options) {
		ModelObjectDelta delta = ModelObjectDelta.newDelta(this, otherObject, options);
		if (!HausratDeckung.class.isAssignableFrom(otherObject.getClass())) {
			return delta;
		}
		HausratDeckung otherHausratDeckung = (HausratDeckung) otherObject;
		delta.checkPropertyChange(IHausratDeckung.PROPERTY_JAHRESBASISBEITRAG, jahresbasisbeitrag,
				otherHausratDeckung.jahresbasisbeitrag, options);
		return delta;
	}

	/**
	 * Interne Kopiermethode mit einer {@link Map} der bisher kopierten
	 * Instanzen
	 * 
	 * @param copyMap
	 *            die Map enthaelt die bisher kopierten Instanzen
	 * 
	 * @generated
	 */
	public IModelObject newCopyInternal(Map<IModelObject, IModelObject> copyMap) {
		throw new RuntimeException(
				"This method has to be abstract. It needs to have an empty body because of a bug in JMerge.");
	}

	/**
	 * Diese Methode setzt alle Werte in der Kopie (copy) auf die Werte aus
	 * diesem Objekt. Kopierte Assoziationen werden zur copyMap hinzugefügt.
	 * 
	 * @param copy
	 *            Das kopierte Object
	 * @param copyMap
	 *            Eine Map mit kopierten assoziierten Objekten
	 * 
	 * @generated
	 */
	protected void copyProperties(IModelObject copy, Map<IModelObject, IModelObject> copyMap) {
		HausratDeckung concreteCopy = (HausratDeckung) copy;
		concreteCopy.jahresbasisbeitrag = jahresbasisbeitrag;
	}

	/**
	 * Interne Methode zum setzen kopierter Assoziationen. Wenn das Ziel der
	 * Assoziation kopiert wurde, wird die Assoziation auf die neue Kopie
	 * gesetzt, ansonsten bleibt die Assoziation unveraendert. Die Methode ruft
	 * ausserdem {@link #copyAssociationsInternal(IModelObject, Map)} in allen
	 * durch Komposition verknuepften Instanzen auf.
	 * 
	 * @param abstractCopy
	 *            die Kopie dieser PolicyCmpt
	 * @param copyMap
	 *            die Map mit den kopierten Instanzen
	 * 
	 * @generated
	 */
	public void copyAssociationsInternal(IModelObject abstractCopy, Map<IModelObject, IModelObject> copyMap) {
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public boolean accept(IModelObjectVisitor visitor) {
		if (!visitor.visit(this)) {
			return false;
		}
		return true;
	}

	/**
	 * Validierung von Objekten der Klasse HausratDeckung. Gibt
	 * <code>true</code> zurueck, wenn dieses Objekt mit der Validierung
	 * fortfahren soll, <code>false</code> sonst.
	 * 
	 * @generated
	 */
	@Override
	public boolean validateSelf(MessageList ml, IValidationContext context) {
		if (!super.validateSelf(ml, context)) {
			return STOP_VALIDATION;
		}
		return CONTINUE_VALIDATION;
	}

	/**
	 * Validierung von abhaengigen Objekten fuer Instanzen der Klasse
	 * HausratDeckung.
	 * 
	 * @generated
	 */
	@Override
	public void validateDependants(MessageList ml, IValidationContext context) {
		super.validateDependants(ml, context);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Money getJahresbasisbeitrag() {
		return jahresbasisbeitrag;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated NOT
	 */
	@Override
	public void berechneJahresbasisbeitrag() {
		jahresbasisbeitrag = berechneJahresbasisbeitragInternal();
	}

	protected abstract Money berechneJahresbasisbeitragInternal();

}
