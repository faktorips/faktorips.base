/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.values.Money;

/**
 * Published Interface von HausratGrunddeckung.
 * 
 * @generated
 */
public interface IHausratGrunddeckung extends IHausratDeckung {

	/**
	 * Diese Konstante enthaelt den Namen der Property beitrag
	 * 
	 * @generated
	 */
	public final static String PROPERTY_BEITRAG = "beitrag";

	/**
	 * Gibt den Wert des Attributs beitrag zurueck.
	 * 
	 * @generated
	 */
	public Money getBeitrag();

	/**
	 * Gibt d. HausratGrunddeckungsTyp zurueck, welches d. HausratGrunddeckung
	 * konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp();

	/**
	 * Setzt d. neue HausratGrunddeckungsTyp.
	 * 
	 * @param hausratGrunddeckungsTyp
	 *            D. neue HausratGrunddeckungsTyp.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> falls die Eigenschaften mit den Defaultwerte
	 *            aus d. HausratGrunddeckungsTyp belegt werden sollen.
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckungsTyp(IHausratGrunddeckungsTyp hausratGrunddeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Gibt d. Anpassungsstufe zurueck, welches d. HausratGrunddeckungsTyp
	 * konfiguriert. D. Anpassungsstufe wird anhand des Wirksamkeitsdatum
	 * ermittelt.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTypAnpStufe getHausratGrunddeckungsTypAnpStufe();

}
