/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IConfigurableModelObject;
import org.faktorips.runtime.IDeltaSupport;
import org.faktorips.runtime.ICopySupport;
import org.faktorips.runtime.IVisitorSupport;
import org.faktorips.values.Money;
import org.faktorips.runtime.IDependantObject;

/**
 * Published Interface von HausratDeckung.
 * 
 * @generated
 */
public interface IHausratDeckung extends IConfigurableModelObject, IDeltaSupport, ICopySupport, IVisitorSupport,
		IDependantObject {

	/**
	 * Diese Konstante enthaelt den Namen der Property jahresbasisbeitrag
	 * 
	 * @generated
	 */
	public final static String PROPERTY_JAHRESBASISBEITRAG = "jahresbasisbeitrag";

	/**
	 * Diese Konstante enthaelt den Name der Beziehung hausratVertrag.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATVERTRAG = "hausratVertrag";

	/**
	 * Gibt d. HausratDeckungsTyp zurueck, welches d. HausratDeckung
	 * konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratDeckungsTyp getHausratDeckungsTyp();

	/**
	 * Setzt d. neue HausratDeckungsTyp.
	 * 
	 * @param hausratDeckungsTyp
	 *            D. neue HausratDeckungsTyp.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> falls die Eigenschaften mit den Defaultwerte
	 *            aus d. HausratDeckungsTyp belegt werden sollen.
	 * 
	 * @generated
	 */
	public void setHausratDeckungsTyp(IHausratDeckungsTyp hausratDeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Gibt d. Anpassungsstufe zurueck, welches d. HausratDeckungsTyp
	 * konfiguriert. D. Anpassungsstufe wird anhand des Wirksamkeitsdatum
	 * ermittelt.
	 * 
	 * @generated
	 */
	public IHausratDeckungsTypAnpStufe getHausratDeckungsTypAnpStufe();

	/**
	 * Gibt den Wert des Attributs jahresbasisbeitrag zurueck.
	 * 
	 * @generated
	 */
	public Money getJahresbasisbeitrag();

	/**
	 * Gibt das referenzierte HausratVertrag-Objekt zurueck.
	 * 
	 * @generated
	 */
	public IHausratVertrag getHausratVertrag();

	/**
	 * @generated
	 */
	public void berechneJahresbasisbeitrag();

}
