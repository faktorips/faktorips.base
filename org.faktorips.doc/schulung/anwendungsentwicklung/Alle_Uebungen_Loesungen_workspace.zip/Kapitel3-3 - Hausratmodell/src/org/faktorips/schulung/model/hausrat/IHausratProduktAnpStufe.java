/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IProductComponentGeneration;
import org.faktorips.values.Money;
import org.faktorips.valueset.OrderedValueSet;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.valueset.MoneyRange;
import org.faktorips.valueset.IntegerRange;

/**
 * Die Anpassungsstufe von HausratProdukt.
 * 
 * @generated
 */
public interface IHausratProduktAnpStufe extends IProductComponentGeneration {

	/**
	 * Diese Konstante enthaelt den Namen der Property produktname
	 * 
	 * @generated
	 */
	public final static String PROPERTY_PRODUKTNAME = "produktname";
	/**
	 * Diese Konstante enthaelt den Namen der Property vertriebsname
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERTRIEBSNAME = "vertriebsname";

	/**
	 * Diese Konstante enthaelt den Namen der Property vorschlagVersSummeProQm
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VORSCHLAGVERSSUMMEPROQM = "vorschlagVersSummeProQm";

	/**
	 * Gibt den Wert der Eigenschaft produktname zurueck.
	 * 
	 * @generated
	 */
	public String getProduktname();

	/**
	 * Gibt den Wert der Eigenschaft vertriebsname zurueck.
	 * 
	 * @generated
	 */
	public String getVertriebsname();

	/**
	 * Gibt den Wert der Eigenschaft vorschlagVersSummeProQm zurueck.
	 * 
	 * @generated
	 */
	public Money getVorschlagVersSummeProQm();

	/**
	 * Gibt den Defaultwert fuer die Eigenschaft zahlweise zurueck.
	 * 
	 * @generated
	 */
	public Integer getDefaultValueZahlweise();

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribute zahlweise zurueck.
	 * 
	 * @generated
	 */
	public OrderedValueSet<Integer> getAllowedValuesForZahlweise(IValidationContext context);

	/**
	 * Gibt den Defaultwert fuer die Eigenschaft wohnflaeche zurueck.
	 * 
	 * @generated
	 */
	public Integer getDefaultValueWohnflaeche();

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribut wohnflaeche zurueck.
	 * 
	 * @generated
	 */
	public IntegerRange getRangeForWohnflaeche(IValidationContext context);

	/**
	 * Gibt den Defaultwert fuer die Eigenschaft versSumme zurueck.
	 * 
	 * @generated
	 */
	public Money getDefaultValueVersSumme();

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribut versSumme zurueck.
	 * 
	 * @generated
	 */
	public MoneyRange getRangeForVersSumme(IValidationContext context);

	/**
	 * Gibt d HausratProdukt zurueck, zu dem diese Anpassungsstufe gehoert.
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProdukt();

}
