/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IProductComponentGeneration;

/**
 * Die Anpassungsstufe von HausratGrunddeckungsTyp.
 * 
 * @generated
 */
public interface IHausratGrunddeckungsTypAnpStufe extends IProductComponentGeneration {

	/**
	 * Gibt d HausratGrunddeckungsTyp zurueck, zu dem diese Anpassungsstufe
	 * gehoert.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp();

}
