/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.Table;
import java.util.List;
import java.util.ArrayList;
import org.faktorips.runtime.IRuntimeRepository;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import org.faktorips.values.Decimal;

/**
 * Diese Klasse implementiert eine Read-Only In-Memory-Tabelle. Auf die Daten
 * der Tabelle kann ueber Finder-Methoden zugegriffen werden.
 * 
 * @generated
 */
public class TariftabelleHausrat extends Table {

	/**
	 * Membervariable die Keys auf Tabellenzeilen abbildet.
	 * 
	 * @generated
	 */
	private Map<UniqueKey0, TariftabelleHausratRow> key0Map;

	/**
	 * Erzeugt einen leeren Tabelleninhalt.
	 * 
	 * @generated
	 */
	public TariftabelleHausrat() {
		super();
	}

	/**
	 * Erzeugt einen neuen Tabelleninhalt mit den uebergebenen Zeilen. Die Liste
	 * mit den Zeilen wird kopiert. Spaetere Aenderungen an dem Inhalt der
	 * Liste, aendern also nicht die erzeugt Tabelle. Dieser Konstruktor ist vor
	 * allem fuer die Verwendung in JUnit Tests vorgesehen, um beliebige
	 * Tabelleninhalte erzeugen zu koennen.
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public TariftabelleHausrat(List<TariftabelleHausratRow> content) {
		super();
		rows = new ArrayList(content.size());
		rows.addAll(content);
		initKeyMaps();
	}

	/**
	 * Diese Methode wird waehrend der Initialisierung verwendet. Sie fuegt eine
	 * neue Tabellenzeile hinzu.
	 * 
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void addRow(List values, IRuntimeRepository productRepository) {
		String columnValue = (String) values.get(0);
		String tarifzone = columnValue == null ? null : columnValue;
		columnValue = (String) values.get(1);
		Decimal beitragssatz = columnValue == null ? Decimal.NULL : Decimal.valueOf(columnValue);
		rows.add(new TariftabelleHausratRow(tarifzone, beitragssatz));
	}

	/**
	 * Initialisiert die Maps dieser Tabelle. Diese werden von den
	 * Finder-Methoden dieser Klasse verwendet.
	 * 
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void initKeyMaps() {
		key0Map = new HashMap<UniqueKey0, TariftabelleHausratRow>(rows.size());
		for (Iterator<TariftabelleHausratRow> it = rows.iterator(); it.hasNext();) {
			TariftabelleHausratRow row = it.next();
			key0Map.put(new UniqueKey0(row.getTarifzone()), row);
		}
	}

	/**
	 * Gibt die Instanz dieser Tabellenklasse zurueck.
	 * 
	 * @generated
	 */
	public static final TariftabelleHausrat getInstance(IRuntimeRepository repository, String qualifiedTableName) {
		return (TariftabelleHausrat) repository.getTable(qualifiedTableName);
	}

	/**
	 * Gibt alle Zeilen dieser Tabelle zurueck.
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public List<TariftabelleHausratRow> getAllRows() {
		return Collections.unmodifiableList(rows);
	}

	/**
	 * Durchsucht den Inhalt dieser Tabelle nach einem Eintrag entsprechend der
	 * Suchkriterien und gibt diesen Zurueck. Null wird zurueckgegeben falls
	 * kein Eintrag gefunden wird.
	 * 
	 * @generated
	 */
	public TariftabelleHausratRow findRow(String tarifzone) {
		if (tarifzone == null) {
			return null;
		}
		TariftabelleHausratRow returnValue = key0Map.get(new UniqueKey0(tarifzone));
		return returnValue;
	}

	/**
	 * Durchsucht den Inhalt dieser Tabelle nach einem Eintrag entsprechend der
	 * Suchkriterien und gibt diesen Zurueck. Eine 'Null-Row' wird
	 * zurueckgegeben, falls kein Eintrag gefunden wird.
	 * 
	 * @generated
	 */
	public TariftabelleHausratRow findRowNullRowReturnedForEmtpyResult(String tarifzone) {
		if (tarifzone == null) {
			return TariftabelleHausratRow.NULL_ROW;
		}
		TariftabelleHausratRow returnValue = key0Map.get(new UniqueKey0(tarifzone));
		if (returnValue == null) {
			return TariftabelleHausratRow.NULL_ROW;
		}
		return returnValue;
	}

	/**
	 * Die Objekte dieser Klasse werden als Hash-Keys verwendent. Fuer jeden
	 * Zugriffsschluessel hat diese Klasse eine eigene java.util.Map.
	 * 
	 * @generated
	 */
	private static final class UniqueKey0 {

		/**
		 * @generated
		 */
		private String tarifzone;
		/**
		 * Cached hashcode.
		 * 
		 * @generated
		 */
		private int hashCode;

		/**
		 * Erzeugt eine neue Instanz mit den angegebenen Parameterwerten.
		 * 
		 * @generated
		 */
		private UniqueKey0(String tarifzone) {
			this.tarifzone = tarifzone;
			hashCode = calculateHashCode();
		}

		/**
		 * @generated
		 */
		private int calculateHashCode() {
			int result = 17;
			result = 37 * result + tarifzone.hashCode();
			return result;
		}

		/**
		 * Ueberschreibt die Methode der Vaterklasse und vergleicht die Werte
		 * der Instanzvariablen auf ihre Gleichheit.
		 * 
		 * @generated
		 */
		@Override
		public boolean equals(Object o) {
			if (o instanceof UniqueKey0) {
				UniqueKey0 other = (UniqueKey0) o;
				return tarifzone.equals(other.tarifzone);
			}
			return false;
		}

		/**
		 * Ueberschreibt die Methode der Vaterklasse und erzeugt einen Hash-Code
		 * basierend auf den Werten der Attribute dieser Klasse.
		 * 
		 * @generated
		 */
		@Override
		public int hashCode() {
			return hashCode;
		}

	}

}
