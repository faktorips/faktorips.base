/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.faktorips.runtime.IDeltaComputationOptions;
import org.faktorips.runtime.IModelObject;
import org.faktorips.runtime.IModelObjectDelta;
import org.faktorips.runtime.IModelObjectVisitor;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.runtime.MessageList;
import org.faktorips.runtime.internal.AbstractConfigurableModelObject;
import org.faktorips.runtime.internal.AbstractModelObject;
import org.faktorips.runtime.internal.ModelObjectDelta;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTyp;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTypAnpStufe;
import org.faktorips.values.Decimal;
import org.faktorips.values.Money;
import org.w3c.dom.Element;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.faktorips.runtime.IConfigurableModelObject;

/**
 * @generated
 */
public class HausratGrunddeckung extends AbstractConfigurableModelObject implements IHausratGrunddeckung {

	/**
	 * Membervariable fuer jahresbasisbeitrag.
	 * 
	 * @generated
	 */
	private Money jahresbasisbeitrag = Money.NULL;

	/**
	 * Membervariable fuer das Parent-Objekt: HausratVertrag
	 * 
	 * @generated
	 */
	private HausratVertrag hausratVertrag;

	/**
	 * Erzeugt eine neue Instanz von HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public HausratGrunddeckung() {
		super();
	}

	/**
	 * Erzeugt eine neue Instanz von HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public HausratGrunddeckung(IHausratGrunddeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Money getJahresbasisbeitrag() {
		return jahresbasisbeitrag;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratVertrag getHausratVertrag() {
		return hausratVertrag;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated NOT
	 */
	@Override
	public void berechneJahresbasisbeitrag() {
		HausratGrunddeckungsTypAnpStufe gen = (HausratGrunddeckungsTypAnpStufe) getHausratGrunddeckungsTypAnpStufe();
		if (gen == null) {
			jahresbasisbeitrag = Money.NULL;
			return;
		}
		TariftabelleHausrat tabelle = gen.getTariftabelle();
		TariftabelleHausratRow row = tabelle.findRow(getHausratVertrag().getTarifzone());
		if (row == null) {
			jahresbasisbeitrag = Money.NULL;
			return;
		}
		Money versSumme = getHausratVertrag().getVersSumme();
		Decimal beitragssatz = row.getBeitragssatz();
		jahresbasisbeitrag = versSumme.divide(1000, BigDecimal.ROUND_HALF_UP).multiply(beitragssatz,
				BigDecimal.ROUND_HALF_UP);
	}

	/**
	 * Initialisiert produktrelevante Attribute mit ihren Vorgabewerten.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initialize() {

		// begin-user-code
		// end-user-code
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp() {
		return (IHausratGrunddeckungsTyp) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratGrunddeckungsTypAnpStufe getHausratGrunddeckungsTypAnpStufe() {
		return (IHausratGrunddeckungsTypAnpStufe) getProductCmptGeneration();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setHausratGrunddeckungsTyp(IHausratGrunddeckungsTyp hausratGrunddeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults) {
		setProductComponent(hausratGrunddeckungsTyp);
		if (initPropertiesWithConfiguratedDefaults) {
			initialize();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void effectiveFromHasChanged() {
		super.effectiveFromHasChanged();
	}

	/**
	 * Gibt den im Produktbausteine referenzierten Tabelleninhalt der Rolle
	 * Tariftabelle zurueck.
	 * 
	 * @generated
	 */
	public TariftabelleHausrat getTariftabelle() {
		HausratGrunddeckungsTypAnpStufe productCmpt = (HausratGrunddeckungsTypAnpStufe) getHausratGrunddeckungsTypAnpStufe();
		if (productCmpt == null) {
			return null;
		}
		return productCmpt.getTariftabelle();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Calendar getEffectiveFromAsCalendar() {
		IModelObject parent = getParentModelObject();
		if (parent instanceof IConfigurableModelObject) {
			return ((IConfigurableModelObject) parent).getEffectiveFromAsCalendar();
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObject getParentModelObject() {
		if (hausratVertrag != null) {
			return hausratVertrag;
		}
		return null;
	}

	/**
	 * @generated
	 */
	public void setHausratVertragInternal(IHausratVertrag newParent) {
		if (getHausratVertrag() == newParent) {
			return;
		}
		IModelObject parent = getParentModelObject();
		if (newParent != null && parent != null) {
			throw new RuntimeException(
					"HausratGrunddeckung kann nicht dem Parent Objekt der Klasse HausratVertrag hinzugefuegt werden, da das Objekt bereits einem anderen Parent Objekt zugeordnet ist.");
		}
		hausratVertrag = (HausratVertrag) newParent;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void initPropertiesFromXml(Map<String, String> propMap, IRuntimeRepository productRepository) {
		super.initPropertiesFromXml(propMap, productRepository);
		if (propMap.containsKey("jahresbasisbeitrag")) {
			this.jahresbasisbeitrag = Money.valueOf(propMap.get("jahresbasisbeitrag"));
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected AbstractModelObject createChildFromXml(Element childEl) {
		AbstractModelObject newChild = super.createChildFromXml(childEl);
		if (newChild != null) {
			return newChild;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObjectDelta computeDelta(IModelObject otherObject, IDeltaComputationOptions options) {
		ModelObjectDelta delta = ModelObjectDelta.newDelta(this, otherObject, options);
		if (!HausratGrunddeckung.class.isAssignableFrom(otherObject.getClass())) {
			return delta;
		}
		HausratGrunddeckung otherHausratGrunddeckung = (HausratGrunddeckung) otherObject;
		delta.checkPropertyChange(IHausratGrunddeckung.PROPERTY_JAHRESBASISBEITRAG, jahresbasisbeitrag,
				otherHausratGrunddeckung.jahresbasisbeitrag, options);
		return delta;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObject newCopy() {
		Map<IModelObject, IModelObject> copyMap = new HashMap<IModelObject, IModelObject>();
		HausratGrunddeckung newCopy = (HausratGrunddeckung) newCopyInternal(copyMap);
		copyAssociationsInternal(newCopy, copyMap);
		return newCopy;
	}

	/**
	 * Interne Kopiermethode mit einer {@link Map} der bisher kopierten
	 * Instanzen
	 * 
	 * @param copyMap
	 *            die Map enthaelt die bisher kopierten Instanzen
	 * 
	 * @generated
	 */
	public IModelObject newCopyInternal(Map<IModelObject, IModelObject> copyMap) {
		HausratGrunddeckung newCopy = (HausratGrunddeckung) copyMap.get(this);
		if (newCopy == null) {
			newCopy = new HausratGrunddeckung();
			newCopy.copyProductCmptAndGenerationInternal(this);
			copyProperties(newCopy, copyMap);
		}
		return newCopy;
	}

	/**
	 * Diese Methode setzt alle Werte in der Kopie (copy) auf die Werte aus
	 * diesem Objekt. Kopierte Assoziationen werden zur copyMap hinzugefügt.
	 * 
	 * @param copy
	 *            Das kopierte Object
	 * @param copyMap
	 *            Eine Map mit kopierten assoziierten Objekten
	 * 
	 * @generated
	 */
	protected void copyProperties(IModelObject copy, Map<IModelObject, IModelObject> copyMap) {
		HausratGrunddeckung concreteCopy = (HausratGrunddeckung) copy;
		concreteCopy.jahresbasisbeitrag = jahresbasisbeitrag;
	}

	/**
	 * Interne Methode zum setzen kopierter Assoziationen. Wenn das Ziel der
	 * Assoziation kopiert wurde, wird die Assoziation auf die neue Kopie
	 * gesetzt, ansonsten bleibt die Assoziation unveraendert. Die Methode ruft
	 * ausserdem {@link #copyAssociationsInternal(IModelObject, Map)} in allen
	 * durch Komposition verknuepften Instanzen auf.
	 * 
	 * @param abstractCopy
	 *            die Kopie dieser PolicyCmpt
	 * @param copyMap
	 *            die Map mit den kopierten Instanzen
	 * 
	 * @generated
	 */
	public void copyAssociationsInternal(IModelObject abstractCopy, Map<IModelObject, IModelObject> copyMap) {
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public boolean accept(IModelObjectVisitor visitor) {
		if (!visitor.visit(this)) {
			return false;
		}
		return true;
	}

	/**
	 * Validierung von Objekten der Klasse HausratGrunddeckung. Gibt
	 * <code>true</code> zurueck, wenn dieses Objekt mit der Validierung
	 * fortfahren soll, <code>false</code> sonst.
	 * 
	 * @generated
	 */
	@Override
	public boolean validateSelf(MessageList ml, IValidationContext context) {
		if (!super.validateSelf(ml, context)) {
			return STOP_VALIDATION;
		}
		return CONTINUE_VALIDATION;
	}

	/**
	 * Validierung von abhaengigen Objekten fuer Instanzen der Klasse
	 * HausratGrunddeckung.
	 * 
	 * @generated
	 */
	@Override
	public void validateDependants(MessageList ml, IValidationContext context) {
		super.validateDependants(ml, context);
	}

}
