/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IDeltaSupport;
import org.faktorips.runtime.ICopySupport;
import org.faktorips.runtime.IVisitorSupport;
import org.faktorips.runtime.IConfigurableModelObject;

/**
 * Published Interface von HausratGrunddeckung.
 * 
 * @generated
 */
public interface IHausratGrunddeckung extends IConfigurableModelObject, IDeltaSupport, ICopySupport, IVisitorSupport {

	/**
	 * Gibt d. HausratGrunddeckungsTyp zurueck, welches d. HausratGrunddeckung
	 * konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp();

	/**
	 * Setzt d. neue HausratGrunddeckungsTyp.
	 * 
	 * @param hausratGrunddeckungsTyp
	 *            D. neue HausratGrunddeckungsTyp.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> falls die Eigenschaften mit den Defaultwerte
	 *            aus d. HausratGrunddeckungsTyp belegt werden sollen.
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckungsTyp(IHausratGrunddeckungsTyp hausratGrunddeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Gibt d. Anpassungsstufe zurueck, welches d. HausratGrunddeckungsTyp
	 * konfiguriert. D. Anpassungsstufe wird anhand des Wirksamkeitsdatum
	 * ermittelt.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTypAnpStufe getHausratGrunddeckungsTypAnpStufe();

}
