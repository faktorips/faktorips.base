package org.faktorips.schulung.model.internal.hausrat;

import static org.junit.Assert.assertEquals;

import java.util.GregorianCalendar;

import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.faktorips.values.Money;
import org.junit.Test;

public class HausratVertragTest {

	@Test
	public void testGetTarifzone() {
		TestContent testContent = new TestContent();
		IRuntimeRepository testRepository = testContent.getRepository();
		IHausratProdukt testProdukt = (IHausratProdukt)testRepository.getProductComponent("TestProdukt 2009-01");
		IHausratVertrag hausratVertrag = testProdukt.createHausratVertrag();
		hausratVertrag.setWirksamAb(new GregorianCalendar(2009, 0, 1));
		assertEquals("I", hausratVertrag.getTarifzone());
	}

	@Test
	public void testGetVorschlagVersSumme() {
		TestContent testContent = new TestContent();
		IRuntimeRepository testRepository = testContent.getRepository();
		IHausratProdukt testProdukt = (IHausratProdukt)testRepository.getProductComponent("TestProdukt 2009-01");
		IHausratVertrag hausratVertrag = testProdukt.createHausratVertrag();
		hausratVertrag.setWirksamAb(new GregorianCalendar(2009, 0, 1));

		hausratVertrag.setWohnflaeche(0);
		assertEquals(Money.euro(0), hausratVertrag.getVorschlagVersSumme());

		hausratVertrag.setWohnflaeche(80);
		assertEquals(Money.euro(80 * 650), hausratVertrag.getVorschlagVersSumme());
	}

}
