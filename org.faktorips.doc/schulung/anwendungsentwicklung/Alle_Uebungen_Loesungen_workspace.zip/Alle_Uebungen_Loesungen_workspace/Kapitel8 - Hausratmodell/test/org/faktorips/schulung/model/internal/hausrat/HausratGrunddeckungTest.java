package org.faktorips.schulung.model.internal.hausrat;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.GregorianCalendar;

import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTyp;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import org.faktorips.schulung.model.hausrat.IHausratProduktGen;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.faktorips.schulung.model.hausrat.Zahlweise;
import org.faktorips.values.Decimal;
import org.faktorips.values.Money;
import org.junit.Test;

public class HausratGrunddeckungTest {

	@Test
	public void testGetBeitragWithInMemoryRepository() throws Exception {
		TestContent testContent = new TestContent();
		IRuntimeRepository testRepository = testContent.getRepository();
		IHausratProdukt testProdukt = (IHausratProdukt)testRepository.getProductComponent("TestProdukt 2009-01");
		IHausratVertrag hausratVertrag = testProdukt.createHausratVertrag();
		hausratVertrag.setWirksamAb(new GregorianCalendar(2009, 0, 1));

		IHausratProduktGen hausratProduktGen = hausratVertrag.getHausratProduktGen();
		IHausratGrunddeckungsTyp hausratGrunddeckungsTyp = hausratProduktGen.getHausratGrunddeckungsTyp();
		IHausratGrunddeckung hausratGrunddeckung = hausratVertrag.newHausratGrunddeckung(hausratGrunddeckungsTyp);

		hausratVertrag.setVersSumme(Money.euro(10000));

		hausratVertrag.setZahlweise((Zahlweise) testRepository.getEnumValue(Zahlweise.class.getName() + "#H"));
		hausratGrunddeckung.berechneJahresbasisbeitrag();

		// 10.000 / 1000 * 0,5 / 2
		assertEquals(Money.euro(2, 50), hausratGrunddeckung.getBeitrag());
	}


	@Test
	public void testGetBeitragWithMocks() {

		HausratVertrag mockedVertrag = mock(HausratVertrag.class);

		when(mockedVertrag.getVersSumme()).thenReturn(Money.euro(10000));
		when(mockedVertrag.getTarifzone()).thenReturn("I");

		HausratGrunddeckungsTypGen mockedGrunddeckungsTypGen = mock(HausratGrunddeckungsTypGen.class);
		TariftabelleHausrat mockedTabelle = mock(TariftabelleHausrat.class);
		TariftabelleHausratRow mockedRow = mock(TariftabelleHausratRow.class);
		when(mockedRow.getBeitragssatz()).thenReturn(Decimal.valueOf(0.5d));
		when(mockedTabelle.findRow(anyString())).thenReturn(mockedRow);
		when(mockedGrunddeckungsTypGen.getTariftabelle()).thenReturn(mockedTabelle);


		HausratGrunddeckung hausratGrunddeckung = new HausratGrunddeckung();
		hausratGrunddeckung.setProductCmptGeneration(mockedGrunddeckungsTypGen);
		hausratGrunddeckung.setHausratVertragInternal(mockedVertrag);

		// Jahresbasisbeitrag = 10.000 EUR / 1000 * 0,5 = 5,00 EUR
		when(mockedVertrag.getZahlweise()).thenReturn(new Zahlweise("H", "Halbj�hrlich", 2));
		hausratGrunddeckung.berechneJahresbasisbeitrag();

		// Beitrag = 5,00 EUR / 2
		assertEquals(Money.euro(2, 50), hausratGrunddeckung.getBeitrag());

		// Beitrag = 5,00 EUR / 1
		when(mockedVertrag.getZahlweise()).thenReturn(new Zahlweise("J", "J�hrlich", 1));
		assertEquals(Money.euro(5), hausratGrunddeckung.getBeitrag());

		// Jahresbasisbeitrag = 10.000 EUR / 1000 * 1,1 = 11,00 EUR
		when(mockedRow.getBeitragssatz()).thenReturn(Decimal.valueOf(1.1d));
		hausratGrunddeckung.berechneJahresbasisbeitrag();

		// Beitrag = 11,00 EUR * 1.0
		assertEquals(Money.euro(11), hausratGrunddeckung.getBeitrag());

	}

}
