package org.faktorips.schulung.model.internal.hausrat;

import java.util.ArrayList;
import java.util.List;

import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.runtime.InMemoryRuntimeRepository;
import org.faktorips.runtime.internal.DateTime;
import org.faktorips.schulung.model.hausrat.Zahlweise;
import org.faktorips.values.Decimal;
import org.faktorips.values.Money;

public class TestContent {

	private InMemoryRuntimeRepository localRepository = new InMemoryRuntimeRepository();

	/**
	 * Die Ableitung der Tarifzonentabelle ist notwendig um sie mit
	 * Beispielinhalt zu f�llen.
	 */
	private static class TestTarifzonentabelle extends Tarifzonentabelle {
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public TestTarifzonentabelle() {
			super();
			rows = new ArrayList();
			rows.add(new TarifzonentabelleRow("10000", "19999", "I"));
			rows.add(new TarifzonentabelleRow("20000", "29999", "II"));
			rows.add(new TarifzonentabelleRow("30000", "39999", "III"));
			initKeyMaps();
		}
	}

	/**
	 * Die Ableitung der Tariftabelle ist notwendig um sie mit
	 * Beispielinhalt zu f�llen.
	 */
	private static class TestTariftabelle extends TariftabelleHausrat {
	@SuppressWarnings({ "unchecked", "rawtypes" })
		public TestTariftabelle() {
			super();
			rows = new ArrayList();
			rows.add(new TariftabelleHausratRow("I", Decimal.valueOf("0.5")));
			rows.add(new TariftabelleHausratRow("II", Decimal.valueOf("0.7")));
			rows.add(new TariftabelleHausratRow("III", Decimal.valueOf("0.9")));
			initKeyMaps();
		}
	}

	private class TestHausratGrunddeckungsTypGen extends HausratGrunddeckungsTypGen {

		private String tabellenName;

		public TestHausratGrunddeckungsTypGen(HausratGrunddeckungsTyp productCmpt) {
			super(productCmpt);
		}

		public void setTariftabellenName(String tabellenName) {
			this.tabellenName = tabellenName;
		}

		@Override
		public TariftabelleHausrat getTariftabelle() {
			return (TariftabelleHausrat) localRepository.getTable(tabellenName);
		}
	}

	private void initialize() {
		// Erstellen eines Test-Produktbausteins
		HausratProdukt testProdukt = new HausratProdukt(localRepository,
				"TestProdukt 2009-01", "TestProdukt", "2009-01");
		HausratProduktGen testProduktGen = new HausratProduktGen(testProdukt);
		testProduktGen.setValidFrom(DateTime.parseIso("2009-01-01"));
		testProduktGen.setProduktname("TestProdukt");
		testProduktGen.setVorschlagVersSummeProQm(Money.euro(650));

		// Hinzuf�gen der Anpassungstufe zum Repository. Es wird automatisch
		// auch der Produktbaustein hinzugef�gt
		localRepository.putProductCmptGeneration(testProduktGen);

		// Erstellen eines Test-Grunddeckungsbausteins
		HausratGrunddeckungsTyp testDeckungstyp = new HausratGrunddeckungsTyp(
		localRepository, "TestDeckung 2009-01", "TestDeckung", "2009-01");
		TestHausratGrunddeckungsTypGen testDeckungGen = new TestHausratGrunddeckungsTypGen(testDeckungstyp);
		testDeckungGen.setValidFrom(DateTime.parseIso("2009-01-01"));
		// Der Tabellenname muss der gleiche sein unter dem man die
		// Testtariftabelle im Repository abspeichert. Siehe unten
		testDeckungGen.setTariftabellenName("Tariftabelle");
		testProduktGen.setHausratGrunddeckungsTyp(testDeckungstyp);

		// Hinzuf�gen der Anpassungstufe zum Repository. Es wird automatisch
		// auch der Baustein hinzugef�gt
		localRepository.putProductCmptGeneration(testDeckungGen);

		// Hinzuf�gen der Testtarifzonentabelle zum Repository
		localRepository.putTable(new TestTarifzonentabelle());

		// Hinzuf�gen der Testtariftabelle zum Repository. Wichtig ist, da es
		// eine Tabelle mit multiplen Inhalten ist, muss der Name der Tabelle
		// angegeben werden, unter dem die Tabelle im Repository gespeichert
		// wird.
		localRepository.putTable(new TestTariftabelle(), "Tariftabelle");

		// Hinzuf�gen der Enum-Werte f�r die Zahlweise zum Repository
		List<Zahlweise> zahlweisen = new ArrayList<Zahlweise>();
		zahlweisen.add(new Zahlweise("J", "J�hrlich", 1));
		zahlweisen.add(new Zahlweise("H", "Halbj�hrlich", 2));
		zahlweisen.add(new Zahlweise("Q", "Quartalsweise", 4));
		zahlweisen.add(new Zahlweise("M", "Monatlich", 12));
		localRepository.putEnumValues(Zahlweise.class, zahlweisen);
	}

	public IRuntimeRepository getRepository() {
		localRepository = new InMemoryRuntimeRepository();
		initialize();
		return localRepository;
	}
}
