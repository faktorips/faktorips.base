/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import java.util.Calendar;

/**
 * Published Interface of HausratZusatzdeckungsTyp.
 * 
 * @generated
 */
public interface IHausratZusatzdeckungsTyp extends IHausratDeckungsTyp {

	/**
	 * Returns the generation that is valid for the given effective date.
	 * Returns <code>null</code>, if no valid generation exists for the given
	 * date.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTypGen getHausratZusatzdeckungsTypGen(
			Calendar effectiveDate);

	/**
	 * Creates a new HausratZusatzdeckung that is configured.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung createHausratZusatzdeckung();

}
