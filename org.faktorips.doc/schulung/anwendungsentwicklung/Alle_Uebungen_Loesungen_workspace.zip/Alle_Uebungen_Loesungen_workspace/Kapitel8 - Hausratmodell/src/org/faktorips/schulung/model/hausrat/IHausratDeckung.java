/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IConfigurableModelObject;
import org.faktorips.runtime.IDeltaSupport;
import org.faktorips.runtime.ICopySupport;
import org.faktorips.runtime.IVisitorSupport;
import org.faktorips.values.Money;
import org.faktorips.runtime.IDependantObject;

/**
 * Published Interface for HausratDeckung.
 * 
 * @generated
 */
public interface IHausratDeckung extends IConfigurableModelObject,
		IDeltaSupport, ICopySupport, IVisitorSupport, IDependantObject {

	/**
	 * The name of the property jahresbasisbeitrag.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_JAHRESBASISBEITRAG = "jahresbasisbeitrag";

	/**
	 * The name of the association hausratVertrag.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATVERTRAG = "hausratVertrag";

	/**
	 * Returns the HausratDeckungsTyp that configures this object.
	 * 
	 * @generated
	 */
	public IHausratDeckungsTyp getHausratDeckungsTyp();

	/**
	 * Sets the new HausratDeckungsTyp that configures this object.
	 * 
	 * @param hausratDeckungsTyp
	 *            The new HausratDeckungsTyp.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> if the properties should be initialized with
	 *            the defaults defined in the HausratDeckungsTyp.
	 * 
	 * @generated
	 */
	public void setHausratDeckungsTyp(IHausratDeckungsTyp hausratDeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Returns the generation that configures this object and is valid at the
	 * objects effective date.
	 * 
	 * @generated
	 */
	public IHausratDeckungsTypGen getHausratDeckungsTypGen();

	/**
	 * Returns the jahresbasisbeitrag.
	 * 
	 * @generated
	 */
	public Money getJahresbasisbeitrag();

	/**
	 * Returns the referenced HausratVertrag.
	 * 
	 * @generated
	 */
	public IHausratVertrag getHausratVertrag();

	/**
	 * @generated
	 */
	public void berechneJahresbasisbeitrag();

}
