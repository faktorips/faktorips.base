/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IProductComponent;
import java.util.Calendar;

/**
 * Published Interface of HausratDeckungsTyp.
 * 
 * @generated
 */
public interface IHausratDeckungsTyp extends IProductComponent {

	/**
	 * Returns the generation that is valid for the given effective date.
	 * Returns <code>null</code>, if no valid generation exists for the given
	 * date.
	 * 
	 * @generated
	 */
	public IHausratDeckungsTypGen getHausratDeckungsTypGen(
			Calendar effectiveDate);

}
