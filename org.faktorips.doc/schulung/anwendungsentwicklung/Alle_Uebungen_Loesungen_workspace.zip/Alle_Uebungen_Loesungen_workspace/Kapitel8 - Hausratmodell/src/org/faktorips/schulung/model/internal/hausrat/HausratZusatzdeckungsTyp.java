/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTyp;
import org.faktorips.runtime.IRuntimeRepository;

import java.util.Calendar;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckung;
import org.faktorips.runtime.IConfigurableModelObject;

import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTypGen;

/**
 * Implementation of IHausratZusatzdeckungsTyp.
 * 
 * @generated
 */
public class HausratZusatzdeckungsTyp extends HausratDeckungsTyp implements
		IHausratZusatzdeckungsTyp {

	/**
	 * Creates a new HausratZusatzdeckungsTyp.
	 * 
	 * @generated
	 */
	public HausratZusatzdeckungsTyp(IRuntimeRepository repository, String id,
			String kindId, String versionId) {
		super(repository, id, kindId, versionId);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratZusatzdeckungsTypGen getHausratZusatzdeckungsTypGen(
			Calendar effectiveDate) {
		return (IHausratZusatzdeckungsTypGen) getRepository()
				.getProductComponentGeneration(getId(), effectiveDate);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratZusatzdeckung createHausratZusatzdeckung() {
		return new HausratZusatzdeckung(this);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IConfigurableModelObject createPolicyComponent() {
		return createHausratZusatzdeckung();
	}

}
