/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import java.io.Serializable;
import java.util.List;
import org.faktorips.runtime.IRuntimeRepository;

/**
 * @generated
 */
public final class Zahlweise implements Serializable {
	/**
	 * The SerialVersionUID.
	 * 
	 * @generated
	 */
	public static final long serialVersionUID = 1L;

	/**
	 * @generated
	 */
	private final String id;

	/**
	 * @generated
	 */
	private final String name;

	/**
	 * @generated
	 */
	private final Integer anzahlZahlungenProJahr;

	/**
	 * Creates a new instance of Zahlweise.
	 * 
	 * @generated
	 */
	protected Zahlweise(List<String> propertyValues,
			IRuntimeRepository productRepository) {
		this.id = propertyValues.get(0);
		this.name = propertyValues.get(1);
		this.anzahlZahlungenProJahr = (propertyValues.get(2) == null || propertyValues
				.get(2).equals("")) ? null : new Integer(propertyValues.get(2));
	}

	/**
	 * Creates a new instance of Zahlweise.
	 * 
	 * @generated
	 */
	public Zahlweise(String id, String name, Integer anzahlZahlungenProJahr) {
		this.id = id;
		this.name = name;
		this.anzahlZahlungenProJahr = anzahlZahlungenProJahr;
	}

	/**
	 * Returns the value of the attribute id.
	 * 
	 * @generated
	 */
	public String getId() {
		return id;
	}

	/**
	 * Returns the value of the attribute name.
	 * 
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the value of the attribute anzahlZahlungenProJahr.
	 * 
	 * @generated
	 */
	public Integer getAnzahlZahlungenProJahr() {
		return anzahlZahlungenProJahr;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public String toString() {
		return "Zahlweise: " + id + '(' + name + ')';
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Zahlweise) {
			return this.getId().equals(((Zahlweise) obj).getId());
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public int hashCode() {
		return getId().hashCode();
	}

	/**
	 * This method mustn't be deleted. This method is used (via the java
	 * reflection mechanism) by the runtime repository to identify this
	 * enumeration value.
	 * 
	 * @generated
	 */
	@SuppressWarnings("unused")
	private Object getEnumValueId() {
		return id;
	}
}
