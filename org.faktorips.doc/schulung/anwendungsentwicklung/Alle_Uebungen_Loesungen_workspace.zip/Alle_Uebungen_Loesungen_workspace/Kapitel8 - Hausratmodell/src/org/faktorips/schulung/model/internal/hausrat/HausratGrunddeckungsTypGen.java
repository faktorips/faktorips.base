/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTypGen;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTyp;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.runtime.internal.ValueToXmlHelper;
import org.faktorips.runtime.IProductComponentLink;
import org.faktorips.runtime.IProductComponent;
import java.util.List;
import org.faktorips.runtime.IllegalRepositoryModificationException;

/**
 * The implementation of IHausratGrunddeckungsTypGen.
 * 
 * @generated
 */
public class HausratGrunddeckungsTypGen extends HausratDeckungsTypGen implements
		IHausratGrunddeckungsTypGen {

	/**
	 * The name of the table used as Tariftabelle
	 * 
	 * @generated
	 */
	protected String tariftabelleName = null;

	/**
	 * Creates a new HausratGrunddeckungsTypGen.
	 * 
	 * @generated
	 */
	public HausratGrunddeckungsTypGen(HausratGrunddeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp() {
		return (IHausratGrunddeckungsTyp) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
	}

	/**
	 * @generated
	 */
	@Override
	protected void doInitTableUsagesFromXml(Map<String, Element> tableUsageMap) {
		super.doInitTableUsagesFromXml(tableUsageMap);
		Element element = null;
		element = tableUsageMap.get("Tariftabelle");
		if (element != null) {
			tariftabelleName = ValueToXmlHelper.getValueFromElement(element,
					"TableContentName");
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IProductComponentLink<? extends IProductComponent> getLink(
			String linkName, IProductComponent target) {
		return super.getLink(linkName, target);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public List<IProductComponentLink<? extends IProductComponent>> getLinks() {
		List<IProductComponentLink<? extends IProductComponent>> list = super
				.getLinks();
		return list;
	}

	/**
	 * Returns the table used as Tariftabelle.
	 * 
	 * @generated
	 */
	public TariftabelleHausrat getTariftabelle() {
		if (tariftabelleName == null) {
			return null;
		}
		return (TariftabelleHausrat) getRepository().getTable(tariftabelleName);
	}

	/**
	 * Sets the name of the table used as TariftabelleName.
	 * 
	 * @generated
	 */
	public void setTariftabelleName(String tableName) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.tariftabelleName = tableName;
	}

}
