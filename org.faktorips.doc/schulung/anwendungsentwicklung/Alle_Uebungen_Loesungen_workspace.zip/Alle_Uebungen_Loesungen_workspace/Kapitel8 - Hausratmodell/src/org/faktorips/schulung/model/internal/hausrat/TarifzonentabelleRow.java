/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

/**
 * This class represents a read-only table row. The values of this row can be
 * retrieved by the according getter methods.
 * 
 * @generated
 */
public class TarifzonentabelleRow {

	/**
	 * @generated
	 */
	public static final TarifzonentabelleRow NULL_ROW = new TarifzonentabelleRow(
			null, null, null);

	/**
	 * @generated
	 */
	private final String plzVon;
	/**
	 * @generated
	 */
	private final String plzBis;
	/**
	 * @generated
	 */
	private final String tarifzone;

	/**
	 * Creates a new table row.
	 * 
	 * @generated
	 */
	public TarifzonentabelleRow(String plzVon, String plzBis, String tarifzone) {
		this.plzVon = plzVon;
		this.plzBis = plzBis;
		this.tarifzone = tarifzone;
	}

	/**
	 * @generated
	 */
	public String getPlzVon() {
		return plzVon;
	}

	/**
	 * @generated
	 */
	public String getPlzBis() {
		return plzBis;
	}

	/**
	 * @generated
	 */
	public String getTarifzone() {
		return tarifzone;
	}

	/**
	 * @generated
	 */
	@Override
	public String toString() {
		return "" + plzVon + "|" + plzBis + "|" + tarifzone;
	}

}
