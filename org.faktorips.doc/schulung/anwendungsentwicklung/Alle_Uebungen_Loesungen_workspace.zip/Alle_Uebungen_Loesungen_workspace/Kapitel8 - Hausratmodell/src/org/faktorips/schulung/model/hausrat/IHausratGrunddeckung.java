/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.values.Money;

/**
 * Published Interface for HausratGrunddeckung.
 * 
 * @generated
 */
public interface IHausratGrunddeckung extends IHausratDeckung {

	/**
	 * The name of the property beitrag.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_BEITRAG = "beitrag";

	/**
	 * Returns the beitrag.
	 * 
	 * @generated
	 */
	public Money getBeitrag();

	/**
	 * Returns the HausratGrunddeckungsTyp that configures this object.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp();

	/**
	 * Sets the new HausratGrunddeckungsTyp that configures this object.
	 * 
	 * @param hausratGrunddeckungsTyp
	 *            The new HausratGrunddeckungsTyp.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> if the properties should be initialized with
	 *            the defaults defined in the HausratGrunddeckungsTyp.
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckungsTyp(
			IHausratGrunddeckungsTyp hausratGrunddeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Returns the generation that configures this object and is valid at the
	 * objects effective date.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTypGen getHausratGrunddeckungsTypGen();

}
