/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTyp;
import org.faktorips.runtime.IRuntimeRepository;

import java.util.Calendar;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.runtime.IConfigurableModelObject;

import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTypGen;

/**
 * Implementation of IHausratGrunddeckungsTyp.
 * 
 * @generated
 */
public class HausratGrunddeckungsTyp extends HausratDeckungsTyp implements
		IHausratGrunddeckungsTyp {

	/**
	 * Creates a new HausratGrunddeckungsTyp.
	 * 
	 * @generated
	 */
	public HausratGrunddeckungsTyp(IRuntimeRepository repository, String id,
			String kindId, String versionId) {
		super(repository, id, kindId, versionId);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratGrunddeckungsTypGen getHausratGrunddeckungsTypGen(
			Calendar effectiveDate) {
		return (IHausratGrunddeckungsTypGen) getRepository()
				.getProductComponentGeneration(getId(), effectiveDate);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratGrunddeckung createHausratGrunddeckung() {
		return new HausratGrunddeckung(this);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IConfigurableModelObject createPolicyComponent() {
		return createHausratGrunddeckung();
	}

}
