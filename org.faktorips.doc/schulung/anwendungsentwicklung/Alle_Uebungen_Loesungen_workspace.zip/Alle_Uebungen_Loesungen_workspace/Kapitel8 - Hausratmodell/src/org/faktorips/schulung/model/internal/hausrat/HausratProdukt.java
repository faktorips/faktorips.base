/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.ProductComponent;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import org.faktorips.runtime.IRuntimeRepository;
import java.util.Calendar;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.faktorips.runtime.IConfigurableModelObject;

import org.faktorips.schulung.model.hausrat.IHausratProduktGen;

/**
 * Implementation of IHausratProdukt.
 * 
 * @generated
 */
public class HausratProdukt extends ProductComponent implements IHausratProdukt {

	/**
	 * Creates a new HausratProdukt.
	 * 
	 * @generated
	 */
	public HausratProdukt(IRuntimeRepository repository, String id,
			String kindId, String versionId) {
		super(repository, id, kindId, versionId);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratProduktGen getHausratProduktGen(Calendar effectiveDate) {
		return (IHausratProduktGen) getRepository()
				.getProductComponentGeneration(getId(), effectiveDate);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratVertrag createHausratVertrag() {
		return new HausratVertrag(this);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IConfigurableModelObject createPolicyComponent() {
		return createHausratVertrag();
	}

}
