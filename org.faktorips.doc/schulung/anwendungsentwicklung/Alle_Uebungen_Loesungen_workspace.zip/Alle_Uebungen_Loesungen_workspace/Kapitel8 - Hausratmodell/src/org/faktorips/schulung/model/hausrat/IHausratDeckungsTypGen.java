/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IProductComponentGeneration;

/**
 * Die Generation von HausratDeckungsTyp.
 * 
 * @generated
 */
public interface IHausratDeckungsTypGen extends IProductComponentGeneration {

	/**
	 * Returns the HausratDeckungsTyp this generation belongs to.
	 * 
	 * @generated
	 */
	public IHausratDeckungsTyp getHausratDeckungsTyp();

}
