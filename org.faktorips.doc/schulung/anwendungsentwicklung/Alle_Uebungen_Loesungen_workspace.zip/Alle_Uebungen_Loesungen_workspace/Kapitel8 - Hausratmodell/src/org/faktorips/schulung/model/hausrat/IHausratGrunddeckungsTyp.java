/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import java.util.Calendar;

/**
 * Published Interface of HausratGrunddeckungsTyp.
 * 
 * @generated
 */
public interface IHausratGrunddeckungsTyp extends IHausratDeckungsTyp {

	/**
	 * Returns the generation that is valid for the given effective date.
	 * Returns <code>null</code>, if no valid generation exists for the given
	 * date.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTypGen getHausratGrunddeckungsTypGen(
			Calendar effectiveDate);

	/**
	 * Creates a new HausratGrunddeckung that is configured.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung createHausratGrunddeckung();

}
