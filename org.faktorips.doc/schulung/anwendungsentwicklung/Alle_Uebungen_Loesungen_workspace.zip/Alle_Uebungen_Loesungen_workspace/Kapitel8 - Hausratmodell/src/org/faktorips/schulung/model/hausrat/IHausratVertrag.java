/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IDeltaSupport;
import org.faktorips.runtime.ICopySupport;
import org.faktorips.runtime.IVisitorSupport;
import org.faktorips.valueset.IntegerRange;
import org.faktorips.valueset.MoneyRange;
import org.faktorips.values.Money;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.runtime.IConfigurableModelObject;
import java.util.GregorianCalendar;
import org.faktorips.valueset.ValueSet;
import java.util.List;

/**
 * Published Interface for HausratVertrag.
 * 
 * @generated
 */
public interface IHausratVertrag extends IConfigurableModelObject,
		IDeltaSupport, ICopySupport, IVisitorSupport {

	/**
	 * The name of the property zahlweise.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_ZAHLWEISE = "zahlweise";
	/**
	 * The name of the property plz.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_PLZ = "plz";
	/**
	 * The name of the property tarifzone.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_TARIFZONE = "tarifzone";
	/**
	 * The name of the property wohnflaeche.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_WOHNFLAECHE = "wohnflaeche";
	/**
	 * Max allowed range for the property wohnflaeche.
	 * 
	 * @generated
	 */
	public static final IntegerRange MAX_ALLOWED_RANGE_FOR_WOHNFLAECHE = IntegerRange
			.valueOf(Integer.valueOf("0"), (Integer) null, (Integer) null,
					false);
	/**
	 * The name of the property vorschlagVersSumme.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VORSCHLAGVERSSUMME = "vorschlagVersSumme";
	/**
	 * The name of the property versSumme.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERSSUMME = "versSumme";
	/**
	 * Max allowed range for the property versSumme.
	 * 
	 * @generated
	 */
	public static final MoneyRange MAX_ALLOWED_RANGE_FOR_VERSSUMME = MoneyRange
			.valueOf(Money.valueOf("0.00 EUR"), Money.NULL, Money.NULL, false);

	/**
	 * The name of the property wirksamAb.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_WIRKSAMAB = "wirksamAb";
	/**
	 * The name of the property jahresbasisbeitrag.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_JAHRESBASISBEITRAG = "jahresbasisbeitrag";
	/**
	 * The maximal multiplicity of the association with the role name
	 * HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public static final IntegerRange MAX_MULTIPLICITY_OF_HAUSRATGRUNDDECKUNG = new IntegerRange(
			0, 1);
	/**
	 * The name of the association hausratGrunddeckung.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATGRUNDDECKUNG = "hausratGrunddeckung";

	/**
	 * The maximal multiplicity of the association with the role name
	 * HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public static final IntegerRange MAX_MULTIPLICITY_OF_HAUSRATZUSATZDECKUNG = new IntegerRange(
			0, 2147483647);
	/**
	 * The name of the association hausratZusatzdeckungen.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATZUSATZDECKUNGEN = "hausratZusatzdeckungen";

	/**
	 * The name of the association hausratDeckungen.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATDECKUNGEN = "hausratDeckungen";
	/**
	 * Error code for rule checkWohnflaeche.
	 * 
	 * @generated
	 */
	public final static String MSG_CODE_CHECKWOHNFLAECHE = "INVALID_WOHNFLAECHE";

	/**
	 * Returns the set of allowed values for the property zahlweise.
	 * 
	 * @generated
	 */
	public ValueSet<Zahlweise> getSetOfAllowedValuesForZahlweise(
			IValidationContext context);

	/**
	 * Returns the zahlweise.
	 * 
	 * @generated
	 */
	public Zahlweise getZahlweise();

	/**
	 * Sets the zahlweise.
	 * 
	 * @generated
	 */
	public void setZahlweise(Zahlweise newValue);

	/**
	 * Returns the plz.
	 * 
	 * @generated
	 */
	public String getPlz();

	/**
	 * Sets the plz.
	 * 
	 * @generated
	 */
	public void setPlz(String newValue);

	/**
	 * Returns the tarifzone.
	 * 
	 * @generated
	 */
	public String getTarifzone();

	/**
	 * Returns the range of allowed values for the property wohnflaeche.
	 * 
	 * @generated
	 */
	public IntegerRange getRangeForWohnflaeche(IValidationContext context);

	/**
	 * Returns the wohnflaeche.
	 * 
	 * @generated
	 */
	public Integer getWohnflaeche();

	/**
	 * Sets the wohnflaeche.
	 * 
	 * @generated
	 */
	public void setWohnflaeche(Integer newValue);

	/**
	 * Returns the vorschlagVersSumme.
	 * 
	 * @generated
	 */
	public Money getVorschlagVersSumme();

	/**
	 * Returns the range of allowed values for the property versSumme.
	 * 
	 * @generated
	 */
	public MoneyRange getRangeForVersSumme(IValidationContext context);

	/**
	 * Returns the versSumme.
	 * 
	 * @generated
	 */
	public Money getVersSumme();

	/**
	 * Sets the versSumme.
	 * 
	 * @generated
	 */
	public void setVersSumme(Money newValue);

	/**
	 * Returns the wirksamAb.
	 * 
	 * @generated
	 */
	public GregorianCalendar getWirksamAb();

	/**
	 * Sets the wirksamAb.
	 * 
	 * @generated
	 */
	public void setWirksamAb(GregorianCalendar newValue);

	/**
	 * Returns the jahresbasisbeitrag.
	 * 
	 * @generated
	 */
	public Money getJahresbasisbeitrag();

	/**
	 * Returns the referenced HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung getHausratGrunddeckung();

	/**
	 * Sets the HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckung(IHausratGrunddeckung newObject);

	/**
	 * Creates a new HausratGrunddeckung and adds it as HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung newHausratGrunddeckung();

	/**
	 * Creates a new HausratGrunddeckung and adds it as HausratGrunddeckung.
	 * 
	 * @param iHausratGrunddeckungsTyp
	 *            The product component that configures the new object.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung newHausratGrunddeckung(
			IHausratGrunddeckungsTyp iHausratGrunddeckungsTyp);

	/**
	 * Returns the number of HausratZusatzdeckungen.
	 * 
	 * @generated
	 */
	public int getNumOfHausratZusatzdeckungen();

	/**
	 * Returns <code>true</code> if the given object is referenced in the
	 * association, otherwise <code>false</code>.
	 * 
	 * @generated
	 */
	public boolean containsHausratZusatzdeckung(
			IHausratZusatzdeckung objectToTest);

	/**
	 * Returns the referenced HausratZusatzdeckungen.
	 * 
	 * @generated
	 */
	public List<IHausratZusatzdeckung> getHausratZusatzdeckungen();

	/**
	 * Adds the given object as HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public void addHausratZusatzdeckung(IHausratZusatzdeckung objectToAdd);

	/**
	 * Removes the given object from the association HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public void removeHausratZusatzdeckung(IHausratZusatzdeckung objectToRemove);

	/**
	 * Creates a new HausratZusatzdeckung and adds it as HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung newHausratZusatzdeckung();

	/**
	 * Creates a new HausratZusatzdeckung and adds it as HausratZusatzdeckung.
	 * 
	 * @param iHausratZusatzdeckungsTyp
	 *            The product component that configures the new object.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung newHausratZusatzdeckung(
			IHausratZusatzdeckungsTyp iHausratZusatzdeckungsTyp);

	/**
	 * Returns the object at the indexed position from the association
	 * HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung getHausratZusatzdeckung(int index);

	/**
	 * @generated
	 */
	public void berechneJahresbasisbeitrag();

	/**
	 * Returns the number of HausratDeckungen.
	 * 
	 * @generated
	 */
	public int getNumOfHausratDeckungen();

	/**
	 * Returns <code>true</code> if the given object is referenced in the
	 * association, otherwise <code>false</code>.
	 * 
	 * @generated
	 */
	public boolean containsHausratDeckung(IHausratDeckung objectToTest);

	/**
	 * Returns the referenced HausratDeckungen.
	 * 
	 * @generated
	 */
	public List<IHausratDeckung> getHausratDeckungen();

	/**
	 * Returns the HausratProdukt that configures this object.
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProdukt();

	/**
	 * Sets the new HausratProdukt that configures this object.
	 * 
	 * @param hausratProdukt
	 *            The new HausratProdukt.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> if the properties should be initialized with
	 *            the defaults defined in the HausratProdukt.
	 * 
	 * @generated
	 */
	public void setHausratProdukt(IHausratProdukt hausratProdukt,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Returns the generation that configures this object and is valid at the
	 * objects effective date.
	 * 
	 * @generated
	 */
	public IHausratProduktGen getHausratProduktGen();

}
