/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.test.IpsTestCase2;
import javax.xml.parsers.ParserConfigurationException;
import org.faktorips.runtime.test.IpsTestResult;
import org.w3c.dom.Element;
import org.faktorips.runtime.IObjectReferenceStore;
import org.faktorips.runtime.DefaultObjectReferenceStore;
import org.faktorips.runtime.internal.XmlUtil;
import org.faktorips.runtime.DefaultReferenceResolver;
import org.faktorips.runtime.internal.XmlCallback;
import org.faktorips.runtime.IModelObject;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckung;

import java.util.List;
import java.util.Map;
import org.faktorips.values.Money;

/**
 * Instances of this class are business test cases. Testing of business logic is
 * done by means of the method executeAsserts(). The data for the test cases are
 * provided by the FaktorIPS-Testcases which are associated with the test case
 * type upon which this class is generated.
 * 
 * @generated
 */
public class BeitragsberechnungsTest extends IpsTestCase2 {

	/**
	 * @generated
	 */
	public final static String TESTATTR_HAUSRATVERTRAG_TARIFZONE = "tarifzone";
	/**
	 * @generated
	 */
	public final static String TESTATTR_HAUSRATZUSATZDECKUNG_VERSSUMME = "versSumme";
	/**
	 * @generated
	 */
	private HausratVertrag inputHausratVertrag;
	/**
	 * @generated
	 */
	private HausratVertrag expectedHausratVertrag;

	/**
	 * Creates a new test case.
	 * 
	 * @restrainedmodifiable
	 */
	public BeitragsberechnungsTest(String qualifiedName)
			throws ParserConfigurationException {
		super(qualifiedName);
		// begin-user-code
		// end-user-code
	}

	/**
	 * Executes the business logic under test.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void executeBusinessLogic() {
		// begin-user-code
		inputHausratVertrag.berechneJahresbasisbeitrag();
		// end-user-code
	}

	/**
	 * Executes the asserts that compare actual with expected result.
	 * 
	 * Asserts are programmed as in JUnit via calling assert(..) methods. E.g.
	 * assert(expectedPolicy.getPremium(), inputPolicy.getPremium(), result); To
	 * identify the test object, the name of the test object and the name of the
	 * attribute could be specified, thus if the test case is running as
	 * Faktor-Ips test case then failures are marked in the test case editor on
	 * the corresponding edit field. The name of the test object and the name of
	 * the test attribute must be the same as specified in the test case type.
	 * If the test object is a child object then the complete path to the object
	 * must be given, the path elements must be separated by ".". If the test
	 * contains several instances with the same name then an index (starting
	 * with 0) must be added to the testObject string separated by "#". E.g.
	 * assertEquals(expectedPolicy.getPremium(), inputPolicy.getPremium(),
	 * result, "RootObject#0.Policy#0", "premium");
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void executeAsserts(IpsTestResult result) {
		// begin-user-code
		String tarifzoneErw = (String) getExtensionAttributeValue(
				expectedHausratVertrag, TESTATTR_HAUSRATVERTRAG_TARIFZONE);
		String tarifzoneIst = inputHausratVertrag.getTarifzone();
		assertEquals(tarifzoneErw, tarifzoneIst, result, "HausratVertrag#0",
				"tarifzone");

		IHausratGrunddeckung grunddeckungErw = expectedHausratVertrag
				.getHausratGrunddeckung();
		IHausratGrunddeckung grunddeckungIst = inputHausratVertrag
				.getHausratGrunddeckung();

		assertEquals(grunddeckungErw.getJahresbasisbeitrag(),
				grunddeckungIst.getJahresbasisbeitrag(), result,
				"HausratVertrag#0.HausratGrunddeckung#0", "jahresbasisbeitrag");

		List<IHausratZusatzdeckung> zusatzdeckungenIst = inputHausratVertrag
				.getHausratZusatzdeckungen();
		List<IHausratZusatzdeckung> zusatzdeckungenErw = expectedHausratVertrag
				.getHausratZusatzdeckungen();
		for (int i = 0; i < zusatzdeckungenErw.size(); i++) {
			assertEquals(zusatzdeckungenErw.get(i).getJahresbasisbeitrag(),
					zusatzdeckungenIst.get(i).getJahresbasisbeitrag(), result,
					"HausratVertrag#0.HausratZusatzdeckung#" + i,
					"jahresbasisbeitrag");
			Money versSummeErw = (Money) getExtensionAttributeValue(
					zusatzdeckungenErw.get(i), "versSumme");
			Money versSummeIst = zusatzdeckungenIst.get(i).getVersSumme();
			assertEquals(versSummeErw, versSummeIst, result,
					"HausratVertrag#0.HausratZusatzdeckung#" + i, "versSumme");
		}
		// end-user-code
	}

	/**
	 * Initializes the test case's input with the data from the xml.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initInputFromXml(Element element) {
		// begin-user-code
		// end-user-code
		IObjectReferenceStore objectReferenceStore = new DefaultObjectReferenceStore();
		Element childElement = null;
		HausratVertragXmlCallback hausratVertragXmlCallback = new HausratVertragXmlCallback(
				true);
		childElement = XmlUtil.getFirstElement(element, "HausratVertrag");
		if (childElement != null) {
			try {
				String className = childElement.getAttribute("class");
				inputHausratVertrag = (HausratVertrag) Class.forName(className,
						true, HausratVertrag.class.getClassLoader())
						.newInstance();
				inputHausratVertrag.initFromXml(childElement, true,
						getRepository(), objectReferenceStore,
						hausratVertragXmlCallback);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		try {
			new DefaultReferenceResolver().resolve(objectReferenceStore);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		;
	}

	/**
	 * Initializes the test case's expected result with the data from the xml.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initExpectedResultFromXml(Element element) {
		// begin-user-code
		// end-user-code
		IObjectReferenceStore objectReferenceStore = new DefaultObjectReferenceStore();
		Element childElement = null;
		HausratVertragXmlCallback hausratVertragXmlCallback = new HausratVertragXmlCallback(
				false);
		childElement = XmlUtil.getFirstElement(element, "HausratVertrag");
		if (childElement != null) {
			try {
				String className = childElement.getAttribute("class");
				expectedHausratVertrag = (HausratVertrag) Class.forName(
						className, true, HausratVertrag.class.getClassLoader())
						.newInstance();
				expectedHausratVertrag.initFromXml(childElement, true,
						getRepository(), objectReferenceStore,
						hausratVertragXmlCallback);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		try {
			new DefaultReferenceResolver().resolve(objectReferenceStore);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		;
	}

	/**
	 * XMLCallback class for the test parameter HausratVertrag
	 * 
	 * @generated
	 */
	private class HausratVertragXmlCallback implements XmlCallback {
		/**
		 * Indicates if the class is used for the input (<code>true</code>) or
		 * for the expected result test content (<code>false</code>)
		 * 
		 * @generated
		 */
		private boolean input;

		/**
		 * Creates a new XMLCallback class for the test parameter HausratVertrag
		 * 
		 * @generated
		 */
		public HausratVertragXmlCallback(boolean input) {
			this.input = input;
		}

		/**
		 * {@inheritDoc}
		 * 
		 * @generated
		 */
		public void initProperties(String pathFromAggregateRoot,
				IModelObject modelObject, Map<String, String> propMap) {
			if (pathFromAggregateRoot.equals("/HausratVertrag")) {
				String value = null;
				if (!input) {
					value = (String) propMap
							.get(TESTATTR_HAUSRATVERTRAG_TARIFZONE);
					addExtensionAttribute(modelObject,
							TESTATTR_HAUSRATVERTRAG_TARIFZONE, value);
				}
			}
			if (pathFromAggregateRoot
					.equals("/HausratVertrag/HausratZusatzdeckung")) {
				String value = null;
				if (!input) {
					value = (String) propMap
							.get(TESTATTR_HAUSRATZUSATZDECKUNG_VERSSUMME);
					addExtensionAttribute(modelObject,
							TESTATTR_HAUSRATZUSATZDECKUNG_VERSSUMME,
							Money.valueOf(value));
				}
			}
		}

	}

}
