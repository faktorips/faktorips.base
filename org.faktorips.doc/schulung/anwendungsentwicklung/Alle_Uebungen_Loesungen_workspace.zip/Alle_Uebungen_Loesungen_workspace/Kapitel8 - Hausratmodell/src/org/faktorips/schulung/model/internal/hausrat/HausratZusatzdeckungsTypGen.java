/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTypGen;
import org.faktorips.values.Decimal;
import org.faktorips.values.Money;
import org.faktorips.runtime.IllegalRepositoryModificationException;
import org.faktorips.runtime.FormulaExecutionException;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTyp;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.runtime.internal.ValueToXmlHelper;
import org.faktorips.runtime.IProductComponentLink;
import org.faktorips.runtime.IProductComponent;
import java.util.List;

/**
 * The implementation of IHausratZusatzdeckungsTypGen.
 * 
 * @generated
 */
public class HausratZusatzdeckungsTypGen extends HausratDeckungsTypGen
		implements IHausratZusatzdeckungsTypGen {

	/**
	 * The product component property Bezeichnung.
	 * 
	 * @generated
	 */
	private String bezeichnung = null;
	/**
	 * The product component property VersSummeFaktor.
	 * 
	 * @generated
	 */
	private Decimal versSummeFaktor = Decimal.NULL;
	/**
	 * The product component property MaximaleVersSumme.
	 * 
	 * @generated
	 */
	private Money maximaleVersSumme = Money.NULL;

	/**
	 * Creates a new HausratZusatzdeckungsTypGen.
	 * 
	 * @generated
	 */
	public HausratZusatzdeckungsTypGen(HausratZusatzdeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public String getBezeichnung() {
		return bezeichnung;
	}

	/**
	 * Sets the value for bezeichnung.
	 * 
	 * @generated
	 */
	public void setBezeichnung(String newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.bezeichnung = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public Decimal getVersSummeFaktor() {
		return versSummeFaktor;
	}

	/**
	 * Sets the value for versSummeFaktor.
	 * 
	 * @generated
	 */
	public void setVersSummeFaktor(Decimal newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.versSummeFaktor = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public Money getMaximaleVersSumme() {
		return maximaleVersSumme;
	}

	/**
	 * Sets the value for maximaleVersSumme.
	 * 
	 * @generated
	 */
	public void setMaximaleVersSumme(Money newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.maximaleVersSumme = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public Money computeJahresbeitrag(Money versSumme)
			throws FormulaExecutionException {
		return (Money) getFormulaEvaluator().evaluate("computeJahresbeitrag",
				versSumme);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp() {
		return (IHausratZusatzdeckungsTyp) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
		Element configElement = null;
		String value = null;
		configElement = configMap.get("bezeichnung");
		if (configElement != null) {
			value = ValueToXmlHelper
					.getValueFromElement(configElement, "Value");
			this.bezeichnung = value;
		}
		configElement = configMap.get("versSummeFaktor");
		if (configElement != null) {
			value = ValueToXmlHelper
					.getValueFromElement(configElement, "Value");
			this.versSummeFaktor = Decimal.valueOf(value);
		}
		configElement = configMap.get("maximaleVersSumme");
		if (configElement != null) {
			value = ValueToXmlHelper
					.getValueFromElement(configElement, "Value");
			this.maximaleVersSumme = Money.valueOf(value);
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IProductComponentLink<? extends IProductComponent> getLink(
			String linkName, IProductComponent target) {
		return super.getLink(linkName, target);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public List<IProductComponentLink<? extends IProductComponent>> getLinks() {
		List<IProductComponentLink<? extends IProductComponent>> list = super
				.getLinks();
		return list;
	}

}
