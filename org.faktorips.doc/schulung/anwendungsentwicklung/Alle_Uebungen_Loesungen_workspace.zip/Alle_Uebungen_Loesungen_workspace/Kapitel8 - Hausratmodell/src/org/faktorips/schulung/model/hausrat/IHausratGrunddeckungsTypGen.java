/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

/**
 * Die Generation von HausratGrunddeckungsTyp.
 * 
 * @generated
 */
public interface IHausratGrunddeckungsTypGen extends IHausratDeckungsTypGen {

	/**
	 * Returns the HausratGrunddeckungsTyp this generation belongs to.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp();

}
