/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.Table;
import java.util.List;
import java.util.ArrayList;
import org.faktorips.runtime.IRuntimeRepository;
import java.util.Collections;
import org.faktorips.runtime.internal.ReadOnlyBinaryRangeTree;
import java.util.HashMap;
import org.faktorips.runtime.internal.ReadOnlyBinaryRangeTree.TwoColumnKey;
import java.util.Iterator;
import org.faktorips.runtime.internal.ReadOnlyBinaryRangeTree.KeyType;

/**
 * This class represents a read-only in memory table. Data can be accessed by
 * the find-methods of this table.
 * 
 * @generated
 */
public class Tarifzonentabelle extends Table {

	/**
	 * Member variable for key to table row mapping.
	 * 
	 * @generated
	 */
	private ReadOnlyBinaryRangeTree key0Tree;

	/**
	 * Creates an empty table.
	 * 
	 * @generated
	 */
	public Tarifzonentabelle() {
		super();
	}

	/**
	 * Creates a new table based on the indicated rows. The given row list is
	 * copied, so modifying it afterwards does not change the created table.
	 * This constructor can be used in unit tests to define arbitrary table
	 * contents.
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public Tarifzonentabelle(List<TarifzonentabelleRow> content) {
		super();
		rows = new ArrayList(content.size());
		rows.addAll(content);
		initKeyMaps();
	}

	/**
	 * Adds a new table row during the initialization phase.
	 * 
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void addRow(List values, IRuntimeRepository productRepository) {
		String columnValue = (String) values.get(0);
		String plzVon = columnValue == null ? null : columnValue;
		columnValue = (String) values.get(1);
		String plzBis = columnValue == null ? null : columnValue;
		columnValue = (String) values.get(2);
		String tarifzone = columnValue == null ? null : columnValue;
		rows.add(new TarifzonentabelleRow(plzVon, plzBis, tarifzone));
	}

	/**
	 * Initializes the maps that are used by the finder methods of this table.
	 * This method is called during the initialization phase.
	 * 
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void initKeyMaps() {
		HashMap<TwoColumnKey, TarifzonentabelleRow> key0MapTemp = new HashMap<TwoColumnKey, TarifzonentabelleRow>(
				rows.size());
		for (Iterator<TarifzonentabelleRow> it = rows.iterator(); it.hasNext();) {
			TarifzonentabelleRow row = it.next();
			key0MapTemp.put(new TwoColumnKey(row.getPlzVon(), row.getPlzBis()),
					row);
		}
		key0Tree = generateTree(key0MapTemp,
				new KeyType[] { ReadOnlyBinaryRangeTree.KEY_IS_TWO_COLUMN_KEY });
	}

	/**
	 * Returns an instance of this table class.
	 * 
	 * @generated
	 */
	public static final Tarifzonentabelle getInstance(
			IRuntimeRepository repository) {
		return (Tarifzonentabelle) repository.getTable(Tarifzonentabelle.class);
	}

	/**
	 * Returns an instance of this table class.
	 * 
	 * @generated
	 */
	public static final Tarifzonentabelle getInstance(
			IRuntimeRepository repository, String qualifiedTableName) {
		return (Tarifzonentabelle) repository.getTable(qualifiedTableName);
	}

	/**
	 * Returns all rows of this table.
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public List<TarifzonentabelleRow> getAllRows() {
		return Collections.unmodifiableList(rows);
	}

	/**
	 * Searches the content of this table for an entry that fits the specified
	 * parameters and returns the according row object. If no entry could be
	 * found, null is returned.
	 * 
	 * @generated
	 */
	public TarifzonentabelleRow findRow(String plzVonBis) {
		if (plzVonBis == null) {
			return null;
		}
		TarifzonentabelleRow returnValue = (TarifzonentabelleRow) getValue(
				key0Tree, new Comparable[] { plzVonBis });
		return returnValue;
	}

	/**
	 * Searches the content of this table for an entry that fits the specified
	 * parameters and returns the according row object. If no entry could be
	 * found, a 'null' row is returned.
	 * 
	 * @generated
	 */
	public TarifzonentabelleRow findRowNullRowReturnedForEmtpyResult(
			String plzVonBis) {
		if (plzVonBis == null) {
			return TarifzonentabelleRow.NULL_ROW;
		}
		TarifzonentabelleRow returnValue = (TarifzonentabelleRow) getValue(
				key0Tree, new Comparable[] { plzVonBis });
		if (returnValue == null) {
			return TarifzonentabelleRow.NULL_ROW;
		}
		return returnValue;
	}

}
