/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.values.Decimal;
import org.faktorips.values.Money;
import org.faktorips.runtime.FormulaExecutionException;

/**
 * Die Generation von HausratZusatzdeckungsTyp.
 * 
 * @generated
 */
public interface IHausratZusatzdeckungsTypGen extends IHausratDeckungsTypGen {

	/**
	 * The name of the property bezeichnung.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_BEZEICHNUNG = "bezeichnung";
	/**
	 * The name of the property versSummeFaktor.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERSSUMMEFAKTOR = "versSummeFaktor";
	/**
	 * The name of the property maximaleVersSumme.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_MAXIMALEVERSSUMME = "maximaleVersSumme";

	/**
	 * Returns the value of bezeichnung.
	 * 
	 * @generated
	 */
	public String getBezeichnung();

	/**
	 * Returns the value of versSummeFaktor.
	 * 
	 * @generated
	 */
	public Decimal getVersSummeFaktor();

	/**
	 * Returns the value of maximaleVersSumme.
	 * 
	 * @generated
	 */
	public Money getMaximaleVersSumme();

	/**
	 * @generated
	 */
	public Money computeJahresbeitrag(Money versSumme)
			throws FormulaExecutionException;

	/**
	 * Returns the HausratZusatzdeckungsTyp this generation belongs to.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp();

}
