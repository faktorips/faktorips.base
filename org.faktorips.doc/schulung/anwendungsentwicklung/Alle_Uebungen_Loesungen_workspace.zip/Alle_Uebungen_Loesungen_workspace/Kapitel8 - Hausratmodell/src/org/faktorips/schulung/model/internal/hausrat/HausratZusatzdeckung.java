/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckung;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTyp;

import java.math.BigDecimal;
import org.faktorips.runtime.internal.AbstractModelObject;
import org.w3c.dom.Element;
import org.faktorips.runtime.IModelObjectDelta;
import org.faktorips.runtime.IModelObject;
import org.faktorips.runtime.IDeltaComputationOptions;
import org.faktorips.runtime.internal.ModelObjectDelta;
import java.util.Map;
import java.util.HashMap;
import org.faktorips.runtime.IModelObjectVisitor;
import org.faktorips.runtime.MessageList;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.faktorips.values.Money;
import org.faktorips.values.Decimal;

import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTypGen;

/**
 * @generated
 */
public class HausratZusatzdeckung extends HausratDeckung implements
		IHausratZusatzdeckung {

	/**
	 * Member variable for the parent object: HausratVertrag
	 * 
	 * @generated
	 */
	private HausratVertrag hausratVertrag;

	/**
	 * Creates a new HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public HausratZusatzdeckung() {
		super();
	}

	/**
	 * Creates a new HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public HausratZusatzdeckung(IHausratZusatzdeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * Returns the bezeichnung.
	 * 
	 * @generated
	 */
	public String getBezeichnung() {
		return getHausratZusatzdeckungsTypGen().getBezeichnung();
	}

	/**
	 * Returns the versSummeFaktor.
	 * 
	 * @generated
	 */
	public Decimal getVersSummeFaktor() {
		return getHausratZusatzdeckungsTypGen().getVersSummeFaktor();
	}

	/**
	 * Returns the maximaleVersSumme.
	 * 
	 * @generated
	 */
	public Money getMaximaleVersSumme() {
		return getHausratZusatzdeckungsTypGen().getMaximaleVersSumme();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated NOT
	 */
	@Override
	public Money getVersSumme() {
		Decimal versSummeFaktor = getHausratZusatzdeckungsTypGen()
				.getVersSummeFaktor();
		Money maximaleVersSumme = getHausratZusatzdeckungsTypGen()
				.getMaximaleVersSumme();

		Money versSumme = getHausratVertrag().getVersSumme();
		Money berechneteVersSumme = versSumme.multiply(versSummeFaktor,
				BigDecimal.ROUND_HALF_DOWN);

		if (maximaleVersSumme.isNull()) {
			return berechneteVersSumme;
		} else {
			return maximaleVersSumme.min(berechneteVersSumme);
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 */
	@Override
	public Money berechneJahresbasisbeitragInternal() {
		return getHausratZusatzdeckungsTypGen().computeJahresbeitrag(
				getVersSumme());
	}

	/**
	 * Initializes the object with the configured defaults.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initialize() {
		super.initialize();

		// begin-user-code
		// end-user-code
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp() {
		return (IHausratZusatzdeckungsTyp) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratZusatzdeckungsTypGen getHausratZusatzdeckungsTypGen() {
		return (IHausratZusatzdeckungsTypGen) getProductCmptGeneration();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setHausratZusatzdeckungsTyp(
			IHausratZusatzdeckungsTyp hausratZusatzdeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults) {
		setProductComponent(hausratZusatzdeckungsTyp);
		if (initPropertiesWithConfiguratedDefaults) {
			initialize();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void effectiveFromHasChanged() {
		super.effectiveFromHasChanged();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObject getParentModelObject() {
		if (hausratVertrag != null) {
			return hausratVertrag;
		}
		return null;
	}

	/**
	 * @generated
	 */
	public void setHausratVertragInternal(IHausratVertrag newParent) {
		if (getHausratVertrag() == newParent) {
			return;
		}
		IModelObject parent = getParentModelObject();
		if (newParent != null && parent != null) {
			throw new RuntimeException(
					"HausratZusatzdeckung can't be assigned to parent object of class HausratVertrag, because object already belongs to a different parent object.");
		}
		hausratVertrag = (HausratVertrag) newParent;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratVertrag getHausratVertrag() {
		if (hausratVertrag != null) {
			return hausratVertrag;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected AbstractModelObject createChildFromXml(Element childEl) {
		AbstractModelObject newChild = super.createChildFromXml(childEl);
		if (newChild != null) {
			return newChild;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObjectDelta computeDelta(IModelObject otherObject,
			IDeltaComputationOptions options) {
		ModelObjectDelta delta = (ModelObjectDelta) super.computeDelta(
				otherObject, options);
		if (!HausratZusatzdeckung.class
				.isAssignableFrom(otherObject.getClass())) {
			return delta;
		}
		return delta;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObject newCopy() {
		Map<IModelObject, IModelObject> copyMap = new HashMap<IModelObject, IModelObject>();
		HausratZusatzdeckung newCopy = (HausratZusatzdeckung) newCopyInternal(copyMap);
		copyAssociationsInternal(newCopy, copyMap);
		return newCopy;
	}

	/**
	 * Internal copy method with a {@link Map} containing already copied
	 * instances.
	 * 
	 * @param copyMap
	 *            the map contains the copied instances
	 * 
	 * @generated
	 */
	@Override
	public IModelObject newCopyInternal(Map<IModelObject, IModelObject> copyMap) {
		HausratZusatzdeckung newCopy = (HausratZusatzdeckung) copyMap.get(this);
		if (newCopy == null) {
			newCopy = new HausratZusatzdeckung();
			newCopy.copyProductCmptAndGenerationInternal(this);
			copyProperties(newCopy, copyMap);
		}
		return newCopy;
	}

	/**
	 * This method sets all properties in the copy with the values of this
	 * object. If there are copied associated objects they are added to the copy
	 * map.
	 * 
	 * @param copy
	 *            The copy object
	 * @param copyMap
	 *            a map containing copied associated objects
	 * 
	 * @generated
	 */
	@Override
	protected void copyProperties(IModelObject copy,
			Map<IModelObject, IModelObject> copyMap) {
		super.copyProperties(copy, copyMap);
	}

	/**
	 * Internal method for setting copied associations. For copied targets, the
	 * association have to retarget to the new copied instance. This method have
	 * to call {@link #copyAssociationsInternal(IModelObject, Map)} in other
	 * instances associated by composite.
	 * 
	 * @param abstractCopy
	 *            the copy of this policy component
	 * @param copyMap
	 *            the map contains the copied instances
	 * 
	 * @generated
	 */
	@Override
	public void copyAssociationsInternal(IModelObject abstractCopy,
			Map<IModelObject, IModelObject> copyMap) {
		super.copyAssociationsInternal(abstractCopy, copyMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public boolean accept(IModelObjectVisitor visitor) {
		if (!super.accept(visitor)) {
			return false;
		}
		return true;
	}

	/**
	 * Validates the object (but not its children). Returns <code>true</code> if
	 * this object should continue validating, <code>false</code> else.
	 * 
	 * @generated
	 */
	@Override
	public boolean validateSelf(MessageList ml, IValidationContext context) {
		if (!super.validateSelf(ml, context)) {
			return STOP_VALIDATION;
		}
		return CONTINUE_VALIDATION;
	}

	/**
	 * Validates the objects children.
	 * 
	 * @generated
	 */
	@Override
	public void validateDependants(MessageList ml, IValidationContext context) {
		super.validateDependants(ml, context);
	}

}
