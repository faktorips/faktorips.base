/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.faktorips.runtime.IDeltaComputationOptions;
import org.faktorips.runtime.IModelObject;
import org.faktorips.runtime.IModelObjectDelta;
import org.faktorips.runtime.IModelObjectVisitor;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.runtime.MessageList;
import org.faktorips.runtime.internal.AbstractModelObject;
import org.faktorips.runtime.internal.ModelObjectDelta;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTyp;

import org.faktorips.values.Decimal;
import org.faktorips.values.Money;
import org.w3c.dom.Element;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;

import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTypGen;

/**
 * @generated
 */
public class HausratGrunddeckung extends HausratDeckung implements
		IHausratGrunddeckung {

	/**
	 * Member variable for the parent object: HausratVertrag
	 * 
	 * @generated
	 */
	private HausratVertrag hausratVertrag;

	/**
	 * Creates a new HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public HausratGrunddeckung() {
		super();
	}

	/**
	 * Creates a new HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public HausratGrunddeckung(IHausratGrunddeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated NOT
	 */
	@Override
	public Money getBeitrag() {
		return getJahresbasisbeitrag().divide(
				getHausratVertrag().getZahlweise().getAnzahlZahlungenProJahr(),
				BigDecimal.ROUND_HALF_DOWN);
	}

	/**
	 * {@inheritDoc}
	 * 
	 */
	@Override
	public Money berechneJahresbasisbeitragInternal() {
		HausratGrunddeckungsTypGen gen = (HausratGrunddeckungsTypGen) getHausratGrunddeckungsTypGen();
		if (gen == null) {
			return Money.NULL;
		}
		TariftabelleHausrat tabelle = gen.getTariftabelle();
		TariftabelleHausratRow row = tabelle.findRow(getHausratVertrag()
				.getTarifzone());
		if (row == null) {
			return Money.NULL;
		}
		Money versSumme = getHausratVertrag().getVersSumme();
		Decimal beitragssatz = row.getBeitragssatz();
		return versSumme.divide(1000, BigDecimal.ROUND_HALF_UP).multiply(
				beitragssatz, BigDecimal.ROUND_HALF_UP);
	}

	/**
	 * Initializes the object with the configured defaults.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initialize() {
		super.initialize();

		// begin-user-code
		// end-user-code
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp() {
		return (IHausratGrunddeckungsTyp) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratGrunddeckungsTypGen getHausratGrunddeckungsTypGen() {
		return (IHausratGrunddeckungsTypGen) getProductCmptGeneration();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setHausratGrunddeckungsTyp(
			IHausratGrunddeckungsTyp hausratGrunddeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults) {
		setProductComponent(hausratGrunddeckungsTyp);
		if (initPropertiesWithConfiguratedDefaults) {
			initialize();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void effectiveFromHasChanged() {
		super.effectiveFromHasChanged();
	}

	/**
	 * Returns the table Tariftabelle referenced by the corresponding product
	 * component.
	 * 
	 * @generated
	 */
	public TariftabelleHausrat getTariftabelle() {
		HausratGrunddeckungsTypGen productCmpt = (HausratGrunddeckungsTypGen) getHausratGrunddeckungsTypGen();
		if (productCmpt == null) {
			return null;
		}
		return productCmpt.getTariftabelle();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObject getParentModelObject() {
		if (hausratVertrag != null) {
			return hausratVertrag;
		}
		return null;
	}

	/**
	 * @generated
	 */
	public void setHausratVertragInternal(IHausratVertrag newParent) {
		if (getHausratVertrag() == newParent) {
			return;
		}
		IModelObject parent = getParentModelObject();
		if (newParent != null && parent != null) {
			throw new RuntimeException(
					"HausratGrunddeckung can't be assigned to parent object of class HausratVertrag, because object already belongs to a different parent object.");
		}
		hausratVertrag = (HausratVertrag) newParent;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratVertrag getHausratVertrag() {
		if (hausratVertrag != null) {
			return hausratVertrag;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected AbstractModelObject createChildFromXml(Element childEl) {
		AbstractModelObject newChild = super.createChildFromXml(childEl);
		if (newChild != null) {
			return newChild;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObjectDelta computeDelta(IModelObject otherObject,
			IDeltaComputationOptions options) {
		ModelObjectDelta delta = (ModelObjectDelta) super.computeDelta(
				otherObject, options);
		if (!HausratGrunddeckung.class.isAssignableFrom(otherObject.getClass())) {
			return delta;
		}
		return delta;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObject newCopy() {
		Map<IModelObject, IModelObject> copyMap = new HashMap<IModelObject, IModelObject>();
		HausratGrunddeckung newCopy = (HausratGrunddeckung) newCopyInternal(copyMap);
		copyAssociationsInternal(newCopy, copyMap);
		return newCopy;
	}

	/**
	 * Internal copy method with a {@link Map} containing already copied
	 * instances.
	 * 
	 * @param copyMap
	 *            the map contains the copied instances
	 * 
	 * @generated
	 */
	@Override
	public IModelObject newCopyInternal(Map<IModelObject, IModelObject> copyMap) {
		HausratGrunddeckung newCopy = (HausratGrunddeckung) copyMap.get(this);
		if (newCopy == null) {
			newCopy = new HausratGrunddeckung();
			newCopy.copyProductCmptAndGenerationInternal(this);
			copyProperties(newCopy, copyMap);
		}
		return newCopy;
	}

	/**
	 * This method sets all properties in the copy with the values of this
	 * object. If there are copied associated objects they are added to the copy
	 * map.
	 * 
	 * @param copy
	 *            The copy object
	 * @param copyMap
	 *            a map containing copied associated objects
	 * 
	 * @generated
	 */
	@Override
	protected void copyProperties(IModelObject copy,
			Map<IModelObject, IModelObject> copyMap) {
		super.copyProperties(copy, copyMap);
	}

	/**
	 * Internal method for setting copied associations. For copied targets, the
	 * association have to retarget to the new copied instance. This method have
	 * to call {@link #copyAssociationsInternal(IModelObject, Map)} in other
	 * instances associated by composite.
	 * 
	 * @param abstractCopy
	 *            the copy of this policy component
	 * @param copyMap
	 *            the map contains the copied instances
	 * 
	 * @generated
	 */
	@Override
	public void copyAssociationsInternal(IModelObject abstractCopy,
			Map<IModelObject, IModelObject> copyMap) {
		super.copyAssociationsInternal(abstractCopy, copyMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public boolean accept(IModelObjectVisitor visitor) {
		if (!super.accept(visitor)) {
			return false;
		}
		return true;
	}

	/**
	 * Validates the object (but not its children). Returns <code>true</code> if
	 * this object should continue validating, <code>false</code> else.
	 * 
	 * @generated
	 */
	@Override
	public boolean validateSelf(MessageList ml, IValidationContext context) {
		if (!super.validateSelf(ml, context)) {
			return STOP_VALIDATION;
		}
		return CONTINUE_VALIDATION;
	}

	/**
	 * Validates the objects children.
	 * 
	 * @generated
	 */
	@Override
	public void validateDependants(MessageList ml, IValidationContext context) {
		super.validateDependants(ml, context);
	}

}
