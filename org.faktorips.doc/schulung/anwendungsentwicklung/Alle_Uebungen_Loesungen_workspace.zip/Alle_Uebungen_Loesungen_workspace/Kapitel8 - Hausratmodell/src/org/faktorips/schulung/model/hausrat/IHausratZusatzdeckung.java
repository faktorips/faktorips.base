/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.values.Money;

/**
 * Published Interface for HausratZusatzdeckung.
 * 
 * @generated
 */
public interface IHausratZusatzdeckung extends IHausratDeckung {

	/**
	 * The name of the property versSumme.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERSSUMME = "versSumme";

	/**
	 * Returns the versSumme.
	 * 
	 * @generated
	 */
	public Money getVersSumme();

	/**
	 * Returns the HausratZusatzdeckungsTyp that configures this object.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp();

	/**
	 * Sets the new HausratZusatzdeckungsTyp that configures this object.
	 * 
	 * @param hausratZusatzdeckungsTyp
	 *            The new HausratZusatzdeckungsTyp.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> if the properties should be initialized with
	 *            the defaults defined in the HausratZusatzdeckungsTyp.
	 * 
	 * @generated
	 */
	public void setHausratZusatzdeckungsTyp(
			IHausratZusatzdeckungsTyp hausratZusatzdeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Returns the generation that configures this object and is valid at the
	 * objects effective date.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTypGen getHausratZusatzdeckungsTypGen();

}
