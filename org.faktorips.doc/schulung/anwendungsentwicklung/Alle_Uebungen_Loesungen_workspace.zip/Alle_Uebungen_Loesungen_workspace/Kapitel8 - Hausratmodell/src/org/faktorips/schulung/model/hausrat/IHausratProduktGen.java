/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IProductComponentGeneration;
import org.faktorips.values.Money;
import org.faktorips.valueset.ValueSet;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.valueset.IntegerRange;
import org.faktorips.valueset.MoneyRange;
import java.util.List;
import java.util.Calendar;
import org.faktorips.runtime.IProductComponentLink;
import org.faktorips.runtime.CardinalityRange;
import java.util.Collection;

/**
 * Die Generation von HausratProdukt.
 * 
 * @generated
 */
public interface IHausratProduktGen extends IProductComponentGeneration {

	/**
	 * The name of the property produktname.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_PRODUKTNAME = "produktname";
	/**
	 * The name of the property vertriebsname.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERTRIEBSNAME = "vertriebsname";
	/**
	 * The name of the property vorschlagVersSummeProQm.
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VORSCHLAGVERSSUMMEPROQM = "vorschlagVersSummeProQm";

	/**
	 * Returns the value of produktname.
	 * 
	 * @generated
	 */
	public String getProduktname();

	/**
	 * Returns the value of vertriebsname.
	 * 
	 * @generated
	 */
	public String getVertriebsname();

	/**
	 * Returns the value of vorschlagVersSummeProQm.
	 * 
	 * @generated
	 */
	public Money getVorschlagVersSummeProQm();

	/**
	 * Returns the default value for zahlweise.
	 * 
	 * @generated
	 */
	public Zahlweise getDefaultValueZahlweise();

	/**
	 * Returns the set of allowed values for the property zahlweise.
	 * 
	 * @generated
	 */
	public ValueSet<Zahlweise> getSetOfAllowedValuesForZahlweise(
			IValidationContext context);

	/**
	 * Returns the default value for wohnflaeche.
	 * 
	 * @generated
	 */
	public Integer getDefaultValueWohnflaeche();

	/**
	 * Returns the range of allowed values for the property wohnflaeche.
	 * 
	 * @generated
	 */
	public IntegerRange getRangeForWohnflaeche(IValidationContext context);

	/**
	 * Returns the default value for versSumme.
	 * 
	 * @generated
	 */
	public Money getDefaultValueVersSumme();

	/**
	 * Returns the range of allowed values for the property versSumme.
	 * 
	 * @generated
	 */
	public MoneyRange getRangeForVersSumme(IValidationContext context);

	/**
	 * Returns the referenced HausratDeckungsTypen. Returns an empty array, if
	 * no object is referenced.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             if one of the referenced product component types cant be
	 *             found.
	 * 
	 * @generated
	 */
	public List<IHausratDeckungsTyp> getHausratDeckungsTypen();

	/**
	 * Returns the number of HausratDeckungsTypen.
	 * 
	 * @generated
	 */
	public int getNumOfHausratDeckungsTypen();

	/**
	 * Returns the referenced HausratGrunddeckungsTyp or <null>.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             if the referenced product component cant be found.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp();

	/**
	 * Returns the generation of the referenced HausratGrunddeckungsTyp valid at
	 * the given date or <null>.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             if the referenced product component cant be found.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTypGen getHausratGrunddeckungsTyp(
			Calendar effectiveDate);

	/**
	 * Returns the <code>ILink</code> to the HausratGrunddeckungsTyp or <null>,
	 * if no object is referenced.
	 * 
	 * @generated
	 */
	public IProductComponentLink<IHausratGrunddeckungsTyp> getLinkForHausratGrunddeckungsTyp();

	/**
	 * Returns the <code>ILink</code> to the HausratGrunddeckungsTyp at the
	 * indicated index.
	 * 
	 * @generated
	 */
	public IProductComponentLink<IHausratGrunddeckungsTyp> getLinkForHausratGrunddeckungsTyp(
			IHausratGrunddeckungsTyp productComponent);

	/**
	 * Returns the cardinality for the number of allowed instanced for
	 * HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public CardinalityRange getCardinalityForHausratGrunddeckung(
			IHausratGrunddeckungsTyp productCmpt);

	/**
	 * Returns the referenced HausratZusatzdeckungsTypen. Returns an empty
	 * array, if no object is referenced.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             if one of the referenced product component types cant be
	 *             found.
	 * 
	 * @generated
	 */
	public List<IHausratZusatzdeckungsTyp> getHausratZusatzdeckungsTypen();

	/**
	 * Returns the referenced HausratZusatzdeckungsTypen valid at the given
	 * date. Returns an empty array, if no object is referenced.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             if one of the referenced product component types cant be
	 *             found.
	 * 
	 * @generated
	 */
	public List<IHausratZusatzdeckungsTypGen> getHausratZusatzdeckungsTypen(
			Calendar effectiveDate);

	/**
	 * Returns the HausratZusatzdeckungsTypen at the indicated index.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             if the product component cant be found.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp(int index);

	/**
	 * Returns the referenced HausratZusatzdeckungsTypen. Returns an empty
	 * array, if no object is referenced.
	 * 
	 * @throws org.faktorips.runtime.ProductCmptNotFoundException
	 *             if one of the referenced product component types cant be
	 *             found.
	 * 
	 * @generated
	 */
	public Collection<IProductComponentLink<IHausratZusatzdeckungsTyp>> getLinksForHausratZusatzdeckungsTypen();

	/**
	 * Returns the <code>ILink</code> to the HausratZusatzdeckungsTyp at the
	 * indicated index.
	 * 
	 * @generated
	 */
	public IProductComponentLink<IHausratZusatzdeckungsTyp> getLinkForHausratZusatzdeckungsTyp(
			IHausratZusatzdeckungsTyp productComponent);

	/**
	 * Returns the cardinality for the number of allowed instanced for
	 * HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public CardinalityRange getCardinalityForHausratZusatzdeckung(
			IHausratZusatzdeckungsTyp productCmpt);

	/**
	 * Returns the number of HausratZusatzdeckungsTypen.
	 * 
	 * @generated
	 */
	public int getNumOfHausratZusatzdeckungsTypen();

	/**
	 * Returns the HausratProdukt this generation belongs to.
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProdukt();

}
