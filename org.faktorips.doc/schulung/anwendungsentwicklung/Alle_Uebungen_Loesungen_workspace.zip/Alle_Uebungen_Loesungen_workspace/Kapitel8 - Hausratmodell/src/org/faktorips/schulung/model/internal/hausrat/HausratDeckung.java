/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.AbstractConfigurableModelObject;
import org.faktorips.schulung.model.hausrat.IHausratDeckung;
import org.faktorips.schulung.model.hausrat.IHausratDeckungsTyp;

import org.faktorips.values.Money;

import java.util.Calendar;
import org.faktorips.runtime.internal.AbstractModelObject;
import org.w3c.dom.Element;
import org.faktorips.runtime.IModelObjectDelta;
import org.faktorips.runtime.IModelObject;
import org.faktorips.runtime.IDeltaComputationOptions;
import org.faktorips.runtime.internal.ModelObjectDelta;
import java.util.Map;
import org.faktorips.runtime.IModelObjectVisitor;
import org.faktorips.runtime.MessageList;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.runtime.IConfigurableModelObject;

import org.faktorips.schulung.model.hausrat.IHausratDeckungsTypGen;

/**
 * @generated
 */
public abstract class HausratDeckung extends AbstractConfigurableModelObject
		implements IHausratDeckung {

	/**
	 * Member variable for jahresbasisbeitrag.
	 * 
	 * @generated
	 */
	private Money jahresbasisbeitrag = Money.NULL;

	/**
	 * Creates a new HausratDeckung.
	 * 
	 * @generated
	 */
	public HausratDeckung() {
		super();
	}

	/**
	 * Creates a new HausratDeckung.
	 * 
	 * @generated
	 */
	public HausratDeckung(IHausratDeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * Initializes the object with the configured defaults.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initialize() {

		// begin-user-code
		// end-user-code
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratDeckungsTyp getHausratDeckungsTyp() {
		return (IHausratDeckungsTyp) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratDeckungsTypGen getHausratDeckungsTypGen() {
		return (IHausratDeckungsTypGen) getProductCmptGeneration();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setHausratDeckungsTyp(IHausratDeckungsTyp hausratDeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults) {
		setProductComponent(hausratDeckungsTyp);
		if (initPropertiesWithConfiguratedDefaults) {
			initialize();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void effectiveFromHasChanged() {
		super.effectiveFromHasChanged();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Calendar getEffectiveFromAsCalendar() {
		IModelObject parent = getParentModelObject();
		if (parent instanceof IConfigurableModelObject) {
			return ((IConfigurableModelObject) parent)
					.getEffectiveFromAsCalendar();
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void initPropertiesFromXml(Map<String, String> propMap,
			IRuntimeRepository productRepository) {
		super.initPropertiesFromXml(propMap, productRepository);
		if (propMap.containsKey("jahresbasisbeitrag")) {
			this.jahresbasisbeitrag = Money.valueOf(propMap
					.get("jahresbasisbeitrag"));
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected AbstractModelObject createChildFromXml(Element childEl) {
		AbstractModelObject newChild = super.createChildFromXml(childEl);
		if (newChild != null) {
			return newChild;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObjectDelta computeDelta(IModelObject otherObject,
			IDeltaComputationOptions options) {
		ModelObjectDelta delta = ModelObjectDelta.newDelta(this, otherObject,
				options);
		if (!HausratDeckung.class.isAssignableFrom(otherObject.getClass())) {
			return delta;
		}
		HausratDeckung otherHausratDeckung = (HausratDeckung) otherObject;
		delta.checkPropertyChange(IHausratDeckung.PROPERTY_JAHRESBASISBEITRAG,
				jahresbasisbeitrag, otherHausratDeckung.jahresbasisbeitrag,
				options);
		return delta;
	}

	/**
	 * Internal copy method with a {@link Map} containing already copied
	 * instances.
	 * 
	 * @param copyMap
	 *            the map contains the copied instances
	 * 
	 * @generated
	 */
	public IModelObject newCopyInternal(Map<IModelObject, IModelObject> copyMap) {
		throw new RuntimeException(
				"This method has to be abstract. It needs to have an empty body because of a bug in JMerge.");
	}

	/**
	 * This method sets all properties in the copy with the values of this
	 * object. If there are copied associated objects they are added to the copy
	 * map.
	 * 
	 * @param copy
	 *            The copy object
	 * @param copyMap
	 *            a map containing copied associated objects
	 * 
	 * @generated
	 */
	protected void copyProperties(IModelObject copy,
			Map<IModelObject, IModelObject> copyMap) {
		HausratDeckung concreteCopy = (HausratDeckung) copy;
		concreteCopy.jahresbasisbeitrag = jahresbasisbeitrag;
	}

	/**
	 * Internal method for setting copied associations. For copied targets, the
	 * association have to retarget to the new copied instance. This method have
	 * to call {@link #copyAssociationsInternal(IModelObject, Map)} in other
	 * instances associated by composite.
	 * 
	 * @param abstractCopy
	 *            the copy of this policy component
	 * @param copyMap
	 *            the map contains the copied instances
	 * 
	 * @generated
	 */
	public void copyAssociationsInternal(IModelObject abstractCopy,
			Map<IModelObject, IModelObject> copyMap) {
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public boolean accept(IModelObjectVisitor visitor) {
		if (!visitor.visit(this)) {
			return false;
		}
		return true;
	}

	/**
	 * Validates the object (but not its children). Returns <code>true</code> if
	 * this object should continue validating, <code>false</code> else.
	 * 
	 * @generated
	 */
	@Override
	public boolean validateSelf(MessageList ml, IValidationContext context) {
		if (!super.validateSelf(ml, context)) {
			return STOP_VALIDATION;
		}
		return CONTINUE_VALIDATION;
	}

	/**
	 * Validates the objects children.
	 * 
	 * @generated
	 */
	@Override
	public void validateDependants(MessageList ml, IValidationContext context) {
		super.validateDependants(ml, context);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Money getJahresbasisbeitrag() {
		return jahresbasisbeitrag;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated NOT
	 */
	@Override
	public void berechneJahresbasisbeitrag() {
		jahresbasisbeitrag = berechneJahresbasisbeitragInternal();
	}

	protected abstract Money berechneJahresbasisbeitragInternal();

}
