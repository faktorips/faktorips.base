/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.Table;
import java.util.List;
import java.util.ArrayList;
import org.faktorips.runtime.IRuntimeRepository;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import org.faktorips.values.Decimal;

/**
 * This class represents a read-only in memory table. Data can be accessed by
 * the find-methods of this table.
 * 
 * @generated
 */
public class TariftabelleHausrat extends Table {

	/**
	 * Member variable for key to table row mapping.
	 * 
	 * @generated
	 */
	private Map<UniqueKey0, TariftabelleHausratRow> key0Map;

	/**
	 * Creates an empty table.
	 * 
	 * @generated
	 */
	public TariftabelleHausrat() {
		super();
	}

	/**
	 * Creates a new table based on the indicated rows. The given row list is
	 * copied, so modifying it afterwards does not change the created table.
	 * This constructor can be used in unit tests to define arbitrary table
	 * contents.
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public TariftabelleHausrat(List<TariftabelleHausratRow> content) {
		super();
		rows = new ArrayList(content.size());
		rows.addAll(content);
		initKeyMaps();
	}

	/**
	 * Adds a new table row during the initialization phase.
	 * 
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void addRow(List values, IRuntimeRepository productRepository) {
		String columnValue = (String) values.get(0);
		String tarifzone = columnValue == null ? null : columnValue;
		columnValue = (String) values.get(1);
		Decimal beitragssatz = columnValue == null ? Decimal.NULL : Decimal
				.valueOf(columnValue);
		rows.add(new TariftabelleHausratRow(tarifzone, beitragssatz));
	}

	/**
	 * Initializes the maps that are used by the finder methods of this table.
	 * This method is called during the initialization phase.
	 * 
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void initKeyMaps() {
		key0Map = new HashMap<UniqueKey0, TariftabelleHausratRow>(rows.size());
		for (Iterator<TariftabelleHausratRow> it = rows.iterator(); it
				.hasNext();) {
			TariftabelleHausratRow row = it.next();
			key0Map.put(new UniqueKey0(row.getTarifzone()), row);
		}
	}

	/**
	 * Returns an instance of this table class.
	 * 
	 * @generated
	 */
	public static final TariftabelleHausrat getInstance(
			IRuntimeRepository repository, String qualifiedTableName) {
		return (TariftabelleHausrat) repository.getTable(qualifiedTableName);
	}

	/**
	 * Returns all rows of this table.
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public List<TariftabelleHausratRow> getAllRows() {
		return Collections.unmodifiableList(rows);
	}

	/**
	 * Searches the content of this table for an entry that fits the specified
	 * parameters and returns the according row object. If no entry could be
	 * found, null is returned.
	 * 
	 * @generated
	 */
	public TariftabelleHausratRow findRow(String tarifzone) {
		if (tarifzone == null) {
			return null;
		}
		TariftabelleHausratRow returnValue = key0Map.get(new UniqueKey0(
				tarifzone));
		return returnValue;
	}

	/**
	 * Searches the content of this table for an entry that fits the specified
	 * parameters and returns the according row object. If no entry could be
	 * found, a 'null' row is returned.
	 * 
	 * @generated
	 */
	public TariftabelleHausratRow findRowNullRowReturnedForEmtpyResult(
			String tarifzone) {
		if (tarifzone == null) {
			return TariftabelleHausratRow.NULL_ROW;
		}
		TariftabelleHausratRow returnValue = key0Map.get(new UniqueKey0(
				tarifzone));
		if (returnValue == null) {
			return TariftabelleHausratRow.NULL_ROW;
		}
		return returnValue;
	}

	/**
	 * Instances of this class are used as a hash key. The key specific map of
	 * this table representation is set up with instances of this class.
	 * 
	 * @generated
	 */
	private static final class UniqueKey0 {

		/**
		 * @generated
		 */
		private String tarifzone;
		/**
		 * Cached hashcode.
		 * 
		 * @generated
		 */
		private int hashCode;

		/**
		 * Creates a new key instance with the specified parameters
		 * 
		 * @generated
		 */
		private UniqueKey0(String tarifzone) {
			this.tarifzone = tarifzone;
			hashCode = calculateHashCode();
		}

		/**
		 * @generated
		 */
		private int calculateHashCode() {
			int result = 17;
			result = 37 * result + tarifzone.hashCode();
			return result;
		}

		/**
		 * Overrides the super class method and compares each instance variable
		 * for equality.
		 * 
		 * @generated
		 */
		@Override
		public boolean equals(Object o) {
			if (o instanceof UniqueKey0) {
				UniqueKey0 other = (UniqueKey0) o;
				return tarifzone.equals(other.tarifzone);
			}
			return false;
		}

		/**
		 * Overrides the super class method and creates a hash code based on the
		 * values of the instance variables.
		 * 
		 * @generated
		 */
		@Override
		public int hashCode() {
			return hashCode;
		}

	}

}
