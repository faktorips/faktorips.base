/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IModelObject;
import org.faktorips.runtime.IDeltaSupport;
import org.faktorips.runtime.ICopySupport;
import org.faktorips.runtime.IVisitorSupport;

/**
 * Published Interface von HausratVertrag.
 * 
 * @generated
 */
public interface IHausratVertrag extends IModelObject, IDeltaSupport, ICopySupport, IVisitorSupport {

}
