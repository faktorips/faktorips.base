/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

/**
 * Diese Klasse repraesentiert eine (Read-Only) Zeile einer Tabelle.
 * 
 * @generated
 */
public class TarifzonentabelleRow {

	/**
	 * @generated
	 */
	public static final TarifzonentabelleRow NULL_ROW = new TarifzonentabelleRow(null, null, null);

	/**
	 * @generated
	 */
	private final String plzVon;
	/**
	 * @generated
	 */
	private final String plzBis;
	/**
	 * @generated
	 */
	private final String tarifzone;

	/**
	 * Erzeugt eine neue Zeile.
	 * 
	 * @generated
	 */
	public TarifzonentabelleRow(String plzVon, String plzBis, String tarifzone) {
		this.plzVon = plzVon;
		this.plzBis = plzBis;
		this.tarifzone = tarifzone;
	}

	/**
	 * @generated
	 */
	public String getPlzVon() {
		return plzVon;
	}

	/**
	 * @generated
	 */
	public String getPlzBis() {
		return plzBis;
	}

	/**
	 * @generated
	 */
	public String getTarifzone() {
		return tarifzone;
	}

	/**
	 * @generated
	 */
	@Override
	public String toString() {
		return "" + plzVon + "|" + plzBis + "|" + tarifzone;
	}

}
