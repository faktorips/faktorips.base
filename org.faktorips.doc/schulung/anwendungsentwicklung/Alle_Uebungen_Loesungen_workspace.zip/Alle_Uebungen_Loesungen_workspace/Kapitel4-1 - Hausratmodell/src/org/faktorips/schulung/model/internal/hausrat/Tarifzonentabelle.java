/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.Table;
import java.util.List;
import java.util.ArrayList;
import org.faktorips.runtime.IRuntimeRepository;
import java.util.Collections;
import org.faktorips.runtime.internal.ReadOnlyBinaryRangeTree;
import java.util.HashMap;
import org.faktorips.runtime.internal.ReadOnlyBinaryRangeTree.TwoColumnKey;
import java.util.Iterator;
import org.faktorips.runtime.internal.ReadOnlyBinaryRangeTree.KeyType;

/**
 * Diese Klasse implementiert eine Read-Only In-Memory-Tabelle. Auf die Daten
 * der Tabelle kann ueber Finder-Methoden zugegriffen werden.
 * 
 * @generated
 */
public class Tarifzonentabelle extends Table {

	/**
	 * Membervariable die Keys auf Tabellenzeilen abbildet.
	 * 
	 * @generated
	 */
	private ReadOnlyBinaryRangeTree key0Tree;

	/**
	 * Erzeugt einen leeren Tabelleninhalt.
	 * 
	 * @generated
	 */
	public Tarifzonentabelle() {
		super();
	}

	/**
	 * Erzeugt einen neuen Tabelleninhalt mit den uebergebenen Zeilen. Die Liste
	 * mit den Zeilen wird kopiert. Spaetere Aenderungen an dem Inhalt der
	 * Liste, aendern also nicht die erzeugt Tabelle. Dieser Konstruktor ist vor
	 * allem fuer die Verwendung in JUnit Tests vorgesehen, um beliebige
	 * Tabelleninhalte erzeugen zu koennen.
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public Tarifzonentabelle(List<TarifzonentabelleRow> content) {
		super();
		rows = new ArrayList(content.size());
		rows.addAll(content);
		initKeyMaps();
	}

	/**
	 * Diese Methode wird waehrend der Initialisierung verwendet. Sie fuegt eine
	 * neue Tabellenzeile hinzu.
	 * 
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void addRow(List values, IRuntimeRepository productRepository) {
		String columnValue = (String) values.get(0);
		String plzVon = columnValue == null ? null : columnValue;
		columnValue = (String) values.get(1);
		String plzBis = columnValue == null ? null : columnValue;
		columnValue = (String) values.get(2);
		String tarifzone = columnValue == null ? null : columnValue;
		rows.add(new TarifzonentabelleRow(plzVon, plzBis, tarifzone));
	}

	/**
	 * Initialisiert die Maps dieser Tabelle. Diese werden von den
	 * Finder-Methoden dieser Klasse verwendet.
	 * 
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void initKeyMaps() {
		HashMap<TwoColumnKey, TarifzonentabelleRow> key0MapTemp = new HashMap<TwoColumnKey, TarifzonentabelleRow>(
				rows.size());
		for (Iterator<TarifzonentabelleRow> it = rows.iterator(); it.hasNext();) {
			TarifzonentabelleRow row = it.next();
			key0MapTemp.put(new TwoColumnKey(row.getPlzVon(), row.getPlzBis()), row);
		}
		key0Tree = generateTree(key0MapTemp, new KeyType[] { ReadOnlyBinaryRangeTree.KEY_IS_TWO_COLUMN_KEY });
	}

	/**
	 * Gibt die Instanz dieser Tabellenklasse zurueck.
	 * 
	 * @generated
	 */
	public static final Tarifzonentabelle getInstance(IRuntimeRepository repository) {
		return (Tarifzonentabelle) repository.getTable(Tarifzonentabelle.class);
	}

	/**
	 * Gibt die Instanz dieser Tabellenklasse zurueck.
	 * 
	 * @generated
	 */
	public static final Tarifzonentabelle getInstance(IRuntimeRepository repository, String qualifiedTableName) {
		return (Tarifzonentabelle) repository.getTable(qualifiedTableName);
	}

	/**
	 * Gibt alle Zeilen dieser Tabelle zurueck.
	 * 
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public List<TarifzonentabelleRow> getAllRows() {
		return Collections.unmodifiableList(rows);
	}

	/**
	 * Durchsucht den Inhalt dieser Tabelle nach einem Eintrag entsprechend der
	 * Suchkriterien und gibt diesen Zurueck. Null wird zurueckgegeben falls
	 * kein Eintrag gefunden wird.
	 * 
	 * @generated
	 */
	public TarifzonentabelleRow findRow(String plzVonBis) {
		if (plzVonBis == null) {
			return null;
		}
		TarifzonentabelleRow returnValue = (TarifzonentabelleRow) getValue(key0Tree, new Comparable[] { plzVonBis });
		return returnValue;
	}

	/**
	 * Durchsucht den Inhalt dieser Tabelle nach einem Eintrag entsprechend der
	 * Suchkriterien und gibt diesen Zurueck. Eine 'Null-Row' wird
	 * zurueckgegeben, falls kein Eintrag gefunden wird.
	 * 
	 * @generated
	 */
	public TarifzonentabelleRow findRowNullRowReturnedForEmtpyResult(String plzVonBis) {
		if (plzVonBis == null) {
			return TarifzonentabelleRow.NULL_ROW;
		}
		TarifzonentabelleRow returnValue = (TarifzonentabelleRow) getValue(key0Tree, new Comparable[] { plzVonBis });
		if (returnValue == null) {
			return TarifzonentabelleRow.NULL_ROW;
		}
		return returnValue;
	}

}
