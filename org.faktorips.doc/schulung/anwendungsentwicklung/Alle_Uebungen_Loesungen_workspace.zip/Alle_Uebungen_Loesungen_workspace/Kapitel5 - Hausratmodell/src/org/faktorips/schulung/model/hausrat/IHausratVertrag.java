/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IDeltaSupport;
import org.faktorips.runtime.ICopySupport;
import org.faktorips.runtime.IVisitorSupport;
import org.faktorips.valueset.IntegerRange;
import org.faktorips.valueset.MoneyRange;
import org.faktorips.values.Money;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.runtime.IConfigurableModelObject;
import java.util.GregorianCalendar;
import org.faktorips.valueset.ValueSet;
import java.util.List;

/**
 * Published Interface von HausratVertrag.
 * 
 * @generated
 */
public interface IHausratVertrag extends IConfigurableModelObject, IDeltaSupport, ICopySupport, IVisitorSupport {

	/**
	 * Diese Konstante enthaelt den Namen der Property zahlweise
	 * 
	 * @generated
	 */
	public final static String PROPERTY_ZAHLWEISE = "zahlweise";
	/**
	 * Diese Konstante enthaelt den Namen der Property plz
	 * 
	 * @generated
	 */
	public final static String PROPERTY_PLZ = "plz";
	/**
	 * Diese Konstante enthaelt den Namen der Property tarifzone
	 * 
	 * @generated
	 */
	public final static String PROPERTY_TARIFZONE = "tarifzone";
	/**
	 * Diese Konstante enthaelt den Namen der Property wohnflaeche
	 * 
	 * @generated
	 */
	public final static String PROPERTY_WOHNFLAECHE = "wohnflaeche";
	/**
	 * Gibt den maximal erlaubten Wertebereich fuer die Eigenschaft wohnflaeche
	 * zurueck.
	 * 
	 * @generated
	 */
	public static final IntegerRange MAX_ALLOWED_RANGE_FOR_WOHNFLAECHE = IntegerRange.valueOf(Integer.valueOf("0"),
			(Integer) null, (Integer) null, false);
	/**
	 * Diese Konstante enthaelt den Namen der Property vorschlagVersSumme
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VORSCHLAGVERSSUMME = "vorschlagVersSumme";
	/**
	 * Diese Konstante enthaelt den Namen der Property versSumme
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERSSUMME = "versSumme";
	/**
	 * Gibt den maximal erlaubten Wertebereich fuer die Eigenschaft versSumme
	 * zurueck.
	 * 
	 * @generated
	 */
	public static final MoneyRange MAX_ALLOWED_RANGE_FOR_VERSSUMME = MoneyRange.valueOf(Money.valueOf("0.00 EUR"),
			Money.NULL, Money.NULL, false);

	/**
	 * Diese Konstante enthaelt den Namen der Property wirksamAb
	 * 
	 * @generated
	 */
	public final static String PROPERTY_WIRKSAMAB = "wirksamAb";
	/**
	 * Die maximale Multiplizitaet der Beziehung mit dem Rollennamen
	 * HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public static final IntegerRange MAX_MULTIPLICITY_OF_HAUSRATGRUNDDECKUNG = new IntegerRange(0, 1);
	/**
	 * Diese Konstante enthaelt den Name der Beziehung hausratGrunddeckung.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATGRUNDDECKUNG = "hausratGrunddeckung";

	/**
	 * Die maximale Multiplizitaet der Beziehung mit dem Rollennamen
	 * HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public static final IntegerRange MAX_MULTIPLICITY_OF_HAUSRATZUSATZDECKUNG = new IntegerRange(0, 2147483647);
	/**
	 * Diese Konstante enthaelt den Name der Beziehung hausratZusatzdeckungen.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATZUSATZDECKUNGEN = "hausratZusatzdeckungen";

	/**
	 * Gibt den erlaubte Wertebereich fuer das Attribute zahlweise zurueck.
	 * 
	 * @generated
	 */
	public ValueSet<Zahlweise> getSetOfAllowedValuesForZahlweise(IValidationContext context);

	/**
	 * Gibt den Wert des Attributs zahlweise zurueck.
	 * 
	 * @generated
	 */
	public Zahlweise getZahlweise();

	/**
	 * Setzt den Wert des Attributs zahlweise.
	 * 
	 * @generated
	 */
	public void setZahlweise(Zahlweise newValue);

	/**
	 * Gibt den Wert des Attributs plz zurueck.
	 * 
	 * @generated
	 */
	public String getPlz();

	/**
	 * Setzt den Wert des Attributs plz.
	 * 
	 * @generated
	 */
	public void setPlz(String newValue);

	/**
	 * Gibt den Wert des Attributs tarifzone zurueck.
	 * 
	 * @generated
	 */
	public String getTarifzone();

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribut wohnflaeche zurueck.
	 * 
	 * @generated
	 */
	public IntegerRange getRangeForWohnflaeche(IValidationContext context);

	/**
	 * Gibt den Wert des Attributs wohnflaeche zurueck.
	 * 
	 * @generated
	 */
	public Integer getWohnflaeche();

	/**
	 * Setzt den Wert des Attributs wohnflaeche.
	 * 
	 * @generated
	 */
	public void setWohnflaeche(Integer newValue);

	/**
	 * Gibt den Wert des Attributs vorschlagVersSumme zurueck.
	 * 
	 * @generated
	 */
	public Money getVorschlagVersSumme();

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribut versSumme zurueck.
	 * 
	 * @generated
	 */
	public MoneyRange getRangeForVersSumme(IValidationContext context);

	/**
	 * Gibt den Wert des Attributs versSumme zurueck.
	 * 
	 * @generated
	 */
	public Money getVersSumme();

	/**
	 * Setzt den Wert des Attributs versSumme.
	 * 
	 * @generated
	 */
	public void setVersSumme(Money newValue);

	/**
	 * Gibt den Wert des Attributs wirksamAb zurueck.
	 * 
	 * @generated
	 */
	public GregorianCalendar getWirksamAb();

	/**
	 * Setzt den Wert des Attributs wirksamAb.
	 * 
	 * @generated
	 */
	public void setWirksamAb(GregorianCalendar newValue);

	/**
	 * Gibt das referenzierte HausratGrunddeckung-Objekt zurueck.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung getHausratGrunddeckung();

	/**
	 * Setzt das uebergebene Objekt in der Beziehung HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckung(IHausratGrunddeckung newObject);

	/**
	 * Erzeugt ein neues HausratGrunddeckung-Objekt und fuegt es zu diesem
	 * Objekt in der Rolle HausratGrunddeckung hinzu.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung newHausratGrunddeckung();

	/**
	 * Erzeugt ein neues HausratGrunddeckung-Objekt und fuegt es zu diesem
	 * Objekt in der Rolle HausratGrunddeckung hinzu.
	 * 
	 * @param iHausratGrunddeckungsTyp
	 *            Der Produktbaustein, auf dem das neue Objekt basiert.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung newHausratGrunddeckung(IHausratGrunddeckungsTyp iHausratGrunddeckungsTyp);

	/**
	 * Gibt die Anzahl der HausratZusatzdeckungen zurueck.
	 * 
	 * @generated
	 */
	public int getNumOfHausratZusatzdeckungen();

	/**
	 * Gibt <code>true</code> zurueck, falls das uebergebene Objekt in der
	 * Beziehung enthalten ist, ansonsten <code>false</code>.
	 * 
	 * @generated
	 */
	public boolean containsHausratZusatzdeckung(IHausratZusatzdeckung objectToTest);

	/**
	 * Gibt die referenzierten HausratZusatzdeckungen zurueck.
	 * 
	 * @generated
	 */
	public List<IHausratZusatzdeckung> getHausratZusatzdeckungen();

	/**
	 * Fuegt das uebergebene Objekt zu der Beziehung HausratZusatzdeckung hinzu.
	 * 
	 * @generated
	 */
	public void addHausratZusatzdeckung(IHausratZusatzdeckung objectToAdd);

	/**
	 * Entfernt das uebergebene Objekt aus der Beziehung HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	public void removeHausratZusatzdeckung(IHausratZusatzdeckung objectToRemove);

	/**
	 * Erzeugt ein neues HausratZusatzdeckung-Objekt und fuegt es zu diesem
	 * Objekt in der Rolle HausratZusatzdeckung hinzu.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung newHausratZusatzdeckung();

	/**
	 * Erzeugt ein neues HausratZusatzdeckung-Objekt und fuegt es zu diesem
	 * Objekt in der Rolle HausratZusatzdeckung hinzu.
	 * 
	 * @param iHausratZusatzdeckungsTyp
	 *            Der Produktbaustein, auf dem das neue Objekt basiert.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung newHausratZusatzdeckung(IHausratZusatzdeckungsTyp iHausratZusatzdeckungsTyp);

	/**
	 * Gibt das Objekt aus der Beziehung HausratZusatzdeckung an der indizierten
	 * Stelle zurueck.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung getHausratZusatzdeckung(int index);

	/**
	 * Gibt d. HausratProdukt zurueck, welches d. HausratVertrag konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProdukt();

	/**
	 * Setzt d. neue HausratProdukt.
	 * 
	 * @param hausratProdukt
	 *            D. neue HausratProdukt.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> falls die Eigenschaften mit den Defaultwerte
	 *            aus d. HausratProdukt belegt werden sollen.
	 * 
	 * @generated
	 */
	public void setHausratProdukt(IHausratProdukt hausratProdukt, boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Gibt d. Anpassungsstufe zurueck, welches d. HausratProdukt konfiguriert.
	 * D. Anpassungsstufe wird anhand des Wirksamkeitsdatum ermittelt.
	 * 
	 * @generated
	 */
	public IHausratProduktAnpStufe getHausratProduktAnpStufe();

	/**
	 * Gibt d. HausratProdukt zurueck, welches d. HausratVertrag konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProduktGen();

}
