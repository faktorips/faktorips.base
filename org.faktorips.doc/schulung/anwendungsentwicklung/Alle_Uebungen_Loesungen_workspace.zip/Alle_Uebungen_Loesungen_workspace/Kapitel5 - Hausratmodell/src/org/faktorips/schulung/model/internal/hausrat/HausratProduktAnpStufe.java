/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.ProductComponentGeneration;
import org.faktorips.schulung.model.hausrat.IHausratProduktAnpStufe;
import org.faktorips.runtime.IllegalRepositoryModificationException;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.runtime.internal.ValueToXmlHelper;
import org.faktorips.runtime.IProductComponentLink;
import org.faktorips.runtime.IProductComponent;
import java.util.List;
import java.util.ArrayList;
import org.faktorips.values.Money;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.valueset.MoneyRange;
import org.faktorips.runtime.internal.Range;
import org.faktorips.valueset.IntegerRange;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTyp;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTypAnpStufe;
import java.util.Calendar;
import org.faktorips.runtime.internal.ProductComponentLink;
import org.faktorips.runtime.CardinalityRange;
import org.faktorips.schulung.model.hausrat.Zahlweise;
import org.faktorips.valueset.OrderedValueSet;
import org.faktorips.runtime.internal.EnumValues;
import org.faktorips.valueset.ValueSet;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTyp;
import java.util.LinkedHashMap;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTypAnpStufe;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Collection;
import java.util.Collections;
import org.faktorips.valueset.UnrestrictedValueSet;
import org.faktorips.runtime.internal.IXmlPersistenceSupport;

/**
 * Die Implementierung von IHausratProduktAnpStufe.
 * 
 * @generated
 */
public class HausratProduktAnpStufe extends ProductComponentGeneration implements IHausratProduktAnpStufe {

	/**
	 * Membervariable fuer die Produkteigenschaft Produktname.
	 * 
	 * @generated
	 */
	private String produktname = null;
	/**
	 * Membervariable fuer die Produkteigenschaft Vertriebsname.
	 * 
	 * @generated
	 */
	private String vertriebsname = null;

	/**
	 * Membervariable fuer die Produkteigenschaft VorschlagVersSummeProQm.
	 * 
	 * @generated
	 */
	private Money vorschlagVersSummeProQm = Money.NULL;

	/**
	 * Membervariable fuer den Vorgabewert der Vertragseigenschaft zahlweise.
	 * 
	 * @generated
	 */
	private Zahlweise defaultValueZahlweise = null;
	/**
	 * Instanzvariable fuer die erlaubte Wertemenge des Attributes zahlweise .
	 * 
	 * @generated
	 */
	private ValueSet<Zahlweise> setOfAllowedValuesZahlweise;
	/**
	 * Membervariable fuer den Vorgabewert der Vertragseigenschaft wohnflaeche.
	 * 
	 * @generated
	 */
	private Integer defaultValueWohnflaeche = null;
	/**
	 * Instanzvariable fuer den Wertebereich des Attributs wohnflaeche .
	 * 
	 * @generated
	 */
	private IntegerRange rangeForWohnflaeche;
	/**
	 * Membervariable fuer den Vorgabewert der Vertragseigenschaft versSumme.
	 * 
	 * @generated
	 */
	private Money defaultValueVersSumme = Money.NULL;
	/**
	 * Instanzvariable fuer den Wertebereich des Attributs versSumme .
	 * 
	 * @generated
	 */
	private MoneyRange rangeForVersSumme;

	/**
	 * Membervariable fuer die Beziehung HausratGrunddeckungsTyp
	 * 
	 * @generated
	 */
	private IProductComponentLink<IHausratGrunddeckungsTyp> hausratGrunddeckungsTyp = null;

	/**
	 * Membervariable fuer die Beziehung HausratZusatzdeckungsTypen
	 * 
	 * @generated
	 */
	private Map<String, IProductComponentLink<IHausratZusatzdeckungsTyp>> hausratZusatzdeckungsTypen = new LinkedHashMap<String, IProductComponentLink<IHausratZusatzdeckungsTyp>>(
			0);

	/**
	 * Erzeugt eine neue Instanz von HausratProduktAnpStufe.
	 * 
	 * @generated
	 */
	public HausratProduktAnpStufe(HausratProdukt productCmpt) {
		super(productCmpt);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public String getProduktname() {
		return produktname;
	}

	/**
	 * Setzt den Wert der Eigenschaft produktname.
	 * 
	 * @generated
	 */
	public void setProduktname(String newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.produktname = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public String getVertriebsname() {
		return vertriebsname;
	}

	/**
	 * Setzt den Wert der Eigenschaft vertriebsname.
	 * 
	 * @generated
	 */
	public void setVertriebsname(String newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.vertriebsname = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public Money getVorschlagVersSummeProQm() {
		return vorschlagVersSummeProQm;
	}

	/**
	 * Setzt den Wert der Eigenschaft vorschlagVersSummeProQm.
	 * 
	 * @generated
	 */
	public void setVorschlagVersSummeProQm(Money newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.vorschlagVersSummeProQm = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Zahlweise getDefaultValueZahlweise() {
		return defaultValueZahlweise;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public ValueSet<Zahlweise> getSetOfAllowedValuesForZahlweise(IValidationContext context) {
		return setOfAllowedValuesZahlweise;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Integer getDefaultValueWohnflaeche() {
		return defaultValueWohnflaeche;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IntegerRange getRangeForWohnflaeche(IValidationContext context) {
		return rangeForWohnflaeche;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Money getDefaultValueVersSumme() {
		return defaultValueVersSumme;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public MoneyRange getRangeForVersSumme(IValidationContext context) {
		return rangeForVersSumme;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp() {
		return hausratGrunddeckungsTyp != null ? hausratGrunddeckungsTyp.getTarget() : null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTypAnpStufe getHausratGrunddeckungsTyp(Calendar effectiveDate) {
		return hausratGrunddeckungsTyp != null ? hausratGrunddeckungsTyp.getTarget()
				.getHausratGrunddeckungsTypAnpStufe(effectiveDate) : null;
	}

	/**
	 * Setzt das neue referenzierte HausratGrunddeckungsTyp-Objekt.
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckungsTyp(IHausratGrunddeckungsTyp target) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		hausratGrunddeckungsTyp = (target == null ? null : new ProductComponentLink<IHausratGrunddeckungsTyp>(this,
				target));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IProductComponentLink<IHausratGrunddeckungsTyp> getLinkForHausratGrunddeckungsTyp() {
		return hausratGrunddeckungsTyp;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IProductComponentLink<IHausratGrunddeckungsTyp> getLinkForHausratGrunddeckungsTyp(
			IHausratGrunddeckungsTyp productComponent) {
		return hausratGrunddeckungsTyp.getTargetId().equals(productComponent.getId()) ? hausratGrunddeckungsTyp : null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public CardinalityRange getCardinalityForHausratGrunddeckung(IHausratGrunddeckungsTyp productCmpt) {
		if (productCmpt != null) {
			return hausratGrunddeckungsTyp != null && hausratGrunddeckungsTyp.getTargetId().equals(productCmpt.getId()) ? hausratGrunddeckungsTyp
					.getCardinality() : null;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public List<IHausratZusatzdeckungsTyp> getHausratZusatzdeckungsTypen() {
		List<IHausratZusatzdeckungsTyp> result = new ArrayList<IHausratZusatzdeckungsTyp>(
				hausratZusatzdeckungsTypen.size());
		for (IProductComponentLink<IHausratZusatzdeckungsTyp> hausratZusatzdeckungsTyp : hausratZusatzdeckungsTypen
				.values()) {
			result.add(hausratZusatzdeckungsTyp.getTarget());
		}
		return result;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public List<IHausratZusatzdeckungsTypAnpStufe> getHausratZusatzdeckungsTypen(Calendar effectiveDate) {
		List<IHausratZusatzdeckungsTyp> targets = getHausratZusatzdeckungsTypen();
		List<IHausratZusatzdeckungsTypAnpStufe> result = new ArrayList<IHausratZusatzdeckungsTypAnpStufe>();
		for (IHausratZusatzdeckungsTyp target : targets) {
			IHausratZusatzdeckungsTypAnpStufe gen = target.getHausratZusatzdeckungsTypAnpStufe(effectiveDate);
			if (gen != null) {
				result.add(gen);
			}
		}
		return result;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp(int index) {
		Iterator<IProductComponentLink<IHausratZusatzdeckungsTyp>> it = hausratZusatzdeckungsTypen.values().iterator();
		try {
			for (int i = 0; i < index; i++) {
				it.next();
			}
			return it.next().getTarget();
		} catch (NoSuchElementException e) {
			throw new IndexOutOfBoundsException(e.getLocalizedMessage());
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public Collection<IProductComponentLink<IHausratZusatzdeckungsTyp>> getLinksForHausratZusatzdeckungsTypen() {
		return Collections.unmodifiableCollection(hausratZusatzdeckungsTypen.values());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IProductComponentLink<IHausratZusatzdeckungsTyp> getLinkForHausratZusatzdeckungsTyp(
			IHausratZusatzdeckungsTyp productComponent) {
		return hausratZusatzdeckungsTypen.get(productComponent.getId());
	}

	/**
	 * Fuegt den gegebenen Produktbaustein zu diesem hinzu.
	 * 
	 * @generated
	 */
	public void addHausratZusatzdeckungsTyp(IHausratZusatzdeckungsTyp target) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.hausratZusatzdeckungsTypen.put(target.getId(), new ProductComponentLink<IHausratZusatzdeckungsTyp>(this,
				target));
	}

	/**
	 * Fuegt den gegebenen Produktbaustein mit der gegebenen Kardinalitaet zu
	 * diesem hinzu.
	 * 
	 * @generated
	 */
	public void addHausratZusatzdeckungsTyp(IHausratZusatzdeckungsTyp target, CardinalityRange cardinality) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.hausratZusatzdeckungsTypen.put(target.getId(), new ProductComponentLink<IHausratZusatzdeckungsTyp>(this,
				target, cardinality));
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public CardinalityRange getCardinalityForHausratZusatzdeckung(IHausratZusatzdeckungsTyp productCmpt) {
		if (productCmpt != null) {
			return hausratZusatzdeckungsTypen.containsKey(productCmpt.getId()) ? hausratZusatzdeckungsTypen.get(
					productCmpt.getId()).getCardinality() : null;
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public int getNumOfHausratZusatzdeckungsTypen() {
		return hausratZusatzdeckungsTypen.size();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratProdukt getHausratProdukt() {
		return (IHausratProdukt) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
		Element configElement = null;
		String value = null;
		configElement = configMap.get("produktname");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			this.produktname = value;
		}
		configElement = configMap.get("vertriebsname");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			this.vertriebsname = value;
		}
		configElement = configMap.get("vorschlagVersSummeProQm");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			this.vorschlagVersSummeProQm = Money.valueOf(value);
		}
		configElement = configMap.get("zahlweise");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			defaultValueZahlweise = getRepository().getEnumValue(Zahlweise.class, value);
			setOfAllowedValuesZahlweise = new OrderedValueSet<Zahlweise>(
					getRepository().getEnumValues(Zahlweise.class), true, null);
			EnumValues values = ValueToXmlHelper.getEnumValueSetFromElement(configElement, "ValueSet");
			if (values != null) {
				ArrayList<Zahlweise> enumValues = new ArrayList<Zahlweise>();
				for (int i = 0; i < values.getNumberOfValues(); i++) {
					enumValues.add(getRepository().getEnumValue(Zahlweise.class, values.getValue(i)));
				}
				setOfAllowedValuesZahlweise = new OrderedValueSet<Zahlweise>(enumValues, values.containsNull(), null);
			}
		}
		configElement = configMap.get("wohnflaeche");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			defaultValueWohnflaeche = (value == null || value.equals("")) ? null : new Integer(value);
			Range range = ValueToXmlHelper.getRangeFromElement(configElement, "ValueSet");
			if (range != null) {
				rangeForWohnflaeche = IntegerRange.valueOf(range.getLower(), range.getUpper(), range.getStep(),
						range.containsNull());
			}
		}
		configElement = configMap.get("versSumme");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			defaultValueVersSumme = Money.valueOf(value);
			Range range = ValueToXmlHelper.getRangeFromElement(configElement, "ValueSet");
			if (range != null) {
				rangeForVersSumme = MoneyRange.valueOf(range.getLower(), range.getUpper(), range.getStep(),
						range.containsNull());
			}
		}
	}

	/**
	 * @generated
	 */
	@Override
	protected void doInitReferencesFromXml(Map<String, List<Element>> elementsMap) {
		super.doInitReferencesFromXml(elementsMap);
		List<Element> associationElements = elementsMap.get("HausratGrunddeckungsTyp");
		if (associationElements != null) {
			Element element = associationElements.get(0);
			hausratGrunddeckungsTyp = new ProductComponentLink<IHausratGrunddeckungsTyp>(this);
			hausratGrunddeckungsTyp.initFromXml(element);
		}
		associationElements = elementsMap.get("HausratZusatzdeckungsTyp");
		if (associationElements != null) {
			this.hausratZusatzdeckungsTypen = new LinkedHashMap<String, IProductComponentLink<IHausratZusatzdeckungsTyp>>(
					associationElements.size());
			for (Element element : associationElements) {
				IProductComponentLink<IHausratZusatzdeckungsTyp> link = new ProductComponentLink<IHausratZusatzdeckungsTyp>(
						this);
				link.initFromXml(element);
				this.hausratZusatzdeckungsTypen.put(link.getTargetId(), link);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void writePropertiesToXml(Element element) {
		super.writePropertiesToXml(element);
		Element attributeElement = null;
		attributeElement = element.getOwnerDocument().createElement("AttributeValue");
		attributeElement.setAttribute("attribute", "produktname");
		ValueToXmlHelper.addValueToElement(produktname, attributeElement, "Value");
		element.appendChild(attributeElement);
		attributeElement = element.getOwnerDocument().createElement("AttributeValue");
		attributeElement.setAttribute("attribute", "vertriebsname");
		ValueToXmlHelper.addValueToElement(vertriebsname, attributeElement, "Value");
		element.appendChild(attributeElement);
		attributeElement = element.getOwnerDocument().createElement("AttributeValue");
		attributeElement.setAttribute("attribute", "vorschlagVersSummeProQm");
		ValueToXmlHelper.addValueToElement(vorschlagVersSummeProQm == null ? null : vorschlagVersSummeProQm.toString(),
				attributeElement, "Value");
		element.appendChild(attributeElement);
		Element configElement = null;
		Element valueSetElement = null;
		Element valueSetValuesElement = null;
		configElement = element.getOwnerDocument().createElement("ConfigElement");
		configElement.setAttribute("attribute", "zahlweise");
		ValueToXmlHelper.addValueToElement(defaultValueZahlweise == null ? null : defaultValueZahlweise.toString(),
				configElement, "Value");
		valueSetElement = element.getOwnerDocument().createElement("ValueSet");
		valueSetElement.setAttribute("abstract", "false");
		if (setOfAllowedValuesZahlweise instanceof UnrestrictedValueSet) {
			Element unrestrictedValueSetElement = element.getOwnerDocument().createElement("Unrestricted");
			Element valueElement = unrestrictedValueSetElement.getOwnerDocument().createElement("AllValues");
			unrestrictedValueSetElement.appendChild(valueElement);
			valueSetElement.appendChild(unrestrictedValueSetElement);
		}
		if (setOfAllowedValuesZahlweise instanceof OrderedValueSet) {
			valueSetValuesElement = element.getOwnerDocument().createElement("Enum");
			valueSetValuesElement.setAttribute("containsNull",
					Boolean.toString(setOfAllowedValuesZahlweise.containsNull()));
			for (org.faktorips.schulung.model.hausrat.Zahlweise value : setOfAllowedValuesZahlweise.getValues(true)) {
				Element valueElement = element.getOwnerDocument().createElement("Value");
				ValueToXmlHelper.addValueToElement(value == null ? null : value.toString(), valueElement, "Data");
				valueSetValuesElement.appendChild(valueElement);
			}
			valueSetElement.appendChild(valueSetValuesElement);
		}
		configElement.appendChild(valueSetElement);
		element.appendChild(configElement);
		configElement = element.getOwnerDocument().createElement("ConfigElement");
		configElement.setAttribute("attribute", "wohnflaeche");
		ValueToXmlHelper.addValueToElement(defaultValueWohnflaeche == null ? null : defaultValueWohnflaeche.toString(),
				configElement, "Value");
		valueSetElement = element.getOwnerDocument().createElement("ValueSet");
		valueSetElement.setAttribute("abstract", "false");
		valueSetValuesElement = element.getOwnerDocument().createElement("Range");
		valueSetValuesElement.setAttribute("containsNull", Boolean.toString(rangeForWohnflaeche.containsNull()));
		ValueToXmlHelper.addValueToElement(rangeForWohnflaeche.getLowerBound() == null ? null : rangeForWohnflaeche
				.getLowerBound().toString(), valueSetValuesElement, "LowerBound");
		ValueToXmlHelper.addValueToElement(rangeForWohnflaeche.getUpperBound() == null ? null : rangeForWohnflaeche
				.getUpperBound().toString(), valueSetValuesElement, "UpperBound");
		ValueToXmlHelper.addValueToElement(rangeForWohnflaeche.getStep() == null ? null : rangeForWohnflaeche.getStep()
				.toString(), valueSetValuesElement, "Step");
		valueSetElement.appendChild(valueSetValuesElement);
		configElement.appendChild(valueSetElement);
		element.appendChild(configElement);
		configElement = element.getOwnerDocument().createElement("ConfigElement");
		configElement.setAttribute("attribute", "versSumme");
		ValueToXmlHelper.addValueToElement(defaultValueVersSumme == null ? null : defaultValueVersSumme.toString(),
				configElement, "Value");
		valueSetElement = element.getOwnerDocument().createElement("ValueSet");
		valueSetElement.setAttribute("abstract", "false");
		valueSetValuesElement = element.getOwnerDocument().createElement("Range");
		valueSetValuesElement.setAttribute("containsNull", Boolean.toString(rangeForVersSumme.containsNull()));
		ValueToXmlHelper.addValueToElement(rangeForVersSumme.getLowerBound() == null ? null : rangeForVersSumme
				.getLowerBound().toString(), valueSetValuesElement, "LowerBound");
		ValueToXmlHelper.addValueToElement(rangeForVersSumme.getUpperBound() == null ? null : rangeForVersSumme
				.getUpperBound().toString(), valueSetValuesElement, "UpperBound");
		ValueToXmlHelper.addValueToElement(rangeForVersSumme.getStep() == null ? null : rangeForVersSumme.getStep()
				.toString(), valueSetValuesElement, "Step");
		valueSetElement.appendChild(valueSetValuesElement);
		configElement.appendChild(valueSetElement);
		element.appendChild(configElement);
	}

	/**
	 * @generated
	 */
	@Override
	protected void writeReferencesToXml(Element element) {
		super.writeReferencesToXml(element);
		element.appendChild(((IXmlPersistenceSupport) hausratGrunddeckungsTyp).toXml(element.getOwnerDocument()));
		for (IProductComponentLink<IHausratZusatzdeckungsTyp> link : hausratZusatzdeckungsTypen.values()) {
			element.appendChild(((IXmlPersistenceSupport) link).toXml(element.getOwnerDocument()));
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IProductComponentLink<? extends IProductComponent> getLink(String linkName, IProductComponent target) {
		if ("HausratGrunddeckungsTyp".equals(linkName)) {
			return getLinkForHausratGrunddeckungsTyp((IHausratGrunddeckungsTyp) target);
		}
		if ("HausratZusatzdeckungsTyp".equals(linkName)) {
			return getLinkForHausratZusatzdeckungsTyp((IHausratZusatzdeckungsTyp) target);
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public List<IProductComponentLink<? extends IProductComponent>> getLinks() {
		List<IProductComponentLink<? extends IProductComponent>> list = new ArrayList<IProductComponentLink<? extends IProductComponent>>();
		if (getLinkForHausratGrunddeckungsTyp() != null) {
			list.add(getLinkForHausratGrunddeckungsTyp());
		}
		list.addAll(getLinksForHausratZusatzdeckungsTypen());
		return list;
	}

}
