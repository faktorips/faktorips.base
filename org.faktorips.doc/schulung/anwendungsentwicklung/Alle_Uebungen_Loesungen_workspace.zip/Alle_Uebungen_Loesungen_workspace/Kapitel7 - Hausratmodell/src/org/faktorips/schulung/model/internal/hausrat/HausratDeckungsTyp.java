/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.ProductComponent;
import org.faktorips.schulung.model.hausrat.IHausratDeckungsTyp;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.schulung.model.hausrat.IHausratDeckungsTypAnpStufe;
import java.util.Calendar;
import java.util.Map;
import org.w3c.dom.Element;

/**
 * The implementation of IHausratDeckungsTyp.
 * 
 * @generated
 */
public abstract class HausratDeckungsTyp extends ProductComponent implements IHausratDeckungsTyp {

	/**
	 * Erzeugt eine neue Instanz von HausratDeckungsTyp.
	 * 
	 * @generated
	 */
	public HausratDeckungsTyp(IRuntimeRepository repository, String id, String kindId, String generationId) {
		super(repository, id, kindId, generationId);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratDeckungsTypAnpStufe getHausratDeckungsTypAnpStufe(Calendar wirksamkeitsdatum) {
		return (IHausratDeckungsTypAnpStufe) getRepository().getProductComponentGeneration(getId(), wirksamkeitsdatum);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void writePropertiesToXml(Element element) {
		super.writePropertiesToXml(element);
	}

}
