/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IProductComponent;
import java.util.Calendar;

/**
 * Published Interface von HausratDeckungsTyp.
 * 
 * @generated
 */
public interface IHausratDeckungsTyp extends IProductComponent {

	/**
	 * Gibt die Anpassungsstufe zum uebergebenen Wirksamkeitsdatum zurueck. Gibt
	 * <code>null</code> zurueck, wenn es zu dem Datum keine gueltige
	 * Anpassungsstufe gibt.
	 * 
	 * @generated
	 */
	public IHausratDeckungsTypAnpStufe getHausratDeckungsTypAnpStufe(Calendar wirksamkeitsdatum);

}
