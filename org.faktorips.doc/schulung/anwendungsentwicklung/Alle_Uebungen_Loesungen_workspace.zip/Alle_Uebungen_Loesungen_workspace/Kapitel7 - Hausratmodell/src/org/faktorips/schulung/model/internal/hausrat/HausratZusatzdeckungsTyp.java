/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTyp;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTypAnpStufe;
import java.util.Calendar;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckung;
import org.faktorips.runtime.IConfigurableModelObject;

/**
 * The implementation of IHausratZusatzdeckungsTyp.
 * 
 * @generated
 */
public class HausratZusatzdeckungsTyp extends HausratDeckungsTyp implements IHausratZusatzdeckungsTyp {

	/**
	 * Erzeugt eine neue Instanz von HausratZusatzdeckungsTyp.
	 * 
	 * @generated
	 */
	public HausratZusatzdeckungsTyp(IRuntimeRepository repository, String id, String kindId, String generationId) {
		super(repository, id, kindId, generationId);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratZusatzdeckungsTypAnpStufe getHausratZusatzdeckungsTypAnpStufe(Calendar wirksamkeitsdatum) {
		return (IHausratZusatzdeckungsTypAnpStufe) getRepository().getProductComponentGeneration(getId(),
				wirksamkeitsdatum);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void writePropertiesToXml(Element element) {
		super.writePropertiesToXml(element);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratZusatzdeckung createHausratZusatzdeckung() {
		return new HausratZusatzdeckung(this);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IConfigurableModelObject createPolicyComponent() {
		return createHausratZusatzdeckung();
	}

}
