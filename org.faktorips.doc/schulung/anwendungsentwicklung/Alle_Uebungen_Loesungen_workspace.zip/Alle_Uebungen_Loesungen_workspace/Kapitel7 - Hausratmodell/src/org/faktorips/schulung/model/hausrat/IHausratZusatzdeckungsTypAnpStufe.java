/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.values.Decimal;
import org.faktorips.values.Money;
import org.faktorips.runtime.FormulaExecutionException;

/**
 * Die Anpassungsstufe von HausratZusatzdeckungsTyp.
 * 
 * @generated
 */
public interface IHausratZusatzdeckungsTypAnpStufe extends IHausratDeckungsTypAnpStufe {

	/**
	 * Diese Konstante enthaelt den Namen der Property bezeichnung
	 * 
	 * @generated
	 */
	public final static String PROPERTY_BEZEICHNUNG = "bezeichnung";

	/**
	 * Diese Konstante enthaelt den Namen der Property versSummeFaktor
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERSSUMMEFAKTOR = "versSummeFaktor";

	/**
	 * Diese Konstante enthaelt den Namen der Property maximaleVersSumme
	 * 
	 * @generated
	 */
	public final static String PROPERTY_MAXIMALEVERSSUMME = "maximaleVersSumme";

	/**
	 * Gibt den Wert der Eigenschaft bezeichnung zurueck.
	 * 
	 * @generated
	 */
	public String getBezeichnung();

	/**
	 * Gibt den Wert der Eigenschaft versSummeFaktor zurueck.
	 * 
	 * @generated
	 */
	public Decimal getVersSummeFaktor();

	/**
	 * Gibt den Wert der Eigenschaft maximaleVersSumme zurueck.
	 * 
	 * @generated
	 */
	public Money getMaximaleVersSumme();

	/**
	 * @generated
	 */
	public Money computeJahresbeitrag(Money versSumme) throws FormulaExecutionException;

	/**
	 * Gibt d HausratZusatzdeckungsTyp zurueck, zu dem diese Anpassungsstufe
	 * gehoert.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp();

}
