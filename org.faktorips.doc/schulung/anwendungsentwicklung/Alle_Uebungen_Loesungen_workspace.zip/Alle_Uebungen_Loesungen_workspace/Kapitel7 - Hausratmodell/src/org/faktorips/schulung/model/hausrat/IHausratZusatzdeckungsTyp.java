/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import java.util.Calendar;

/**
 * Published Interface von HausratZusatzdeckungsTyp.
 * 
 * @generated
 */
public interface IHausratZusatzdeckungsTyp extends IHausratDeckungsTyp {

	/**
	 * Gibt die Anpassungsstufe zum uebergebenen Wirksamkeitsdatum zurueck. Gibt
	 * <code>null</code> zurueck, wenn es zu dem Datum keine gueltige
	 * Anpassungsstufe gibt.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTypAnpStufe getHausratZusatzdeckungsTypAnpStufe(Calendar wirksamkeitsdatum);

	/**
	 * Erzeugt eine neue Instanz von HausratZusatzdeckung, die durch diesen
	 * Produktbaustein konfiguriert wird.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung createHausratZusatzdeckung();

}
