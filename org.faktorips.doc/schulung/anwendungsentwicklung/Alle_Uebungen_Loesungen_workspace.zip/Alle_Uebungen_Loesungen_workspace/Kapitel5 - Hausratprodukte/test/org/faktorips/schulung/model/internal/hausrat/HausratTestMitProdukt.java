package org.faktorips.schulung.model.internal.hausrat;

import static org.junit.Assert.*;

import java.util.GregorianCalendar;

import org.faktorips.runtime.ClassloaderRuntimeRepository;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTyp;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import org.faktorips.schulung.model.hausrat.IHausratProduktAnpStufe;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckung;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTyp;
import org.faktorips.schulung.model.hausrat.Zahlweise;
import org.faktorips.values.Money;
import org.junit.Before;
import org.junit.Test;

public class HausratTestMitProdukt {

	private IRuntimeRepository repository;

	@Before
	public void setUp() {
		// Repository erzeugen
		repository = ClassloaderRuntimeRepository
				.create("org/faktorips/schulung/produktdaten/internal/faktorips-repository-toc.xml");
	}

	@Test
	public void testGetVorgeschlageneVersSumme() throws Exception {
		IHausratProdukt hrKompakt = (IHausratProdukt) repository.getProductComponent("hausrat.HR-Kompakt 2012-01");
		IHausratVertrag hausratVertrag = hrKompakt.createHausratVertrag();
		hausratVertrag.setWohnflaeche(80);
		hausratVertrag.setWirksamAb(new GregorianCalendar(2012, 0, 1));

		assertEquals(Money.euro(80 * 600), hausratVertrag.getVorschlagVersSumme());
	}

	@Test
	public void testGetTarifzone() {
		IHausratProdukt hrKompakt = (IHausratProdukt) repository.getProductComponent("hausrat.HR-Kompakt 2012-01");
		IHausratVertrag hausratVertrag = hrKompakt.createHausratVertrag();
		assertEquals("I", hausratVertrag.getTarifzone());

		hausratVertrag.setPlz("12345");
		assertEquals("I", hausratVertrag.getTarifzone());

		hausratVertrag.setPlz("17235");
		assertEquals("II", hausratVertrag.getTarifzone());

		hausratVertrag.setPlz("47279");
		assertEquals("V", hausratVertrag.getTarifzone());
	}

	@Test
	public void testBerechneJahresbasisbeitrag() throws Exception {
		IHausratProdukt hrKompakt = (IHausratProdukt) repository.getProductComponent("hausrat.HR-Kompakt 2012-01");
		IHausratVertrag hausratVertrag = hrKompakt.createHausratVertrag();
		hausratVertrag.setWirksamAb(new GregorianCalendar(2012, 0, 1));

		IHausratProduktAnpStufe hausratProduktAnpStufe = hausratVertrag.getHausratProduktAnpStufe();
		IHausratGrunddeckungsTyp hausratGrunddeckungsTyp = hausratProduktAnpStufe.getHausratGrunddeckungsTyp();
		IHausratGrunddeckung hausratGrunddeckung = hausratVertrag.newHausratGrunddeckung(hausratGrunddeckungsTyp);

		hausratGrunddeckung.berechneJahresbasisbeitrag();
		assertEquals(Money.NULL, hausratGrunddeckung.getJahresbasisbeitrag());

		hausratVertrag.setVersSumme(Money.euro(10000));
		hausratGrunddeckung.berechneJahresbasisbeitrag();
		assertEquals(Money.euro(6), hausratGrunddeckung.getJahresbasisbeitrag());

		IHausratProdukt hrOptimal = (IHausratProdukt) repository.getProductComponent("hausrat.HR-Optimal 2012-01");
		IHausratVertrag hausratVertragOptimal = hrOptimal.createHausratVertrag();
		hausratVertragOptimal.setWirksamAb(new GregorianCalendar(2012, 0, 1));

		IHausratProduktAnpStufe hausratProduktAnpStufeOptimal = hausratVertragOptimal.getHausratProduktAnpStufe();
		IHausratGrunddeckungsTyp hausratGrunddeckungsTypOptimal = hausratProduktAnpStufeOptimal
				.getHausratGrunddeckungsTyp();
		IHausratGrunddeckung hausratGrunddeckungOptimal = hausratVertragOptimal
				.newHausratGrunddeckung(hausratGrunddeckungsTypOptimal);

		hausratGrunddeckungOptimal.berechneJahresbasisbeitrag();
		assertEquals(Money.NULL, hausratGrunddeckungOptimal.getJahresbasisbeitrag());

		hausratVertragOptimal.setVersSumme(Money.euro(10000));
		hausratGrunddeckungOptimal.berechneJahresbasisbeitrag();
		assertEquals(Money.euro(8), hausratGrunddeckungOptimal.getJahresbasisbeitrag());

		// Kapitel 5
		
		IHausratZusatzdeckungsTyp hausratZusatzdeckungsTyp = hausratProduktAnpStufeOptimal.getHausratZusatzdeckungsTyp(0);
		IHausratZusatzdeckung hausratZusatzdeckung = hausratVertragOptimal.newHausratZusatzdeckung(hausratZusatzdeckungsTyp);
		hausratZusatzdeckung.berechneJahresbasisbeitrag();
		assertEquals(Money.euro(10), hausratZusatzdeckung.getJahresbasisbeitrag());
	}

	@Test
	public void testGetBeitrag() throws Exception {
		IHausratProdukt hrKompakt = (IHausratProdukt) repository.getProductComponent("hausrat.HR-Kompakt 2012-01");
		IHausratVertrag hausratVertrag = hrKompakt.createHausratVertrag();
		hausratVertrag.setWirksamAb(new GregorianCalendar(2012, 0, 1));

		IHausratProduktAnpStufe hausratProduktAnpStufe = hausratVertrag.getHausratProduktAnpStufe();
		IHausratGrunddeckungsTyp hausratGrunddeckungsTyp = hausratProduktAnpStufe.getHausratGrunddeckungsTyp();
		IHausratGrunddeckung hausratGrunddeckung = hausratVertrag.newHausratGrunddeckung(hausratGrunddeckungsTyp);

		hausratVertrag.setVersSumme(Money.euro(10000));
		hausratVertrag.setZahlweise((Zahlweise) repository.getEnumValue(Zahlweise.class.getName() + "#H"));
		hausratGrunddeckung.berechneJahresbasisbeitrag();

		assertEquals(Money.euro(3), hausratGrunddeckung.getBeitrag());
	}

}
