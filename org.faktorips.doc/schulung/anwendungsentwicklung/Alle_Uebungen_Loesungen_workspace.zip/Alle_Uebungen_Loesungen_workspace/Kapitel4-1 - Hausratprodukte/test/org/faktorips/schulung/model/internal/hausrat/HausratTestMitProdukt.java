package org.faktorips.schulung.model.internal.hausrat;

import static org.junit.Assert.assertEquals;

import java.util.GregorianCalendar;

import org.faktorips.runtime.ClassloaderRuntimeRepository;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.faktorips.values.Money;
import org.junit.Before;
import org.junit.Test;

public class HausratTestMitProdukt {

	private IRuntimeRepository repository;

	@Before
	public void setUp() {
		// Repository erzeugen
		repository = ClassloaderRuntimeRepository
				.create("org/faktorips/schulung/produktdaten/internal/faktorips-repository-toc.xml");
	}

	@Test
	public void testGetVorgeschlageneVersSumme() throws Exception {
		IHausratProdukt hrKompakt = (IHausratProdukt) repository.getProductComponent("hausrat.HR-Kompakt 2012-01");
		IHausratVertrag hausratVertrag = hrKompakt.createHausratVertrag();
		hausratVertrag.setWohnflaeche(80);
		hausratVertrag.setWirksamAb(new GregorianCalendar(2012, 0, 1));
		
		assertEquals(Money.euro(80*600), hausratVertrag.getVorschlagVersSumme());
	}

	@Test
	public void testGetTarifzone() {
		IHausratProdukt hrKompakt = (IHausratProdukt) repository.getProductComponent("hausrat.HR-Kompakt 2012-01");
		IHausratVertrag hausratVertrag = hrKompakt.createHausratVertrag();
		assertEquals("I", hausratVertrag.getTarifzone());

		hausratVertrag.setPlz("12345");
		assertEquals("I", hausratVertrag.getTarifzone());

		hausratVertrag.setPlz("17235");
		assertEquals("II", hausratVertrag.getTarifzone());

		hausratVertrag.setPlz("47279");
		assertEquals("V", hausratVertrag.getTarifzone());
	}

}
