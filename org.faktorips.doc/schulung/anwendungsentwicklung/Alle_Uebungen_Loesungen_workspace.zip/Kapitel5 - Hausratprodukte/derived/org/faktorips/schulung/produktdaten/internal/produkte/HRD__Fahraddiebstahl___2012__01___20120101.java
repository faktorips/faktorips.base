/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.produktdaten.internal.produkte;

import org.faktorips.schulung.model.internal.hausrat.HausratZusatzdeckungsTypAnpStufe;
import org.faktorips.schulung.model.internal.hausrat.HausratZusatzdeckungsTyp;
import org.faktorips.values.Money;
import org.faktorips.runtime.FormulaExecutionException;
import org.faktorips.values.Decimal;
import java.math.BigDecimal;

public class HRD__Fahraddiebstahl___2012__01___20120101 extends HausratZusatzdeckungsTypAnpStufe {

	/**
	 * Erzeugt eine neue Anpassungsstufe.
	 */
	public HRD__Fahraddiebstahl___2012__01___20120101(HausratZusatzdeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Money computeJahresbeitrag(final Money versSumme) throws FormulaExecutionException {
		try {
			return versSumme.multiply(Decimal.valueOf("0.1"), BigDecimal.ROUND_HALF_UP);
		} catch (Exception e) {
			StringBuffer parameterValues = new StringBuffer();
			parameterValues.append("versSumme=");
			parameterValues.append(versSumme == null ? "null" : versSumme.toString());
			throw new FormulaExecutionException(toString(), "0.1 * versSumme", parameterValues.toString(), e);
		}
	}

}
