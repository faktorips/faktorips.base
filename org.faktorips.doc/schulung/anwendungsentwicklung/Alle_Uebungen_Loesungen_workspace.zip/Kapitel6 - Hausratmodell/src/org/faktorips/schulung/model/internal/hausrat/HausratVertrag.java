/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import org.faktorips.runtime.IDeltaComputationOptions;
import org.faktorips.runtime.IModelObject;
import org.faktorips.runtime.IModelObjectDelta;
import org.faktorips.runtime.IModelObjectVisitor;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.runtime.MessageList;
import org.faktorips.runtime.internal.AbstractConfigurableModelObject;
import org.faktorips.runtime.internal.AbstractModelObject;
import org.faktorips.runtime.internal.ModelObjectDelta;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckungsTyp;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import org.faktorips.schulung.model.hausrat.IHausratProduktAnpStufe;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.faktorips.values.DateUtil;
import org.faktorips.values.Money;
import org.faktorips.valueset.IntegerRange;
import org.faktorips.valueset.MoneyRange;
import org.w3c.dom.Element;
import org.faktorips.schulung.model.hausrat.Zahlweise;
import org.faktorips.valueset.ValueSet;
import java.util.List;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckung;
import java.util.ArrayList;
import java.util.Collections;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTyp;
import java.util.Iterator;
import org.faktorips.runtime.Message;
import org.faktorips.runtime.ObjectProperty;
import org.faktorips.runtime.MsgReplacementParameter;
import org.faktorips.runtime.util.MessagesHelper;

/**
 * @generated
 */
public class HausratVertrag extends AbstractConfigurableModelObject implements IHausratVertrag {

	/**
	 * Membervariable fuer zahlweise.
	 * 
	 * @generated
	 */
	private Zahlweise zahlweise = null;
	/**
	 * Membervariable fuer plz.
	 * 
	 * @generated
	 */
	private String plz = null;
	/**
	 * Membervariable fuer wohnflaeche.
	 * 
	 * @generated
	 */
	private Integer wohnflaeche = null;
	/**
	 * Membervariable fuer versSumme.
	 * 
	 * @generated
	 */
	private Money versSumme = Money.NULL;

	/**
	 * Membervariable fuer wirksamAb.
	 * 
	 * @generated
	 */
	private GregorianCalendar wirksamAb = null;
	/**
	 * Membervariable fuer die Beziehung HausratGrunddeckung.
	 * 
	 * @generated
	 */
	private HausratGrunddeckung hausratGrunddeckung = null;

	/**
	 * Membervariable fuer die Beziehung HausratZusatzdeckung.
	 * 
	 * @generated
	 */
	private List<IHausratZusatzdeckung> hausratZusatzdeckungen = new ArrayList<IHausratZusatzdeckung>();

	/**
	 * Erzeugt eine neue Instanz von HausratVertrag.
	 * 
	 * @generated
	 */
	public HausratVertrag() {
		super();
	}

	/**
	 * Erzeugt eine neue Instanz von HausratVertrag.
	 * 
	 * @generated
	 */
	public HausratVertrag(IHausratProdukt productCmpt) {
		super(productCmpt);
	}

	/**
	 * Gibt den Wert des Attributs produktname zurueck.
	 * 
	 * @generated
	 */
	public String getProduktname() {
		return getHausratProduktAnpStufe().getProduktname();
	}

	/**
	 * Gibt den Wert des Attributs vertriebsname zurueck.
	 * 
	 * @generated
	 */
	public String getVertriebsname() {
		return getHausratProduktAnpStufe().getVertriebsname();
	}

	/**
	 * Gibt den Wert des Attributs vorschlagVersSummeProQm zurueck.
	 * 
	 * @generated
	 */
	public Money getVorschlagVersSummeProQm() {
		return getHausratProduktAnpStufe().getVorschlagVersSummeProQm();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public ValueSet<Zahlweise> getSetOfAllowedValuesForZahlweise(IValidationContext context) {
		return getHausratProduktAnpStufe().getSetOfAllowedValuesForZahlweise(context);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Zahlweise getZahlweise() {
		return zahlweise;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setZahlweise(Zahlweise newValue) {
		this.zahlweise = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public String getPlz() {
		return plz;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setPlz(String newValue) {
		this.plz = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated NOT
	 */
	@Override
	public String getTarifzone() {
		Tarifzonentabelle table = (Tarifzonentabelle) getHausratProdukt().getRepository().getTable(
				Tarifzonentabelle.class);
		TarifzonentabelleRow row = table.findRow(getPlz());
		if (row != null) {
			return row.getTarifzone();
		} else {
			return "I";
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IntegerRange getRangeForWohnflaeche(IValidationContext context) {
		return getHausratProduktAnpStufe().getRangeForWohnflaeche(context);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Integer getWohnflaeche() {
		return wohnflaeche;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setWohnflaeche(Integer newValue) {
		this.wohnflaeche = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated NOT
	 */
	@Override
	public Money getVorschlagVersSumme() {
		return getVorschlagVersSummeProQm().multiply(getWohnflaeche());
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public MoneyRange getRangeForVersSumme(IValidationContext context) {
		return getHausratProduktAnpStufe().getRangeForVersSumme(context);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Money getVersSumme() {
		return versSumme;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setVersSumme(Money newValue) {
		this.versSumme = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public GregorianCalendar getWirksamAb() {
		return wirksamAb == null ? null : (GregorianCalendar) wirksamAb.clone();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setWirksamAb(GregorianCalendar newValue) {
		this.wirksamAb = newValue == null ? null : (GregorianCalendar) newValue.clone();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung getHausratGrunddeckung() {
		return hausratGrunddeckung;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckung(IHausratGrunddeckung newObject) {
		if (hausratGrunddeckung != null) {
			hausratGrunddeckung.setHausratVertragInternal(null);
		}
		if (newObject != null) {
			((HausratGrunddeckung) newObject).setHausratVertragInternal(this);
		}
		hausratGrunddeckung = (HausratGrunddeckung) newObject;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung newHausratGrunddeckung() {
		HausratGrunddeckung newHausratGrunddeckung = new HausratGrunddeckung();
		setHausratGrunddeckung(newHausratGrunddeckung);
		newHausratGrunddeckung.initialize();
		return newHausratGrunddeckung;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung newHausratGrunddeckung(IHausratGrunddeckungsTyp iHausratGrunddeckungsTyp) {
		if (iHausratGrunddeckungsTyp == null) {
			return newHausratGrunddeckung();
		}
		IHausratGrunddeckung newHausratGrunddeckung = iHausratGrunddeckungsTyp.createHausratGrunddeckung();
		setHausratGrunddeckung(newHausratGrunddeckung);
		newHausratGrunddeckung.initialize();
		return newHausratGrunddeckung;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public int getNumOfHausratZusatzdeckungen() {
		return hausratZusatzdeckungen.size();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public boolean containsHausratZusatzdeckung(IHausratZusatzdeckung objectToTest) {
		return hausratZusatzdeckungen.contains(objectToTest);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public List<IHausratZusatzdeckung> getHausratZusatzdeckungen() {
		return Collections.unmodifiableList(hausratZusatzdeckungen);
	}

	/**
	 * Gibt das Objekt aus der Beziehung HausratZusatzdeckung an der indizierten
	 * Stelle zurueck.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung getHausratZusatzdeckung(int index) {
		return hausratZusatzdeckungen.get(index);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung newHausratZusatzdeckung() {
		HausratZusatzdeckung newHausratZusatzdeckung = new HausratZusatzdeckung();
		addHausratZusatzdeckung(newHausratZusatzdeckung);
		newHausratZusatzdeckung.initialize();
		return newHausratZusatzdeckung;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckung newHausratZusatzdeckung(IHausratZusatzdeckungsTyp iHausratZusatzdeckungsTyp) {
		if (iHausratZusatzdeckungsTyp == null) {
			return newHausratZusatzdeckung();
		}
		IHausratZusatzdeckung newHausratZusatzdeckung = iHausratZusatzdeckungsTyp.createHausratZusatzdeckung();
		addHausratZusatzdeckung(newHausratZusatzdeckung);
		newHausratZusatzdeckung.initialize();
		return newHausratZusatzdeckung;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public void addHausratZusatzdeckung(IHausratZusatzdeckung objectToAdd) {
		if (objectToAdd == null) {
			throw new NullPointerException("Can't add null to association HausratZusatzdeckung of " + this);
		}
		if (hausratZusatzdeckungen.contains(objectToAdd)) {
			return;
		}
		((HausratZusatzdeckung) objectToAdd).setHausratVertragInternal(this);
		hausratZusatzdeckungen.add(objectToAdd);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public void removeHausratZusatzdeckung(IHausratZusatzdeckung objectToRemove) {
		if (objectToRemove == null) {
			return;
		}
		if (hausratZusatzdeckungen.remove(objectToRemove)) {
			((HausratZusatzdeckung) objectToRemove).setHausratVertragInternal(null);
		}
	}

	/**
	 * Initialisiert produktrelevante Attribute mit ihren Vorgabewerten.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initialize() {
		if (getHausratProduktAnpStufe() == null) {
			return;
		}
		zahlweise = getHausratProduktAnpStufe().getDefaultValueZahlweise();
		wohnflaeche = getHausratProduktAnpStufe().getDefaultValueWohnflaeche();
		versSumme = getHausratProduktAnpStufe().getDefaultValueVersSumme();

		// begin-user-code
		// end-user-code
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratProdukt getHausratProdukt() {
		return (IHausratProdukt) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProduktGen() {
		return (IHausratProdukt) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratProduktAnpStufe getHausratProduktAnpStufe() {
		return (IHausratProduktAnpStufe) getProductCmptGeneration();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setHausratProdukt(IHausratProdukt hausratProdukt, boolean initPropertiesWithConfiguratedDefaults) {
		setProductComponent(hausratProdukt);
		if (initPropertiesWithConfiguratedDefaults) {
			initialize();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void effectiveFromHasChanged() {
		super.effectiveFromHasChanged();
		if (hausratGrunddeckung != null) {
			((AbstractConfigurableModelObject) hausratGrunddeckung).effectiveFromHasChanged();
		}
		for (Iterator<IHausratZusatzdeckung> it = hausratZusatzdeckungen.iterator(); it.hasNext();) {
			AbstractConfigurableModelObject child = (AbstractConfigurableModelObject) it.next();
			child.effectiveFromHasChanged();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated NOT
	 */
	@Override
	public Calendar getEffectiveFromAsCalendar() {
		return wirksamAb;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void initPropertiesFromXml(Map<String, String> propMap, IRuntimeRepository productRepository) {
		super.initPropertiesFromXml(propMap, productRepository);
		if (propMap.containsKey("zahlweise")) {
			this.zahlweise = productRepository.getEnumValue(Zahlweise.class, propMap.get("zahlweise"));
		}
		if (propMap.containsKey("plz")) {
			this.plz = propMap.get("plz");
		}
		if (propMap.containsKey("wohnflaeche")) {
			this.wohnflaeche = (propMap.get("wohnflaeche") == null || propMap.get("wohnflaeche").equals("")) ? null
					: new Integer(propMap.get("wohnflaeche"));
		}
		if (propMap.containsKey("versSumme")) {
			this.versSumme = Money.valueOf(propMap.get("versSumme"));
		}
		if (propMap.containsKey("wirksamAb")) {
			this.wirksamAb = (propMap.get("wirksamAb") == null || propMap.get("wirksamAb").equals("")) ? null
					: DateUtil.parseIsoDateStringToGregorianCalendar(propMap.get("wirksamAb"));
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected AbstractModelObject createChildFromXml(Element childEl) {
		AbstractModelObject newChild = super.createChildFromXml(childEl);
		if (newChild != null) {
			return newChild;
		}
		if ("HausratGrunddeckung".equals(childEl.getNodeName())) {
			String className = childEl.getAttribute("class");
			if (className.length() > 0) {
				try {
					HausratGrunddeckung hausratGrunddeckungLocalVar = (HausratGrunddeckung) Class.forName(className)
							.newInstance();
					setHausratGrunddeckung(hausratGrunddeckungLocalVar);
					return hausratGrunddeckungLocalVar;
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
			return (AbstractModelObject) newHausratGrunddeckung();
		}
		if ("HausratZusatzdeckung".equals(childEl.getNodeName())) {
			String className = childEl.getAttribute("class");
			if (className.length() > 0) {
				try {
					HausratZusatzdeckung hausratZusatzdeckungLocalVar = (HausratZusatzdeckung) Class.forName(className)
							.newInstance();
					addHausratZusatzdeckung(hausratZusatzdeckungLocalVar);
					return hausratZusatzdeckungLocalVar;
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
			return (AbstractModelObject) newHausratZusatzdeckung();
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObjectDelta computeDelta(IModelObject otherObject, IDeltaComputationOptions options) {
		ModelObjectDelta delta = ModelObjectDelta.newDelta(this, otherObject, options);
		if (!HausratVertrag.class.isAssignableFrom(otherObject.getClass())) {
			return delta;
		}
		HausratVertrag otherHausratVertrag = (HausratVertrag) otherObject;
		delta.checkPropertyChange(IHausratVertrag.PROPERTY_ZAHLWEISE, zahlweise, otherHausratVertrag.zahlweise, options);
		delta.checkPropertyChange(IHausratVertrag.PROPERTY_PLZ, plz, otherHausratVertrag.plz, options);
		delta.checkPropertyChange(IHausratVertrag.PROPERTY_WOHNFLAECHE, wohnflaeche, otherHausratVertrag.wohnflaeche,
				options);
		delta.checkPropertyChange(IHausratVertrag.PROPERTY_VERSSUMME, versSumme, otherHausratVertrag.versSumme, options);
		delta.checkPropertyChange(IHausratVertrag.PROPERTY_WIRKSAMAB, wirksamAb, otherHausratVertrag.wirksamAb, options);
		ModelObjectDelta.createChildDeltas(delta, hausratGrunddeckung, otherHausratVertrag.hausratGrunddeckung,
				"hausratGrunddeckung", options);
		ModelObjectDelta.createChildDeltas(delta, hausratZusatzdeckungen, otherHausratVertrag.hausratZusatzdeckungen,
				"hausratZusatzdeckungen", options);
		return delta;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObject newCopy() {
		Map<IModelObject, IModelObject> copyMap = new HashMap<IModelObject, IModelObject>();
		HausratVertrag newCopy = (HausratVertrag) newCopyInternal(copyMap);
		copyAssociationsInternal(newCopy, copyMap);
		return newCopy;
	}

	/**
	 * Interne Kopiermethode mit einer {@link Map} der bisher kopierten
	 * Instanzen
	 * 
	 * @param copyMap
	 *            die Map enthaelt die bisher kopierten Instanzen
	 * 
	 * @generated
	 */
	public IModelObject newCopyInternal(Map<IModelObject, IModelObject> copyMap) {
		HausratVertrag newCopy = (HausratVertrag) copyMap.get(this);
		if (newCopy == null) {
			newCopy = new HausratVertrag();
			newCopy.copyProductCmptAndGenerationInternal(this);
			copyProperties(newCopy, copyMap);
		}
		return newCopy;
	}

	/**
	 * Diese Methode setzt alle Werte in der Kopie (copy) auf die Werte aus
	 * diesem Objekt. Kopierte Assoziationen werden zur copyMap hinzugefügt.
	 * 
	 * @param copy
	 *            Das kopierte Object
	 * @param copyMap
	 *            Eine Map mit kopierten assoziierten Objekten
	 * 
	 * @generated
	 */
	protected void copyProperties(IModelObject copy, Map<IModelObject, IModelObject> copyMap) {
		HausratVertrag concreteCopy = (HausratVertrag) copy;
		concreteCopy.zahlweise = zahlweise;
		concreteCopy.plz = plz;
		concreteCopy.wohnflaeche = wohnflaeche;
		concreteCopy.versSumme = versSumme;
		concreteCopy.wirksamAb = wirksamAb == null ? null : (GregorianCalendar) wirksamAb.clone();
		if (hausratGrunddeckung != null) {
			concreteCopy.hausratGrunddeckung = (HausratGrunddeckung) hausratGrunddeckung.newCopyInternal(copyMap);
			concreteCopy.hausratGrunddeckung.setHausratVertragInternal(concreteCopy);
			copyMap.put(hausratGrunddeckung, concreteCopy.hausratGrunddeckung);
		}
		for (Iterator<IHausratZusatzdeckung> it = hausratZusatzdeckungen.iterator(); it.hasNext();) {
			HausratZusatzdeckung hausratZusatzdeckung = (HausratZusatzdeckung) it.next();
			HausratZusatzdeckung copyHausratZusatzdeckung = (HausratZusatzdeckung) hausratZusatzdeckung
					.newCopyInternal(copyMap);
			copyHausratZusatzdeckung.setHausratVertragInternal(concreteCopy);
			concreteCopy.hausratZusatzdeckungen.add(copyHausratZusatzdeckung);
			copyMap.put(hausratZusatzdeckung, copyHausratZusatzdeckung);
		}
	}

	/**
	 * Interne Methode zum setzen kopierter Assoziationen. Wenn das Ziel der
	 * Assoziation kopiert wurde, wird die Assoziation auf die neue Kopie
	 * gesetzt, ansonsten bleibt die Assoziation unveraendert. Die Methode ruft
	 * ausserdem {@link #copyAssociationsInternal(IModelObject, Map)} in allen
	 * durch Komposition verknuepften Instanzen auf.
	 * 
	 * @param abstractCopy
	 *            die Kopie dieser PolicyCmpt
	 * @param copyMap
	 *            die Map mit den kopierten Instanzen
	 * 
	 * @generated
	 */
	public void copyAssociationsInternal(IModelObject abstractCopy, Map<IModelObject, IModelObject> copyMap) {
		if (hausratGrunddeckung != null) {
			HausratGrunddeckung copyHausratGrunddeckung = (HausratGrunddeckung) copyMap.get(hausratGrunddeckung);
			hausratGrunddeckung.copyAssociationsInternal(copyHausratGrunddeckung, copyMap);
		}
		for (IHausratZusatzdeckung iHausratZusatzdeckung : hausratZusatzdeckungen) {
			HausratZusatzdeckung copyHausratZusatzdeckung = (HausratZusatzdeckung) copyMap.get(iHausratZusatzdeckung);
			((HausratZusatzdeckung) iHausratZusatzdeckung).copyAssociationsInternal(copyHausratZusatzdeckung, copyMap);
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public boolean accept(IModelObjectVisitor visitor) {
		if (!visitor.visit(this)) {
			return false;
		}
		if (hausratGrunddeckung != null) {
			hausratGrunddeckung.accept(visitor);
		}
		for (IHausratZusatzdeckung hausratZusatzdeckung : hausratZusatzdeckungen) {
			hausratZusatzdeckung.accept(visitor);
		}
		return true;
	}

	/**
	 * Validierung von Objekten der Klasse HausratVertrag. Gibt
	 * <code>true</code> zurueck, wenn dieses Objekt mit der Validierung
	 * fortfahren soll, <code>false</code> sonst.
	 * 
	 * @generated
	 */
	@Override
	public boolean validateSelf(MessageList ml, IValidationContext context) {
		if (!super.validateSelf(ml, context)) {
			return STOP_VALIDATION;
		}
		if (!checkWohnflaeche(ml, context)) {
			return STOP_VALIDATION;
		}
		return CONTINUE_VALIDATION;
	}

	/**
	 * Validierung von abhaengigen Objekten fuer Instanzen der Klasse
	 * HausratVertrag.
	 * 
	 * @generated
	 */
	@Override
	public void validateDependants(MessageList ml, IValidationContext context) {
		super.validateDependants(ml, context);
		if (hausratGrunddeckung != null) {
			ml.add(hausratGrunddeckung.validate(context));
		}
		if (getNumOfHausratZusatzdeckungen() > 0) {
			for (IHausratZusatzdeckung rel : getHausratZusatzdeckungen()) {
				ml.add(rel.validate(context));
			}
		}
	}

	/**
	 * Fuehrt die Regel checkWohnflaeche aus und fuegt eine Message an die
	 * uebergebene MessageList an, wenn die Regel einen nicht validen Zustand
	 * feststellt.
	 * 
	 * @param ml
	 *            Liste, der Fehler bei der Validierung in Form von Messages
	 *            hinzugefügt werden
	 * @param context
	 *            der Kontext der Validierung
	 * @return <code>true</code>, wenn die Validierung nach Ausführung dieser
	 *         Regel fortgesetzt werden soll, <code>false</code> wenn sie
	 *         abgebrochen werden soll.
	 * 
	 * @generated NOT
	 */
	protected boolean checkWohnflaeche(MessageList ml, IValidationContext context) {

		if (!getRangeForWohnflaeche(context).contains(getWohnflaeche())) {
			ml.add(createMessageForRuleCheckWohnflaeche(context, getRangeForWohnflaeche(context).getUpperBound()));
		}
		return CONTINUE_VALIDATION;
	}

	/**
	 * Erzeugt die Message, die in das Ergebnis der Validierung aufgenommen
	 * wird, wenn die Regel checkWohnflaeche einen nicht validen Zustand melden
	 * soll.
	 * 
	 * @generated
	 */
	protected Message createMessageForRuleCheckWohnflaeche(IValidationContext context, Object maxWohnflaeche) {
		ObjectProperty[] invalidObjectProperties = new ObjectProperty[] { new ObjectProperty(this, PROPERTY_WOHNFLAECHE) };
		MsgReplacementParameter[] replacementParameters = new MsgReplacementParameter[] { new MsgReplacementParameter(
				"maxWohnflaeche", maxWohnflaeche) };
		MessagesHelper messageHelper = new MessagesHelper("org.faktorips.schulung.model.internal.validation-messages",
				getClass().getClassLoader());
		String msgText = messageHelper.getMessage("hausrat.HausratVertrag-checkWohnflaeche", context.getLocale(),
				maxWohnflaeche);
		return new Message(MSG_CODE_CHECKWOHNFLAECHE, msgText, Message.ERROR, invalidObjectProperties,
				replacementParameters);
	}

}
