/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IDeltaSupport;
import org.faktorips.runtime.ICopySupport;
import org.faktorips.runtime.IVisitorSupport;
import org.faktorips.valueset.OrderedValueSet;
import org.faktorips.valueset.IntegerRange;
import org.faktorips.valueset.MoneyRange;
import org.faktorips.values.Money;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.runtime.IConfigurableModelObject;
import java.util.GregorianCalendar;

/**
 * Published Interface von HausratVertrag.
 * 
 * @generated
 */
public interface IHausratVertrag extends IConfigurableModelObject, IDeltaSupport, ICopySupport, IVisitorSupport {

	/**
	 * Diese Konstante enthaelt den Namen der Property zahlweise
	 * 
	 * @generated
	 */
	public final static String PROPERTY_ZAHLWEISE = "zahlweise";
	/**
	 * Gibt die maximale erlaubten Werte fuer die Eigenschaft zahlweise zurueck.
	 * 
	 * @generated
	 */
	public static final OrderedValueSet<Integer> MAX_ALLOWED_VALUES_FOR_ZAHLWEISE = new OrderedValueSet<Integer>(false,
			null, new Integer(1), new Integer(2), new Integer(4), new Integer(12));
	/**
	 * Diese Konstante enthaelt den Namen der Property plz
	 * 
	 * @generated
	 */
	public final static String PROPERTY_PLZ = "plz";
	/**
	 * Diese Konstante enthaelt den Namen der Property tarifzone
	 * 
	 * @generated
	 */
	public final static String PROPERTY_TARIFZONE = "tarifzone";
	/**
	 * Diese Konstante enthaelt den Namen der Property wohnflaeche
	 * 
	 * @generated
	 */
	public final static String PROPERTY_WOHNFLAECHE = "wohnflaeche";
	/**
	 * Gibt den maximal erlaubten Wertebereich fuer die Eigenschaft wohnflaeche
	 * zurueck.
	 * 
	 * @generated
	 */
	public static final IntegerRange MAX_ALLOWED_RANGE_FOR_WOHNFLAECHE = IntegerRange.valueOf(Integer.valueOf("0"),
			(Integer) null, (Integer) null, false);
	/**
	 * Diese Konstante enthaelt den Namen der Property vorschlagVersSumme
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VORSCHLAGVERSSUMME = "vorschlagVersSumme";
	/**
	 * Diese Konstante enthaelt den Namen der Property versSumme
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERSSUMME = "versSumme";
	/**
	 * Gibt den maximal erlaubten Wertebereich fuer die Eigenschaft versSumme
	 * zurueck.
	 * 
	 * @generated
	 */
	public static final MoneyRange MAX_ALLOWED_RANGE_FOR_VERSSUMME = MoneyRange.valueOf(Money.valueOf("0.00 EUR"),
			Money.NULL, Money.NULL, false);

	/**
	 * Diese Konstante enthaelt den Namen der Property wirksamAb
	 * 
	 * @generated
	 */
	public final static String PROPERTY_WIRKSAMAB = "wirksamAb";
	/**
	 * Die maximale Multiplizitaet der Beziehung mit dem Rollennamen
	 * HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public static final IntegerRange MAX_MULTIPLICITY_OF_HAUSRATGRUNDDECKUNG = new IntegerRange(0, 1);
	/**
	 * Diese Konstante enthaelt den Name der Beziehung hausratGrunddeckung.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATGRUNDDECKUNG = "hausratGrunddeckung";

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribute zahlweise zurueck.
	 * 
	 * @generated
	 */
	public OrderedValueSet<Integer> getAllowedValuesForZahlweise(IValidationContext context);

	/**
	 * Gibt den Wert des Attributs zahlweise zurueck.
	 * 
	 * @generated
	 */
	public Integer getZahlweise();

	/**
	 * Setzt den Wert des Attributs zahlweise.
	 * 
	 * @generated
	 */
	public void setZahlweise(Integer newValue);

	/**
	 * Gibt den Wert des Attributs plz zurueck.
	 * 
	 * @generated
	 */
	public String getPlz();

	/**
	 * Setzt den Wert des Attributs plz.
	 * 
	 * @generated
	 */
	public void setPlz(String newValue);

	/**
	 * Gibt den Wert des Attributs tarifzone zurueck.
	 * 
	 * @generated
	 */
	public String getTarifzone();

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribut wohnflaeche zurueck.
	 * 
	 * @generated
	 */
	public IntegerRange getRangeForWohnflaeche(IValidationContext context);

	/**
	 * Gibt den Wert des Attributs wohnflaeche zurueck.
	 * 
	 * @generated
	 */
	public Integer getWohnflaeche();

	/**
	 * Setzt den Wert des Attributs wohnflaeche.
	 * 
	 * @generated
	 */
	public void setWohnflaeche(Integer newValue);

	/**
	 * Gibt den Wert des Attributs vorschlagVersSumme zurueck.
	 * 
	 * @generated
	 */
	public Money getVorschlagVersSumme();

	/**
	 * Gibt den erlaubten Wertebereich fuer das Attribut versSumme zurueck.
	 * 
	 * @generated
	 */
	public MoneyRange getRangeForVersSumme(IValidationContext context);

	/**
	 * Gibt den Wert des Attributs versSumme zurueck.
	 * 
	 * @generated
	 */
	public Money getVersSumme();

	/**
	 * Setzt den Wert des Attributs versSumme.
	 * 
	 * @generated
	 */
	public void setVersSumme(Money newValue);

	/**
	 * Gibt den Wert des Attributs wirksamAb zurueck.
	 * 
	 * @generated
	 */
	public GregorianCalendar getWirksamAb();

	/**
	 * Setzt den Wert des Attributs wirksamAb.
	 * 
	 * @generated
	 */
	public void setWirksamAb(GregorianCalendar newValue);

	/**
	 * Gibt das referenzierte HausratGrunddeckung-Objekt zurueck.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung getHausratGrunddeckung();

	/**
	 * Setzt das uebergebene Objekt in der Beziehung HausratGrunddeckung.
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckung(IHausratGrunddeckung newObject);

	/**
	 * Erzeugt ein neues HausratGrunddeckung-Objekt und fuegt es zu diesem
	 * Objekt in der Rolle HausratGrunddeckung hinzu.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung newHausratGrunddeckung();

	/**
	 * Gibt d. HausratProdukt zurueck, welches d. HausratVertrag konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProdukt();

	/**
	 * Setzt d. neue HausratProdukt.
	 * 
	 * @param hausratProdukt
	 *            D. neue HausratProdukt.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> falls die Eigenschaften mit den Defaultwerte
	 *            aus d. HausratProdukt belegt werden sollen.
	 * 
	 * @generated
	 */
	public void setHausratProdukt(IHausratProdukt hausratProdukt, boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Gibt d. Anpassungsstufe zurueck, welches d. HausratProdukt konfiguriert.
	 * D. Anpassungsstufe wird anhand des Wirksamkeitsdatum ermittelt.
	 * 
	 * @generated
	 */
	public IHausratProduktAnpStufe getHausratProduktAnpStufe();

	/**
	 * Gibt d. HausratProdukt zurueck, welches d. HausratVertrag konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProduktGen();

}
