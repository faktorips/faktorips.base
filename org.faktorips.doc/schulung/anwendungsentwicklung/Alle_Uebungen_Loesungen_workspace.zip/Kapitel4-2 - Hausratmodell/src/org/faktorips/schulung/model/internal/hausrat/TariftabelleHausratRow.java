/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.values.Decimal;

/**
 * Diese Klasse repraesentiert eine (Read-Only) Zeile einer Tabelle.
 * 
 * @generated
 */
public class TariftabelleHausratRow {

	/**
	 * @generated
	 */
	public static final TariftabelleHausratRow NULL_ROW = new TariftabelleHausratRow(null, Decimal.NULL);

	/**
	 * @generated
	 */
	private final String tarifzone;
	/**
	 * @generated
	 */
	private final Decimal beitragssatz;

	/**
	 * Erzeugt eine neue Zeile.
	 * 
	 * @generated
	 */
	public TariftabelleHausratRow(String tarifzone, Decimal beitragssatz) {
		this.tarifzone = tarifzone;
		this.beitragssatz = beitragssatz;
	}

	/**
	 * @generated
	 */
	public String getTarifzone() {
		return tarifzone;
	}

	/**
	 * @generated
	 */
	public Decimal getBeitragssatz() {
		return beitragssatz;
	}

	/**
	 * @generated
	 */
	@Override
	public String toString() {
		return "" + tarifzone + "|" + beitragssatz;
	}

}
