/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IDeltaSupport;
import org.faktorips.runtime.ICopySupport;
import org.faktorips.runtime.IVisitorSupport;
import org.faktorips.runtime.IConfigurableModelObject;
import org.faktorips.values.Money;
import org.faktorips.runtime.IDependantObject;

/**
 * Published Interface von HausratGrunddeckung.
 * 
 * @generated
 */
public interface IHausratGrunddeckung extends IConfigurableModelObject, IDeltaSupport, ICopySupport, IVisitorSupport,
		IDependantObject {

	/**
	 * Diese Konstante enthaelt den Namen der Property jahresbasisbeitrag
	 * 
	 * @generated
	 */
	public final static String PROPERTY_JAHRESBASISBEITRAG = "jahresbasisbeitrag";

	/**
	 * Diese Konstante enthaelt den Name der Beziehung hausratVertrag.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATVERTRAG = "hausratVertrag";

	/**
	 * Gibt den Wert des Attributs jahresbasisbeitrag zurueck.
	 * 
	 * @generated
	 */
	public Money getJahresbasisbeitrag();

	/**
	 * Gibt das referenzierte HausratVertrag-Objekt zurueck.
	 * 
	 * @generated
	 */
	public IHausratVertrag getHausratVertrag();

	/**
	 * @generated
	 */
	public void berechneJahresbasisbeitrag();

	/**
	 * Gibt d. HausratGrunddeckungsTyp zurueck, welches d. HausratGrunddeckung
	 * konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTyp getHausratGrunddeckungsTyp();

	/**
	 * Setzt d. neue HausratGrunddeckungsTyp.
	 * 
	 * @param hausratGrunddeckungsTyp
	 *            D. neue HausratGrunddeckungsTyp.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> falls die Eigenschaften mit den Defaultwerte
	 *            aus d. HausratGrunddeckungsTyp belegt werden sollen.
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckungsTyp(IHausratGrunddeckungsTyp hausratGrunddeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Gibt d. Anpassungsstufe zurueck, welches d. HausratGrunddeckungsTyp
	 * konfiguriert. D. Anpassungsstufe wird anhand des Wirksamkeitsdatum
	 * ermittelt.
	 * 
	 * @generated
	 */
	public IHausratGrunddeckungsTypAnpStufe getHausratGrunddeckungsTypAnpStufe();

}
