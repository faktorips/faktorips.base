/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.test.IpsTestCase2;
import javax.xml.parsers.ParserConfigurationException;
import org.faktorips.runtime.test.IpsTestResult;
import org.w3c.dom.Element;
import org.faktorips.runtime.IObjectReferenceStore;
import org.faktorips.runtime.DefaultObjectReferenceStore;
import org.faktorips.runtime.internal.XmlUtil;
import org.faktorips.runtime.DefaultReferenceResolver;
import org.faktorips.runtime.internal.XmlCallback;
import org.faktorips.runtime.IModelObject;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckung;

import java.util.List;
import java.util.Map;
import org.faktorips.values.Money;

/**
 * Instanzen dieser Klasse sind fachliche Testfaelle. Das Testen der fachlichen
 * Logik findet in der Methode executeAsserts() statt. Die Daten fuer die
 * Testfaelle werden von FaktorIPS-Testfaellen geliefert, die auf dem
 * Testfalltyp basieren, auf dessen Basis auch diese Klasse generiert wird.
 * 
 * @generated
 */
public class BeitragsberechnungsTest extends IpsTestCase2 {

	/**
	 * @generated
	 */
	public final static String TESTATTR_HAUSRATVERTRAG_TARIFZONE = "tarifzone";
	/**
	 * @generated
	 */
	public final static String TESTATTR_HAUSRATZUSATZDECKUNG_VERSSUMME = "versSumme";
	/**
	 * @generated
	 */
	private HausratVertrag inputHausratVertrag;
	/**
	 * @generated
	 */
	private HausratVertrag erwartetHausratVertrag;

	/**
	 * Erzeugt eine neue Instanz des Testfalls.
	 * 
	 * @restrainedmodifiable
	 */
	public BeitragsberechnungsTest(String qualifiedName) throws ParserConfigurationException {
		super(qualifiedName);
		// begin-user-code
		// end-user-code
	}

	/**
	 * Fuehrt die zu testende Geschaeftslogik aus.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void executeBusinessLogic() {
		// begin-user-code
		inputHausratVertrag.berechneJahresbasisbeitrag();
		// end-user-code
	}

	/**
	 * Fuehrt die Pruefungen (Asserts) aus, d.h. vergleicht die erwarteten
	 * Werten mit den tatsaechlichen Ergebnissen.
	 * 
	 * Dies geschieht analog zu JUnit mit Aufrufen von assert(..) Methoden. Zum
	 * Beispiel assertEquals(erwartetVertrag.getBeitrag(),
	 * inputVertrag.getBeitrag(), result); Um das getestete Objekt bzw. das
	 * Attribut genauer zu beschreiben, kann zusaetzlich der Name des getesteten
	 * Objektes und der Attributname uebergeben werden, bei der Ausfuehrung als
	 * Faktor-Ips Testfall, wird dann im Fehlerfall das entsprechende
	 * Attribut-Feld im Testfalleditor als rot gekennzeichnet. Der Name des
	 * Objektes bzw. der Name des Attributes, muss gleich dem im Testfalltyp
	 * definierten Namen sein. Es muss immer der komplette Pfad zu dem
	 * Testobjekt angegeben werden, wobei die einzelnen Testobjekte auf den
	 * unterschiedlichen Ebenen (Root/Parent/Child) durch "." getrennt werden
	 * muessen. Wenn im Testfall mehrere Instanzen des gleiche Testobjektes
	 * vorhanden sind, muss ein Index an den Namen (getrennt durch "#")
	 * angefuegt werden. Beispiel: assertEquals(erwartetVertrag.getBeitrag(),
	 * inputVertrag.getBeitrag(), result, "Police#0.Vertrag#0", "beitrag");
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void executeAsserts(IpsTestResult result) {
		// begin-user-code
		String tarifzoneErw = (String) getExtensionAttributeValue(erwartetHausratVertrag,
				TESTATTR_HAUSRATVERTRAG_TARIFZONE);
		String tarifzoneIst = inputHausratVertrag.getTarifzone();
		assertEquals(tarifzoneErw, tarifzoneIst, result, "HausratVertrag#0", "tarifzone");

		IHausratGrunddeckung grunddeckungErw = erwartetHausratVertrag.getHausratGrunddeckung();
		IHausratGrunddeckung grunddeckungIst = inputHausratVertrag.getHausratGrunddeckung();

		assertEquals(grunddeckungErw.getJahresbasisbeitrag(), grunddeckungIst.getJahresbasisbeitrag(), result,
				"HausratVertrag#0.HausratGrunddeckung#0", "jahresbasisbeitrag");

		List<IHausratZusatzdeckung> zusatzdeckungenIst = inputHausratVertrag.getHausratZusatzdeckungen();
		List<IHausratZusatzdeckung> zusatzdeckungenErw = erwartetHausratVertrag.getHausratZusatzdeckungen();
		for (int i = 0; i < zusatzdeckungenErw.size(); i++) {
			assertEquals(zusatzdeckungenErw.get(i).getJahresbasisbeitrag(), zusatzdeckungenIst.get(i)
					.getJahresbasisbeitrag(), result, "HausratVertrag#0.HausratZusatzdeckung#" + i,
					"jahresbasisbeitrag");
			Money versSummeErw = (Money) getExtensionAttributeValue(zusatzdeckungenErw.get(i), "versSumme");
			Money versSummeIst = zusatzdeckungenIst.get(i).getVersSumme();
			assertEquals(versSummeErw, versSummeIst, result, "HausratVertrag#0.HausratZusatzdeckung#" + i, "versSumme");
		}
		// end-user-code
	}

	/**
	 * Initialisiert die Eingabewerte aus dem XML.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initInputFromXml(Element element) {
		// begin-user-code
		// end-user-code
		IObjectReferenceStore objectReferenceStore = new DefaultObjectReferenceStore();
		Element childElement = null;
		HausratVertragXmlCallback hausratVertragXmlCallback = new HausratVertragXmlCallback(true);
		childElement = XmlUtil.getFirstElement(element, "HausratVertrag");
		if (childElement != null) {
			try {
				String className = childElement.getAttribute("class");
				inputHausratVertrag = (HausratVertrag) Class.forName(className, true,
						HausratVertrag.class.getClassLoader()).newInstance();
				inputHausratVertrag.initFromXml(childElement, true, getRepository(), objectReferenceStore,
						hausratVertragXmlCallback);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		try {
			new DefaultReferenceResolver().resolve(objectReferenceStore);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		;
	}

	/**
	 * Initialisiert die erwarteten Werte aus dem XML.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initExpectedResultFromXml(Element element) {
		// begin-user-code
		// end-user-code
		IObjectReferenceStore objectReferenceStore = new DefaultObjectReferenceStore();
		Element childElement = null;
		HausratVertragXmlCallback hausratVertragXmlCallback = new HausratVertragXmlCallback(false);
		childElement = XmlUtil.getFirstElement(element, "HausratVertrag");
		if (childElement != null) {
			try {
				String className = childElement.getAttribute("class");
				erwartetHausratVertrag = (HausratVertrag) Class.forName(className, true,
						HausratVertrag.class.getClassLoader()).newInstance();
				erwartetHausratVertrag.initFromXml(childElement, true, getRepository(), objectReferenceStore,
						hausratVertragXmlCallback);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		try {
			new DefaultReferenceResolver().resolve(objectReferenceStore);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		;
	}

	/**
	 * XMLCallback Klasse fuer den Testparameter HausratVertrag.
	 * 
	 * @generated
	 */
	private class HausratVertragXmlCallback implements XmlCallback {
		/**
		 * Gibt an ob die Klasse fuer die Input (<code>true</code>) oder fuer
		 * die erwarteten Werte (<code>false</code>) verwendet wird.
		 * 
		 * @generated
		 */
		private boolean input;

		/**
		 * Erzeugt eine neue XMLCallback Klasse fuer den Testparameter
		 * HausratVertrag.
		 * 
		 * @generated
		 */
		public HausratVertragXmlCallback(boolean input) {
			this.input = input;
		}

		/**
		 * {@inheritDoc}
		 * 
		 * @generated
		 */
		public void initProperties(String pathFromAggregateRoot, IModelObject modelObject, Map<String, String> propMap) {
			if (pathFromAggregateRoot.equals("/HausratVertrag")) {
				String value = null;
				if (!input) {
					value = (String) propMap.get(TESTATTR_HAUSRATVERTRAG_TARIFZONE);
					addExtensionAttribute(modelObject, TESTATTR_HAUSRATVERTRAG_TARIFZONE, value);
				}
			}
			if (pathFromAggregateRoot.equals("/HausratVertrag/HausratZusatzdeckung")) {
				String value = null;
				if (!input) {
					value = (String) propMap.get(TESTATTR_HAUSRATZUSATZDECKUNG_VERSSUMME);
					addExtensionAttribute(modelObject, TESTATTR_HAUSRATZUSATZDECKUNG_VERSSUMME, Money.valueOf(value));
				}
			}
		}

	}

}
