package org.faktorips.schulung.model.internal.hausrat;

import static org.junit.Assert.*;

import org.faktorips.values.Money;
import org.junit.Test;

public class HausratVertragTest {

	@Test
	public void testGetTarifzone() {
		HausratVertrag hausratVertrag = new HausratVertrag();
		assertEquals("I", hausratVertrag.getTarifzone());
	}

	@Test
	public void testGetVorschlagVersSumme() {
		HausratVertrag hausratVertrag = new HausratVertrag();
		
		hausratVertrag.setWohnflaeche(0);
		assertEquals(Money.euro(0), hausratVertrag.getVorschlagVersSumme());

		hausratVertrag.setWohnflaeche(80);
		assertEquals(Money.euro(80*650), hausratVertrag.getVorschlagVersSumme());

	}

}
