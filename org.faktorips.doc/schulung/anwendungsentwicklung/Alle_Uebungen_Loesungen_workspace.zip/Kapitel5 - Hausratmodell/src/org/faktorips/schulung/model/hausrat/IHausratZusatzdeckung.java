/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IConfigurableModelObject;
import org.faktorips.runtime.IDeltaSupport;
import org.faktorips.runtime.ICopySupport;
import org.faktorips.runtime.IVisitorSupport;
import org.faktorips.runtime.IDependantObject;
import org.faktorips.values.Money;

/**
 * Published Interface von HausratZusatzdeckung.
 * 
 * @generated
 */
public interface IHausratZusatzdeckung extends IConfigurableModelObject, IDeltaSupport, ICopySupport, IVisitorSupport,
		IDependantObject {

	/**
	 * Diese Konstante enthaelt den Namen der Property versSumme
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERSSUMME = "versSumme";
	/**
	 * Diese Konstante enthaelt den Namen der Property jahresbasisbeitrag
	 * 
	 * @generated
	 */
	public final static String PROPERTY_JAHRESBASISBEITRAG = "jahresbasisbeitrag";
	/**
	 * Diese Konstante enthaelt den Name der Beziehung hausratVertrag.
	 * 
	 * @generated
	 */
	public final static String ASSOCIATION_HAUSRATVERTRAG = "hausratVertrag";

	/**
	 * Gibt den Wert des Attributs versSumme zurueck.
	 * 
	 * @generated
	 */
	public Money getVersSumme();

	/**
	 * Gibt den Wert des Attributs jahresbasisbeitrag zurueck.
	 * 
	 * @generated
	 */
	public Money getJahresbasisbeitrag();

	/**
	 * Gibt das referenzierte HausratVertrag-Objekt zurueck.
	 * 
	 * @generated
	 */
	public IHausratVertrag getHausratVertrag();

	/**
	 * @generated
	 */
	public void berechneJahresbasisbeitrag();

	/**
	 * Gibt d. HausratZusatzdeckungsTyp zurueck, welches d. HausratZusatzdeckung
	 * konfiguriert.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp();

	/**
	 * Setzt d. neue HausratZusatzdeckungsTyp.
	 * 
	 * @param hausratZusatzdeckungsTyp
	 *            D. neue HausratZusatzdeckungsTyp.
	 * @param initPropertiesWithConfiguratedDefaults
	 *            <code>true</code> falls die Eigenschaften mit den Defaultwerte
	 *            aus d. HausratZusatzdeckungsTyp belegt werden sollen.
	 * 
	 * @generated
	 */
	public void setHausratZusatzdeckungsTyp(IHausratZusatzdeckungsTyp hausratZusatzdeckungsTyp,
			boolean initPropertiesWithConfiguratedDefaults);

	/**
	 * Gibt d. Anpassungsstufe zurueck, welches d. HausratZusatzdeckungsTyp
	 * konfiguriert. D. Anpassungsstufe wird anhand des Wirksamkeitsdatum
	 * ermittelt.
	 * 
	 * @generated
	 */
	public IHausratZusatzdeckungsTypAnpStufe getHausratZusatzdeckungsTypAnpStufe();

}
