/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.ProductComponentGeneration;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTypAnpStufe;
import org.faktorips.schulung.model.hausrat.IHausratZusatzdeckungsTyp;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.runtime.IProductComponentLink;
import org.faktorips.runtime.IProductComponent;
import java.util.List;
import java.util.ArrayList;
import org.faktorips.values.Decimal;
import org.faktorips.runtime.IllegalRepositoryModificationException;
import org.faktorips.runtime.internal.ValueToXmlHelper;
import org.faktorips.values.Money;
import org.faktorips.runtime.FormulaExecutionException;

/**
 * Die Implementierung von IHausratZusatzdeckungsTypAnpStufe.
 * 
 * @generated
 */
public class HausratZusatzdeckungsTypAnpStufe extends ProductComponentGeneration implements
		IHausratZusatzdeckungsTypAnpStufe {

	/**
	 * Membervariable fuer die Produkteigenschaft Bezeichnung.
	 * 
	 * @generated
	 */
	private String bezeichnung = null;

	/**
	 * Membervariable fuer die Produkteigenschaft VersSummeFaktor.
	 * 
	 * @generated
	 */
	private Decimal versSummeFaktor = Decimal.NULL;

	/**
	 * Membervariable fuer die Produkteigenschaft MaximaleVersSumme.
	 * 
	 * @generated
	 */
	private Money maximaleVersSumme = Money.NULL;

	/**
	 * Erzeugt eine neue Instanz von HausratZusatzdeckungsTypAnpStufe.
	 * 
	 * @generated
	 */
	public HausratZusatzdeckungsTypAnpStufe(HausratZusatzdeckungsTyp productCmpt) {
		super(productCmpt);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public String getBezeichnung() {
		return bezeichnung;
	}

	/**
	 * Setzt den Wert der Eigenschaft bezeichnung.
	 * 
	 * @generated
	 */
	public void setBezeichnung(String newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.bezeichnung = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public Decimal getVersSummeFaktor() {
		return versSummeFaktor;
	}

	/**
	 * Setzt den Wert der Eigenschaft versSummeFaktor.
	 * 
	 * @generated
	 */
	public void setVersSummeFaktor(Decimal newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.versSummeFaktor = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public Money getMaximaleVersSumme() {
		return maximaleVersSumme;
	}

	/**
	 * Setzt den Wert der Eigenschaft maximaleVersSumme.
	 * 
	 * @generated
	 */
	public void setMaximaleVersSumme(Money newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.maximaleVersSumme = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public Money computeJahresbeitrag(Money versSumme) throws FormulaExecutionException {
		return (Money) getFormulaEvaluator().evaluate("computeJahresbeitrag", versSumme);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratZusatzdeckungsTyp getHausratZusatzdeckungsTyp() {
		return (IHausratZusatzdeckungsTyp) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
		Element configElement = null;
		String value = null;
		configElement = configMap.get("bezeichnung");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			bezeichnung = value;
		}
		configElement = configMap.get("versSummeFaktor");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			versSummeFaktor = Decimal.valueOf(value);
		}
		configElement = configMap.get("maximaleVersSumme");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			maximaleVersSumme = Money.valueOf(value);
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IProductComponentLink<? extends IProductComponent> getLink(String linkName, IProductComponent target) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public List<IProductComponentLink<? extends IProductComponent>> getLinks() {
		List<IProductComponentLink<? extends IProductComponent>> list = new ArrayList<IProductComponentLink<? extends IProductComponent>>();
		return list;
	}

}
