/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.AbstractModelObject;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.w3c.dom.Element;
import org.faktorips.runtime.IModelObjectDelta;
import org.faktorips.runtime.IModelObject;
import org.faktorips.runtime.IDeltaComputationOptions;
import org.faktorips.runtime.internal.ModelObjectDelta;
import java.util.Map;
import java.util.HashMap;
import org.faktorips.runtime.IModelObjectVisitor;
import org.faktorips.runtime.MessageList;
import org.faktorips.runtime.IValidationContext;
import org.faktorips.values.Money;
import org.faktorips.valueset.OrderedValueSet;
import org.faktorips.valueset.IntegerRange;
import org.faktorips.valueset.MoneyRange;
import org.faktorips.runtime.IRuntimeRepository;
import org.faktorips.schulung.model.hausrat.IHausratGrunddeckung;
import org.faktorips.runtime.internal.AbstractConfigurableModelObject;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import java.util.Calendar;
import org.faktorips.schulung.model.hausrat.IHausratProduktAnpStufe;

/**
 * @generated
 */
public class HausratVertrag extends AbstractConfigurableModelObject implements IHausratVertrag {

	/**
	 * Membervariable fuer zahlweise.
	 * 
	 * @generated
	 */
	private Integer zahlweise = null;
	/**
	 * Membervariable fuer plz.
	 * 
	 * @generated
	 */
	private String plz = null;
	/**
	 * Membervariable fuer wohnflaeche.
	 * 
	 * @generated
	 */
	private Integer wohnflaeche = null;
	/**
	 * Membervariable fuer versSumme.
	 * 
	 * @generated
	 */
	private Money versSumme = Money.NULL;

	/**
	 * Membervariable fuer die Beziehung HausratGrunddeckung.
	 * 
	 * @generated
	 */
	private HausratGrunddeckung hausratGrunddeckung = null;

	/**
	 * Erzeugt eine neue Instanz von HausratVertrag.
	 * 
	 * @generated
	 */
	public HausratVertrag() {
		super();
	}

	/**
	 * Erzeugt eine neue Instanz von HausratVertrag.
	 * 
	 * @generated
	 */
	public HausratVertrag(IHausratProdukt productCmpt) {
		super(productCmpt);
	}

	/**
	 * Gibt den Wert des Attributs produktname zurueck.
	 * 
	 * @generated
	 */
	public String getProduktname() {
		return getHausratProduktAnpStufe().getProduktname();
	}

	/**
	 * Gibt den Wert des Attributs vertriebsname zurueck.
	 * 
	 * @generated
	 */
	public String getVertriebsname() {
		return getHausratProduktAnpStufe().getVertriebsname();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public OrderedValueSet<Integer> getAllowedValuesForZahlweise(IValidationContext context) {
		return MAX_ALLOWED_VALUES_FOR_ZAHLWEISE;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Integer getZahlweise() {
		return zahlweise;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setZahlweise(Integer newValue) {
		this.zahlweise = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public String getPlz() {
		return plz;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setPlz(String newValue) {
		this.plz = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated NOT
	 */
	@Override
	public String getTarifzone() {
		return "I";
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IntegerRange getRangeForWohnflaeche(IValidationContext context) {
		return MAX_ALLOWED_RANGE_FOR_WOHNFLAECHE;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Integer getWohnflaeche() {
		return wohnflaeche;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setWohnflaeche(Integer newValue) {
		this.wohnflaeche = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Money getVorschlagVersSumme() {
		return Money.NULL;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public MoneyRange getRangeForVersSumme(IValidationContext context) {
		return MAX_ALLOWED_RANGE_FOR_VERSSUMME;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Money getVersSumme() {
		return versSumme;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setVersSumme(Money newValue) {
		this.versSumme = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung getHausratGrunddeckung() {
		return hausratGrunddeckung;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public void setHausratGrunddeckung(IHausratGrunddeckung newObject) {
		hausratGrunddeckung = (HausratGrunddeckung) newObject;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratGrunddeckung newHausratGrunddeckung() {
		HausratGrunddeckung newHausratGrunddeckung = new HausratGrunddeckung();
		setHausratGrunddeckung(newHausratGrunddeckung);
		newHausratGrunddeckung.initialize();
		return newHausratGrunddeckung;
	}

	/**
	 * Initialisiert produktrelevante Attribute mit ihren Vorgabewerten.
	 * 
	 * @restrainedmodifiable
	 */
	@Override
	public void initialize() {

		// begin-user-code
		// end-user-code
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratProdukt getHausratProdukt() {
		return (IHausratProdukt) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProduktGen() {
		return (IHausratProdukt) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratProduktAnpStufe getHausratProduktAnpStufe() {
		return (IHausratProduktAnpStufe) getProductCmptGeneration();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void setHausratProdukt(IHausratProdukt hausratProdukt, boolean initPropertiesWithConfiguratedDefaults) {
		setProductComponent(hausratProdukt);
		if (initPropertiesWithConfiguratedDefaults) {
			initialize();
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public void effectiveFromHasChanged() {
		super.effectiveFromHasChanged();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public Calendar getEffectiveFromAsCalendar() {
		return null; // TODO Implementieren des Zugriffs auf das
						// Wirksamkeitsdatum (wird benoetigt um auf die
						// gueltigen Produktdaten zuzugreifen).
		// Damit diese Methode bei erneutem Generieren nicht neu ueberschrieben
		// wird,
		// muss im Javadoc ein NOT hinter @generated geschrieben werden!
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void initPropertiesFromXml(Map<String, String> propMap, IRuntimeRepository productRepository) {
		super.initPropertiesFromXml(propMap, productRepository);
		if (propMap.containsKey("zahlweise")) {
			this.zahlweise = (propMap.get("zahlweise") == null || propMap.get("zahlweise").equals("")) ? null
					: new Integer(propMap.get("zahlweise"));
		}
		if (propMap.containsKey("plz")) {
			this.plz = propMap.get("plz");
		}
		if (propMap.containsKey("wohnflaeche")) {
			this.wohnflaeche = (propMap.get("wohnflaeche") == null || propMap.get("wohnflaeche").equals("")) ? null
					: new Integer(propMap.get("wohnflaeche"));
		}
		if (propMap.containsKey("versSumme")) {
			this.versSumme = Money.valueOf(propMap.get("versSumme"));
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected AbstractModelObject createChildFromXml(Element childEl) {
		AbstractModelObject newChild = super.createChildFromXml(childEl);
		if (newChild != null) {
			return newChild;
		}
		if ("HausratGrunddeckung".equals(childEl.getNodeName())) {
			String className = childEl.getAttribute("class");
			if (className.length() > 0) {
				try {
					HausratGrunddeckung hausratGrunddeckungLocalVar = (HausratGrunddeckung) Class.forName(className)
							.newInstance();
					setHausratGrunddeckung(hausratGrunddeckungLocalVar);
					return hausratGrunddeckungLocalVar;
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
			return (AbstractModelObject) newHausratGrunddeckung();
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObjectDelta computeDelta(IModelObject otherObject, IDeltaComputationOptions options) {
		ModelObjectDelta delta = ModelObjectDelta.newDelta(this, otherObject, options);
		if (!HausratVertrag.class.isAssignableFrom(otherObject.getClass())) {
			return delta;
		}
		HausratVertrag otherHausratVertrag = (HausratVertrag) otherObject;
		delta.checkPropertyChange(IHausratVertrag.PROPERTY_ZAHLWEISE, zahlweise, otherHausratVertrag.zahlweise, options);
		delta.checkPropertyChange(IHausratVertrag.PROPERTY_PLZ, plz, otherHausratVertrag.plz, options);
		delta.checkPropertyChange(IHausratVertrag.PROPERTY_WOHNFLAECHE, wohnflaeche, otherHausratVertrag.wohnflaeche,
				options);
		delta.checkPropertyChange(IHausratVertrag.PROPERTY_VERSSUMME, versSumme, otherHausratVertrag.versSumme, options);
		ModelObjectDelta.createChildDeltas(delta, hausratGrunddeckung, otherHausratVertrag.hausratGrunddeckung,
				"hausratGrunddeckung", options);
		return delta;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IModelObject newCopy() {
		Map<IModelObject, IModelObject> copyMap = new HashMap<IModelObject, IModelObject>();
		HausratVertrag newCopy = (HausratVertrag) newCopyInternal(copyMap);
		copyAssociationsInternal(newCopy, copyMap);
		return newCopy;
	}

	/**
	 * Interne Kopiermethode mit einer {@link Map} der bisher kopierten
	 * Instanzen
	 * 
	 * @param copyMap
	 *            die Map enthaelt die bisher kopierten Instanzen
	 * 
	 * @generated
	 */
	public IModelObject newCopyInternal(Map<IModelObject, IModelObject> copyMap) {
		HausratVertrag newCopy = (HausratVertrag) copyMap.get(this);
		if (newCopy == null) {
			newCopy = new HausratVertrag();
			newCopy.copyProductCmptAndGenerationInternal(this);
			copyProperties(newCopy, copyMap);
		}
		return newCopy;
	}

	/**
	 * Diese Methode setzt alle Werte in der Kopie (copy) auf die Werte aus
	 * diesem Objekt. Kopierte Assoziationen werden zur copyMap hinzugefügt.
	 * 
	 * @param copy
	 *            Das kopierte Object
	 * @param copyMap
	 *            Eine Map mit kopierten assoziierten Objekten
	 * 
	 * @generated
	 */
	protected void copyProperties(IModelObject copy, Map<IModelObject, IModelObject> copyMap) {
		HausratVertrag concreteCopy = (HausratVertrag) copy;
		concreteCopy.zahlweise = zahlweise;
		concreteCopy.plz = plz;
		concreteCopy.wohnflaeche = wohnflaeche;
		concreteCopy.versSumme = versSumme;
		if (hausratGrunddeckung != null) {
			concreteCopy.hausratGrunddeckung = (HausratGrunddeckung) hausratGrunddeckung.newCopyInternal(copyMap);
			copyMap.put(hausratGrunddeckung, concreteCopy.hausratGrunddeckung);
		}
	}

	/**
	 * Interne Methode zum setzen kopierter Assoziationen. Wenn das Ziel der
	 * Assoziation kopiert wurde, wird die Assoziation auf die neue Kopie
	 * gesetzt, ansonsten bleibt die Assoziation unveraendert. Die Methode ruft
	 * ausserdem {@link #copyAssociationsInternal(IModelObject, Map)} in allen
	 * durch Komposition verknuepften Instanzen auf.
	 * 
	 * @param abstractCopy
	 *            die Kopie dieser PolicyCmpt
	 * @param copyMap
	 *            die Map mit den kopierten Instanzen
	 * 
	 * @generated
	 */
	public void copyAssociationsInternal(IModelObject abstractCopy, Map<IModelObject, IModelObject> copyMap) {
		if (hausratGrunddeckung != null) {
			HausratGrunddeckung copyHausratGrunddeckung = (HausratGrunddeckung) copyMap.get(hausratGrunddeckung);
			hausratGrunddeckung.copyAssociationsInternal(copyHausratGrunddeckung, copyMap);
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public boolean accept(IModelObjectVisitor visitor) {
		if (!visitor.visit(this)) {
			return false;
		}
		if (hausratGrunddeckung != null) {
			hausratGrunddeckung.accept(visitor);
		}
		return true;
	}

	/**
	 * Validierung von Objekten der Klasse HausratVertrag. Gibt
	 * <code>true</code> zurueck, wenn dieses Objekt mit der Validierung
	 * fortfahren soll, <code>false</code> sonst.
	 * 
	 * @generated
	 */
	@Override
	public boolean validateSelf(MessageList ml, IValidationContext context) {
		if (!super.validateSelf(ml, context)) {
			return STOP_VALIDATION;
		}
		return CONTINUE_VALIDATION;
	}

	/**
	 * Validierung von abhaengigen Objekten fuer Instanzen der Klasse
	 * HausratVertrag.
	 * 
	 * @generated
	 */
	@Override
	public void validateDependants(MessageList ml, IValidationContext context) {
		super.validateDependants(ml, context);
		if (hausratGrunddeckung != null) {
			ml.add(hausratGrunddeckung.validate(context));
		}
	}

}
