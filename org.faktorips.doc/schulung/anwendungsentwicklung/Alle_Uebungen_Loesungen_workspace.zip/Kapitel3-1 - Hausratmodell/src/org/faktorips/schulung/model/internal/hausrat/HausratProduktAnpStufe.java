/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.ProductComponentGeneration;
import org.faktorips.schulung.model.hausrat.IHausratProduktAnpStufe;
import org.faktorips.runtime.IllegalRepositoryModificationException;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.runtime.internal.ValueToXmlHelper;
import org.faktorips.runtime.IProductComponentLink;
import org.faktorips.runtime.IProductComponent;
import java.util.List;
import java.util.ArrayList;

/**
 * Die Implementierung von IHausratProduktAnpStufe.
 * 
 * @generated
 */
public class HausratProduktAnpStufe extends ProductComponentGeneration implements IHausratProduktAnpStufe {

	/**
	 * Membervariable fuer die Produkteigenschaft Produktname.
	 * 
	 * @generated
	 */
	private String produktname = null;
	/**
	 * Membervariable fuer die Produkteigenschaft Vertriebsname.
	 * 
	 * @generated
	 */
	private String vertriebsname = null;

	/**
	 * Erzeugt eine neue Instanz von HausratProduktAnpStufe.
	 * 
	 * @generated
	 */
	public HausratProduktAnpStufe(HausratProdukt productCmpt) {
		super(productCmpt);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public String getProduktname() {
		return produktname;
	}

	/**
	 * Setzt den Wert der Eigenschaft produktname.
	 * 
	 * @generated
	 */
	public void setProduktname(String newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.produktname = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	public String getVertriebsname() {
		return vertriebsname;
	}

	/**
	 * Setzt den Wert der Eigenschaft vertriebsname.
	 * 
	 * @generated
	 */
	public void setVertriebsname(String newValue) {
		if (getRepository() != null && !getRepository().isModifiable()) {
			throw new IllegalRepositoryModificationException();
		}
		this.vertriebsname = newValue;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratProdukt getHausratProdukt() {
		return (IHausratProdukt) getProductComponent();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
		Element configElement = null;
		String value = null;
		configElement = configMap.get("produktname");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			produktname = value;
		}
		configElement = configMap.get("vertriebsname");
		if (configElement != null) {
			value = ValueToXmlHelper.getValueFromElement(configElement, "Value");
			vertriebsname = value;
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IProductComponentLink<? extends IProductComponent> getLink(String linkName, IProductComponent target) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public List<IProductComponentLink<? extends IProductComponent>> getLinks() {
		List<IProductComponentLink<? extends IProductComponent>> list = new ArrayList<IProductComponentLink<? extends IProductComponent>>();
		return list;
	}

}
