/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.internal.hausrat;

import org.faktorips.runtime.internal.ProductComponent;
import org.faktorips.schulung.model.hausrat.IHausratProdukt;
import org.faktorips.runtime.IRuntimeRepository;
import java.util.Calendar;
import java.util.Map;
import org.w3c.dom.Element;
import org.faktorips.schulung.model.hausrat.IHausratVertrag;
import org.faktorips.runtime.IConfigurableModelObject;
import org.faktorips.schulung.model.hausrat.IHausratProduktAnpStufe;

/**
 * The implementation of IHausratProdukt.
 * 
 * @generated
 */
public class HausratProdukt extends ProductComponent implements IHausratProdukt {

	/**
	 * Erzeugt eine neue Instanz von HausratProdukt.
	 * 
	 * @generated
	 */
	public HausratProdukt(IRuntimeRepository repository, String id, String kindId, String generationId) {
		super(repository, id, kindId, generationId);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratProduktAnpStufe getHausratProduktAnpStufe(Calendar wirksamkeitsdatum) {
		return (IHausratProduktAnpStufe) getRepository().getProductComponentGeneration(getId(), wirksamkeitsdatum);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	protected void doInitPropertiesFromXml(Map<String, Element> configMap) {
		super.doInitPropertiesFromXml(configMap);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IHausratVertrag createHausratVertrag() {
		return new HausratVertrag(this);
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @generated
	 */
	@Override
	public IConfigurableModelObject createPolicyComponent() {
		return createHausratVertrag();
	}

}
