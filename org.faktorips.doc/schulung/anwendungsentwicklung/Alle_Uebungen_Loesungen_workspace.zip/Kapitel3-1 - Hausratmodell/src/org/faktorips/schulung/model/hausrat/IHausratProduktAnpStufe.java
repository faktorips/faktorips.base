/* BEGIN FAKTORIPS GENERATOR INFORMATION SECTION
 * 
 * builder set: org.faktorips.devtools.stdbuilder.ipsstdbuilderset, Version: 3.0.0
 * 
 * END FAKTORIPS GENERATOR INFORMATION SECTION
 */
package org.faktorips.schulung.model.hausrat;

import org.faktorips.runtime.IProductComponentGeneration;

/**
 * Die Anpassungsstufe von HausratProdukt.
 * 
 * @generated
 */
public interface IHausratProduktAnpStufe extends IProductComponentGeneration {

	/**
	 * Diese Konstante enthaelt den Namen der Property produktname
	 * 
	 * @generated
	 */
	public final static String PROPERTY_PRODUKTNAME = "produktname";
	/**
	 * Diese Konstante enthaelt den Namen der Property vertriebsname
	 * 
	 * @generated
	 */
	public final static String PROPERTY_VERTRIEBSNAME = "vertriebsname";

	/**
	 * Gibt den Wert der Eigenschaft produktname zurueck.
	 * 
	 * @generated
	 */
	public String getProduktname();

	/**
	 * Gibt den Wert der Eigenschaft vertriebsname zurueck.
	 * 
	 * @generated
	 */
	public String getVertriebsname();

	/**
	 * Gibt d HausratProdukt zurueck, zu dem diese Anpassungsstufe gehoert.
	 * 
	 * @generated
	 */
	public IHausratProdukt getHausratProdukt();

}
