/**
 * Abstract representation of a triangle.
 */
public abstract class Triangle {

	/**
	 * Returns the area of the triangle.
	 * <p>
	 * <strong>Subclassing:</strong><br>
	 * Subclasses must implement the mathematics of the area function.
	 */
	protected abstract double area();
	
	protected abstract double getA();
	
	protected abstract double getB();
	
	protected abstract double getC();

}
