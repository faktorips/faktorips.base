/**
 * A triangle that has two sides with same length.
 */
public class IsoscelesTriangle extends Triangle {

	private final double a;

	private final double b;

	private final double c;

	/**
	 * @param a
	 *            the length of two sides of the triangle
	 * @param y
	 *            the angle in-between the two equal sides
	 * 
	 * @throws IllegalArgumentException
	 *             if a or y is <= 0, or if y is >= 180
	 */
	public IsoscelesTriangle(int a, int y) {
		if (a <= 0 || y <= 0 || y >= 180) {
			throw new IllegalArgumentException();
		}
		this.a = a;
		this.b = a;
		this.c = Math.sqrt(a * a + b * b - 2 * a * b
				* Math.cos(Math.toRadians(y)));
	}

	@Override
	protected double area() {
		double s = (a + b + c) / 2;
		return Math.sqrt(s * (s - a) * (s - b) * (s - c));
	}

	@Override
	protected double getA() {
		return a;
	}

	@Override
	protected double getB() {
		return b;
	}

	@Override
	protected double getC() {
		return c;
	}

}
