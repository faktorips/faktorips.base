/**
 * A triangle with all sides having equal length.
 */
public class EquilateralTriangle extends Triangle {

	private final double a;

	/**
	 * @param a
	 *            the length of each side of the triangle
	 * 
	 * @throws IllegalArgumentException
	 *             if a is <= 0
	 */
	public EquilateralTriangle(int a) {
		if (a <= 0) {
			throw new IllegalArgumentException();
		}
		this.a = a;
	}

	@Override
	protected double area() {
		return (Math.sqrt(3) / 4) * Math.pow(a, 2);
	}

	@Override
	protected double getA() {
		return a;
	}

	@Override
	protected double getB() {
		return a;
	}

	@Override
	protected double getC() {
		return a;
	}

}
