import static org.junit.Assert.*;

import org.junit.Test;

public class EquilateralTriangleTest {
	
	@Test(expected = IllegalArgumentException.class)
	public void testConstructor_DisallowZero() {
		new EquilateralTriangle(0);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testConstructor_DisallowNegativeNumber() {
		new EquilateralTriangle(-1);
	}
	
	@Test
	public void testConstructor_AllSidesMustHaveEqualLength() {
		Triangle triangle = new EquilateralTriangle(3);
		assertEquals(3, triangle.getA(), 0);
		assertEquals(3, triangle.getB(), 0);
		assertEquals(3, triangle.getC (), 0);
	}
	
	@Test
	public void testArea() {
		Triangle triangle = new EquilateralTriangle(68);
		assertEquals(2002.25, triangle.area(), 0.01);
	}
	

}
