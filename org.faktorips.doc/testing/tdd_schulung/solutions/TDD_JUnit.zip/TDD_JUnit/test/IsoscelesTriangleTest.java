import static org.junit.Assert.*;

import org.junit.Test;

public class IsoscelesTriangleTest {

	@Test(expected = IllegalArgumentException.class)
	public void testConstructor_DisallowZeroSideLength() {
		new IsoscelesTriangle(0, 10);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstructor_DisallowNegativeSideLength() {
		new IsoscelesTriangle(-1, 10);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstructor_DisallowZeroAngle() {
		new IsoscelesTriangle(10, 0);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstructor_DisallowNegativeAngle() {
		new IsoscelesTriangle(10, -1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstructor_DisallowAngleOf180() {
		new IsoscelesTriangle(10, 180);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testConstructor_DisallowAngleGreater180() {
		new IsoscelesTriangle(10, 181);
	}

	@Test
	public void testConstructor_TwoSidesMustHaveSameLength() {
		Triangle triangle = new IsoscelesTriangle(16, 40);
		assertEquals(16, triangle.getA(), 0);
		assertEquals(16, triangle.getB(), 0);
	}

	@Test
	public void testConstructor_ThirdSideIsDerivedByOtherSidesAndAngle() {
		Triangle triangle = new IsoscelesTriangle(5, 120);
		assertEquals(8.66, triangle.getC(), 0.01);
	}

	@Test
	public void testArea() {
		Triangle triangle = new IsoscelesTriangle(5, 120);
		assertEquals(10.83, triangle.area(), 0.01);
	}

}
