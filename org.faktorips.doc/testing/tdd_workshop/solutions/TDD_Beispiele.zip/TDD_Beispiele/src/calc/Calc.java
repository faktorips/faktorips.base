package calc;

public class Calc {
	/**
	 * Returns the result of a + b.
	 */
	public int add(int a, int b) {
		// TODO: not yet implemented
		return 0;
	}
}