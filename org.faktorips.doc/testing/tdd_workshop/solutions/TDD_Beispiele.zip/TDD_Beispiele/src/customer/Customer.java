package customer;

public class Customer {
	private final IDatabase database;
	private final String customerId;

	private String firstName;
	private String lastName;

	public Customer(IDatabase database, String customerId) {
		this.database = database;
		this.customerId = customerId;
		firstName = database.getFirstNameOfCustomer(customerId);
		lastName = database.getLastNameOfCustomer(customerId);
	}

	public String getFullName() {
		return firstName + ' ' + lastName;
	}

	public void save() {
		database.setFirstNameOfCustomer(customerId, firstName);
		database.setLastNameOfCustomer(customerId, lastName);
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

}