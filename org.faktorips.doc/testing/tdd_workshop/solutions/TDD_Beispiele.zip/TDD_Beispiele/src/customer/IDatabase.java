package customer;

public interface IDatabase {

	String getFirstNameOfCustomer(String customerId);

	String getLastNameOfCustomer(String customerId);
	
	void setFirstNameOfCustomer(String customerId, String firstName);

	void setLastNameOfCustomer(String customerId, String lastName);

}
