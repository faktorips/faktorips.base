package calc;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CalcTest {
	private Calc calc;

	@Before
	public void setUp() {
		calc = new Calc();
	}

	@Test
	public void testAdd_AddPositiveNumbers() {
		assertEquals(1, calc.add(0, 1));
		assertEquals(1, calc.add(1, 0));
		assertEquals(5, calc.add(2, 3));
	}
}