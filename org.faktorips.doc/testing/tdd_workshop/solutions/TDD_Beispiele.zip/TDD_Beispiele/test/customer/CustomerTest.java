package customer;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class CustomerTest {
	@Mock
	private IDatabase database;
	private Customer customer;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this); // initialize @Mock fields
		// configure mocks (also called stubbing)
		when(database.getFirstNameOfCustomer("1234")).thenReturn("Max");
		when(database.getLastNameOfCustomer("1234")).thenReturn("Mustermann");
		customer = new Customer(database, "1234");
	}

	@Test
	public void testGetFullName() {
		assertEquals("Max Mustermann", customer.getFullName());
	}

	@Test
	public void testSave() {
		customer.setFirstName("Otto");
		customer.setLastName("Ottinger");

		customer.save();

		// verify that the database gets updated
		verify(database).setFirstNameOfCustomer("1234", "Otto");
		verify(database).setLastNameOfCustomer("1234", "Ottinger");
	}
}