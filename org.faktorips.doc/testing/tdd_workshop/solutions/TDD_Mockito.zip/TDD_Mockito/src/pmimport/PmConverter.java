package pmimport;

public class PmConverter {

	private final ILegacyPm legacyPm;

	private final IModernPm modernPm;

	public PmConverter(ILegacyPm legacyPm, IModernPm modernPm) {
		this.legacyPm = legacyPm;
		this.modernPm = modernPm;
	}

	/**
	 * Converts all data from the legacy pm to the modern pm.
	 */
	public void convert() {
		for (String legacyProductId : legacyPm.getAllProducts()) {
			String modernProductId = modernPm.createProduct(legacyPm
					.getProductName(legacyProductId));
			for (String attributeName : legacyPm.getAttributes(legacyProductId)) {
				modernPm.addAttribute(modernProductId, attributeName);
			}
		}
	}

}
