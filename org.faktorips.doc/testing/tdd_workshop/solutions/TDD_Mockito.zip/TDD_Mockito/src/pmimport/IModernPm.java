package pmimport;

public interface IModernPm {

	/**
	 * Creates a new product with the given name and returns it's id.
	 */
	public String createProduct(String name);

	/**
	 * Adds an attribute with the given name to the product with the given id.
	 */
	public void addAttribute(String productId, String attributeName);

}
