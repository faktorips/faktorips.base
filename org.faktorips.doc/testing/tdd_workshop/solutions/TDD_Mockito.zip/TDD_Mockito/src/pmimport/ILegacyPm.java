package pmimport;

import java.util.List;

public interface ILegacyPm {

	/**
	 * Returns a list containing the ids of all products.
	 */
	List<String> getAllProducts();

	/**
	 * Returns the name of the product with the given product id.
	 */
	String getProductName(String productId);

	/**
	 * Returns a list containing the names of all attributes belonging to the
	 * product with the given product id.
	 */
	List<String> getAttributes(String productId);

}
