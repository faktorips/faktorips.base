package pmimport;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.inOrder;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class PmConverterTest {

	@Mock
	private ILegacyPm legacyPm;

	@Mock
	private IModernPm modernPm;

	private PmConverter pmConverter;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		pmConverter = new PmConverter(legacyPm, modernPm);
	}

	@Test
	public void testConvert_TransferAllProducts() {
		List<String> legacyProducts = Arrays.asList("p1", "p2", "p3");
		when(legacyPm.getAllProducts()).thenReturn(legacyProducts);
		when(legacyPm.getProductName("p1")).thenReturn("Product 1");
		when(legacyPm.getProductName("p2")).thenReturn("Product 2");
		when(legacyPm.getProductName("p3")).thenReturn("Product 3");

		pmConverter.convert();

		verify(modernPm).createProduct("Product 1");
		verify(modernPm).createProduct("Product 2");
		verify(modernPm).createProduct("Product 3");
	}

	@Test
	public void testConvert_TransferAttributes() {
		List<String> legacyProducts = Arrays.asList("p1");
		List<String> legacyP1Attributes = Arrays.asList("a1", "a2", "a3");
		when(legacyPm.getAllProducts()).thenReturn(legacyProducts);
		when(legacyPm.getProductName("p1")).thenReturn("Product 1");
		when(legacyPm.getAttributes("p1")).thenReturn(legacyP1Attributes);
		when(modernPm.createProduct("Product 1")).thenReturn("id1");

		pmConverter.convert();

		InOrder inOrder = inOrder(modernPm);
		inOrder.verify(modernPm).createProduct("Product 1");
		inOrder.verify(modernPm).addAttribute("id1", "a1");
		inOrder.verify(modernPm).addAttribute("id1", "a2");
		inOrder.verify(modernPm).addAttribute("id1", "a3");
	}

}
